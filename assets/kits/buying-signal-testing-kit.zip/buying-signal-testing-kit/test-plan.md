# Test plan

Part of the Magnetiz Buying Signal Testing implementation kit.

Write this before the first message goes out, and sign it. The readout applies this plan, so the decision
is made now, while nobody has a stake in the result.

## 1. The comparison

The test compares accounts that show the signal against accounts that do not, from the same list, over
the same weeks.

| Arm | Who is in it | What they get |
|---|---|---|
| **Signal** | accounts in your target band that show the signal and pass the pre-send check | the message from the signal card |
| **Comparison** | accounts in the same band with no sign of the signal | your usual message, the line in the card's section 3 |

Keep everything else the same in both arms, including the sender, the channel, the days and the follow-ups.
What the test then measures is the signal and its message together, against how you reach out today.

## 2. How many, and what that can tell you

This playbook is written for teams that send hundreds of messages a month. At that size a test finds
big differences and misses small ones. That is fine. A signal that only works a little better is
rarely worth the checking it takes.

| Field | Your value |
|---|---|
| Accounts per arm | [plan on 100. A smaller test can still be read, it just gives a wider range] |
| What you count | [replies per account contacted, and meetings booked] |
| Quick-read count | [about 7 replies in each arm. Below it, read the result with the small-sample row in section 3] |
| Read date | [the date both arms reach their count, or six weeks, whichever comes first] |

Report the result as a chance and a range, never as proven. With a hundred accounts per arm, 9% against
3% is about a 96% chance the signal arm really replies more, and the gap could be anywhere from about 1 to
8 times. That is the honest way to report it.

## 3. What counts as enough

Decide now how sure you need to be before you believe the signal.

| Field | Your value |
|---|---|
| The chance that counts | [we use 90%. Keep the signal when the read says at least a 90% chance it beats the comparison] |
| "Too close to call" | [any read under that chance] |

Find your read in the table, or the nearest row. The chance is how likely it is that the signal arm's real
reply rate beats the comparison's. The range is where the real gap probably sits (90% of the time), as the
signal arm's rate over the comparison's.

| Signal arm replies | Comparison replies | Chance the signal arm really replies more | Range of the gap |
|---|---|---|---|
| 12 of 100 | 4 of 100 | 98% | 1.2 to 6.9 times |
| 9 of 100 | 3 of 100 | 96% | 1.05 to 7.7 times |
| 8 of 100 | 4 of 100 | 87% | 0.8 to 4.9 times |
| 6 of 100 | 3 of 100 | 84% | 0.7 to 5.5 times |
| 5 of 100 | 5 of 100 | 50% | 0.4 to 2.6 times |
| 9 of 60 | 3 of 60 | 96% | 1.1 to 7.6 times |
| Small-sample row, 4 of 30 | 1 of 30 | 90% | 0.8 to 14 times |

A signal arm at 9% against a comparison at 3% is the read that acts. At 6% against 3% the signal more likely
helps than not, but the chance is under 90%, so it is too close to call. A range that reaches below 1 means
the signal could be doing nothing at all. A small test is not unreadable; its range is just wide.

How the numbers were worked out. Each arm's reply rate starts with every rate from 0% to 100% equally
likely, is updated on its replies and non-replies, and the two are compared over 400,000 random draws.

## 4. What else could move the numbers

List anything in the test weeks that could change reply rates on its own, such as a holiday, a new
sender, a change to the main message, a launch or a news event in your market. The readout checks the
list before giving the signal credit.

- [ ]
- [ ]

## 5. The decision rule

| On the read date, the log shows | Decision |
|---|---|
| The chance that counts, nothing on the list happened | **Keep.** The signal earns its place. Scale it, keep the pre-send check, and read it again in a quarter |
| A gap, but something on the list happened | **Hold.** Run another period with a cleaner comparison |
| Too close to call | **Fix or retire.** Change the message once and run one more period, or apply the card's retirement rule |
| The signal arm did worse | **Retire** |
| Fewer than about 7 replies in an arm before the read date | **Keep recording.** On the read date, read it with the small-sample row and decide as above |

## Sign-off

| | Name | Date |
|---|---|---|
| Owner of the number | | |
| Person who runs the test | | |
