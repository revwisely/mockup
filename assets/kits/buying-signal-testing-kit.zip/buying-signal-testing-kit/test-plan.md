# Test plan

Part of the Magnetiz Buying Signal Testing implementation kit.

Write this before the first message goes out, and sign it. The readout applies this plan, so the decision
is made now, while nobody has a stake in the result.

## 1. The comparison

The test compares accounts that show the signal against accounts that do not, from the same list, over
the same weeks.

| Arm | Who is in it | What they get |
|---|---|---|
| **Signal** | accounts in your target band that show the signal and pass the pre-send check | the message from the signal card |
| **Comparison** | accounts in the same band with no sign of the signal | your usual message, the line in the card's section 3 |

Keep everything else the same in both arms, including the sender, the channel, the days and the follow-ups.
What the test then measures is the signal and its message together, against how you reach out today.

## 2. How many, and what that can tell you

This playbook is written for teams that send hundreds of messages a month. At that size a test finds
big differences and misses small ones. That is fine. A signal that only works a little better is
rarely worth the checking it takes.

| Field | Your value |
|---|---|
| Accounts per arm | [100 is a sensible floor. Fewer than 60 reads nothing] |
| What you count | [replies per account contacted, and meetings booked] |
| Minimum count to read | [e.g. 10 replies across both arms. Below it the read is "too few to decide"] |
| Read date | [the date both arms reach their count, or six weeks, whichever comes first] |

Call the result directional in the readout. With a hundred accounts per arm it is a strong hint, not a
proof, and that is the honest way to report it.

## 3. What counts as a gap

Decide now how big a difference has to be before you believe it.

| Field | Your value |
|---|---|
| The gap that counts | [e.g. the signal arm's reply rate about three times the comparison's, with the minimum count met] |
| The gap that means "too close to call" | [e.g. anything less than that] |

At a hundred accounts per arm and the low reply rates most cold outreach sees, a gap smaller than about
three times is usually noise. A signal arm at 9% against a comparison at 3% is a strong enough hint to act on. At 6%
against 3% it is too close to call.

## 4. What else could move the numbers

List anything in the test weeks that could change reply rates on its own, such as a holiday, a new
sender, a change to the main message, a launch or a news event in your market. The readout checks the
list before giving the signal credit.

- [ ]
- [ ]

## 5. The decision rule

| On the read date, the log shows | Decision |
|---|---|
| The gap that counts, minimum count met, nothing on the list happened | **Keep.** The signal earns its place. Scale it, keep the pre-send check, and read it again in a quarter |
| A gap, but something on the list happened | **Hold.** Run another period with a cleaner comparison |
| Too close to call, minimum count met | **Fix or retire.** Change the message once and run one more period, or apply the card's retirement rule |
| The signal arm did worse | **Retire** |
| Below the minimum count | **Keep recording.** Decide nothing yet |

## Sign-off

| | Name | Date |
|---|---|---|
| Owner of the number | | |
| Person who runs the test | | |
