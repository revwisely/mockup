# Signal card

Part of the Magnetiz Buying Signal Testing implementation kit.

Fill in one card for each signal on the shortlist, before any outreach uses it. The card is the signal's
definition. The pre-send check, the test and the readout all read from it.

## Why a card

A signal goes stale without anyone noticing. A job posting stays up after the seat is filled. A funding
round is a year old. A champion left the company they moved to.

The card writes down what must still be true for the signal to mean anything, and when it stops counting.

## 1. The signal

| Field | Your answer |
|---|---|
| Signal | [one line, e.g. a past champion started at a new company in our target band] |
| What you see | [the observable event, e.g. a new role on their LinkedIn profile] |
| Why it might mean ready | [one sentence, e.g. new leaders rebuild their stack in their first months] |
| Who it points to | [the person you would contact, by role] |

## 2. The fact that must still be true

Write the one fact that, if it stopped being true, would make the signal meaningless.

| Field | Your answer |
|---|---|
| The fact | [e.g. they still work at the new company, in a role that buys what we sell] |
| Where to check it | [the source, e.g. their LinkedIn profile, the company's careers page, the public filing] |
| How long it stays fresh | [e.g. 90 days from the start date. After that the signal is stale] |
| Last checked | [filled in by `pre-send-check.md` before each batch] |

If the fact cannot be checked, the account is held. It never sends on an unchecked signal.

## 3. The message it triggers

The signal earns its place only if the message uses it. Write the opening line the signal makes
possible, the one that could not be sent without it.

| Field | Your answer |
|---|---|
| Opening line | [about the person and the moment, no pitch] |
| What the message asks | [one small ask] |
| The message without the signal | [the line the comparison accounts get, see `test-plan.md`] |

## 4. When it retires

Write the retirement rule now, while nobody has a stake in the signal. The readout applies it.

| Retire the signal when | Your rule |
|---|---|
| The test reads no gap | [e.g. two read periods in a row with no gap past the minimum count] |
| It cannot be checked | [e.g. more than one in five accounts fail the check because the source is gone or unclear] |
| It goes stale too often | [e.g. more than one in three accounts are past their fresh window by the time they would send] |
| It gets crowded | [e.g. buyers mention hearing the same message from others] |

## Sign-off

| | Name | Date |
|---|---|---|
| Owner of the number | | |
| Person who runs the checks | | |
