# Pre-send check

Part of the Magnetiz Buying Signal Testing implementation kit.

Run this on every signal-arm account before its batch goes out. It takes a few minutes per account and
it is the part of the playbook that stops the most embarrassing messages.

## Why check before every batch

Lists go stale between the day they are built and the day they send. When we read every rendered message
before one load, 8 of 129 contacts had already moved on to other companies.

A message about a moment that has passed tells the buyer you did not look.

## The check

One row per account in the batch. Read the fact from the signal card, check it at its source, and write
what you found.

| Account | Person | Signal | The fact (from the card) | Checked at | Still true? | Inside the fresh window? | Send / hold |
|---|---|---|---|---|---|---|---|
| | | | | [date] | [yes / no / cannot tell] | [yes / no] | |
| | | | | | | | |
| | | | | | | | |
| | | | | | | | |
| | | | | | | | |

## The rules

- **Send** only when the fact is still true and inside its fresh window.
- **Hold** when the answer is "cannot tell". An unchecked signal never sends. Treat "cannot tell" as its
  own answer, never as a yes.
- **Drop** from the signal arm when the fact is no longer true. Do not move the account to the comparison
  arm, because it showed the signal once and that would muddy both.
- **Read the rendered message**, the one the tool will actually send, with the name, company and opening
  line filled in. Check the company is the one they work at today.

## The tally for the batch

The readout uses these to apply the card's retirement rule.

| Field | Count |
|---|---|
| Accounts checked | |
| Sent | |
| Held, cannot tell | |
| Dropped, no longer true | |
| Dropped, past the fresh window | |
