# Sample filled card

Part of the Magnetiz Buying Signal Testing implementation kit.

A worked example, so the blank card is easier to fill. The company and its numbers are made up.
Northgate Analytics sells a $30K-a-year reporting product to finance teams at companies of 100 to 400
people. It picked "a past champion starts at a new company", one of the four places Kyle Poyar suggests
starting, because the team already knows who its champions were.

## 1. The signal

| Field | Answer |
|---|---|
| Signal | A person who championed us at a customer or a late-stage deal starts at a new company in our band |
| What you see | A new role on their LinkedIn profile, at a company of 100 to 400 people |
| Why it might mean ready | They already know the product works, and new finance leaders tend to rebuild reporting in their first months |
| Who it points to | The champion themselves |

## 2. The fact that must still be true

| Field | Answer |
|---|---|
| The fact | They still work at the new company, in a finance role that owns reporting |
| Where to check it | Their LinkedIn profile, and the company's own team page if it has one |
| How long it stays fresh | 120 days from their start date |
| Last checked | Filled in by the pre-send check before each batch |

## 3. The message it triggers

| Field | Answer |
|---|---|
| Opening line | "Saw you started at Halden as head of finance last month. Congratulations, and I hope the first weeks are treating you well." |
| What the message asks | Whether reporting is on their list for the first quarter, and if a short call on how their last team set it up would help |
| The message without the signal | The team's usual opener about month-end close taking too long |

## 4. When it retires

| Retire the signal when | Rule |
|---|---|
| The test reads no gap | Two read periods in a row with no gap past the minimum count |
| It cannot be checked | More than one in five profiles are private or unclear |
| It goes stale too often | More than one in three champions are past 120 days by the time they would send |
| It gets crowded | Two or more replies mention hearing the same congratulations from other vendors |

## The test, in one line

Northgate's list shows about 25 champion moves a month, so the signal arm takes about four months to
reach 100 accounts. The team runs a second signal from the shortlist at the same time, a new finance
leader at any company in the band, which reaches 100 in about five weeks. Each signal is read on its own
when it reaches its own count, and neither is judged early.
