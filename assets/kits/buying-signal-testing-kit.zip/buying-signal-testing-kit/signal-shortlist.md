# Signal shortlist

Part of the Magnetiz Buying Signal Testing implementation kit.

Fill this in first. It turns a long list of possible signals into the two or three worth testing. Every
other worksheet in the kit works on the signals this page picks.

## Why a shortlist

There are more signals than any team can check. Testing ten at once spreads the outreach so thin that
none of them can be read.

Pick few, pick the ones you can see and check from outside the account, and lean toward the ones fewer
teams act on.

## 1. List every candidate

One row per signal you have heard of, already pay for, or could watch by hand.

| Signal | Can you see it from outside the account before the conversation? | How crowded is it? | What does checking it cost? | Shortlist? |
|---|---|---|---|---|
| [e.g. a champion moved to a new company] | [yes / only with their data / no] | [high / medium / low, see section 2] | [minutes per account, or a tool cost] | [ ] |
| | | | | [ ] |
| | | | | [ ] |
| | | | | [ ] |
| | | | | [ ] |
| | | | | [ ] |

A signal you cannot see before the conversation is a discovery question. Ask it on the call and keep it
off the list.

## 2. How crowded is each one?

The more teams act on a signal, the more likely your buyer hears the same message from three other
companies the same week.

The 2026 State of B2B GTM report (Kyle Poyar and Maja Voje, 300 companies, self-reported) asked which
signals GTM teams act on.

| Share of companies acting on it | Signals | Crowding |
|---|---|---|
| 40% or more | content engagement (52%), website visits (42%), product usage (40%) | high |
| 20% to 39% | social activity (30%), champion movements (28%), hiring activity (25%), leadership changes (24%) | medium |
| Under 20% | company events (17%), tech changes (14%) | low |

A high-crowding signal can still work. It needs a better message to stand out, and the test will show
whether it gets one.

## 3. Where less-crowded signals come from

The least crowded signals usually come from data your competitors are not reading.

- **Public records specific to your market.** Filings, permits, registrations, tenders, licences.
  Compared over time, a new entry or a change marks a moment before it shows up anywhere else.
- **Tech changes.** A team adding or dropping a tool is often the clearest evidence it is rebuilding
  that part of its stack.
- **Company events.** A new office, a new region, a product launch, a reorganisation.

The work in these sources is figuring out which company and which person the record points to. That
work is also why fewer teams do it.

## 4. The shortlist

Pick two or three. Each one gets its own `signal-card.md`.

| # | Signal | Why it might mean ready (one sentence) | Crowding |
|---|---|---|---|
| 1 | | | |
| 2 | | | |
| 3 | | | |

Before going on, answer each in a line. A "no" means swap the signal.

- Can every signal on the shortlist be checked by someone on the team in a few minutes per account? [yes / no]
- Will the list have at least 100 accounts showing each signal over the next four to six weeks? [yes / no, if no see `test-plan.md` section 2]
- Is at least one signal medium or low crowding? [yes / no]
