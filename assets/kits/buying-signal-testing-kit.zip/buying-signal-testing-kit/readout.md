# Readout

Part of the Magnetiz Buying Signal Testing implementation kit.

Fill this in on the read date in `test-plan.md`, one readout per signal. It applies the plan's decision
rule and the card's retirement rule as they were signed.

## 1. The numbers

| | Signal arm | Comparison arm |
|---|---|---|
| Accounts contacted | | |
| Replies | | |
| Reply rate (replies / contacted) | | |
| Meetings booked | | |
| Meetings per 100 contacted | | |

| Field | Value |
|---|---|
| Quick-read count met? | [yes / no, about 7 replies in each arm, from `test-plan.md` section 2] |
| The gap (signal reply rate / comparison reply rate) | |
| Chance the signal arm really replies more | [from the table in `test-plan.md` section 3, nearest row] |
| Range of the gap | [from the same row] |
| Past the chance that counts? | [yes / no] |

## 2. What else happened

Copy the list from `test-plan.md` section 4 and mark anything that happened during the test.

| Planned or possible event | Happened? | Could it explain the gap? |
|---|---|---|
| | | |
| | | |

## 3. The checks

From the pre-send check tallies across all batches.

| Field | Value |
|---|---|
| Accounts checked | |
| Share held, cannot tell | |
| Share dropped, no longer true or stale | |
| Hit a retirement trigger on the card? | [yes / no, which one] |

## 4. The decision

Apply the rule from `test-plan.md` section 5 as written. Pick one.

- [ ] **Keep.** The signal earns its place.
- [ ] **Hold.** Run another period, because something else could explain the result.
- [ ] **Fix.** Change the message once and run one more period.
- [ ] **Retire.** Apply the card's retirement rule.
- [ ] **Keep recording.** Fewer than about 7 replies in an arm and the read date not reached.

Write the result as a chance and a range, for example "about a 96% chance the signal arm replies more
than the comparison, with the gap anywhere from about 1 to 8 times, over 100 accounts per arm". Never as
proven, and never the gap alone.

## 5. What happens next

| If kept | If retired |
|---|---|
| Scale it with the pre-send check still on every batch. Read it again in a quarter, because a signal that works now can stop working once more teams use it | Take the next signal off the shortlist and fill in its card |

## Sign-off

| | Name | Date |
|---|---|---|
| Owner of the number | | |
| Person who ran the test | | |
