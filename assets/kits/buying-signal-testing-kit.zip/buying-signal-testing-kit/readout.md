# Readout

Part of the Magnetiz Buying Signal Testing implementation kit.

Fill this in on the read date in `test-plan.md`, one readout per signal. It applies the plan's decision
rule and the card's retirement rule as they were signed.

## 1. The numbers

| | Signal arm | Comparison arm |
|---|---|---|
| Accounts contacted | | |
| Replies | | |
| Reply rate (replies / contacted) | | |
| Meetings booked | | |
| Meetings per 100 contacted | | |

| Field | Value |
|---|---|
| Minimum count met? | [yes / no, from `test-plan.md` section 2] |
| The gap (signal reply rate / comparison reply rate) | |
| Past the gap that counts? | [yes / no] |

## 2. What else happened

Copy the list from `test-plan.md` section 4 and mark anything that happened during the test.

| Planned or possible event | Happened? | Could it explain the gap? |
|---|---|---|
| | | |
| | | |

## 3. The checks

From the pre-send check tallies across all batches.

| Field | Value |
|---|---|
| Accounts checked | |
| Share held, cannot tell | |
| Share dropped, no longer true or stale | |
| Hit a retirement trigger on the card? | [yes / no, which one] |

## 4. The decision

Apply the rule from `test-plan.md` section 5 as written. Pick one.

- [ ] **Keep.** The signal earns its place.
- [ ] **Hold.** Run another period, because something else could explain the result.
- [ ] **Fix.** Change the message once and run one more period.
- [ ] **Retire.** Apply the card's retirement rule.
- [ ] **Keep recording.** Below the minimum count.

Write the result as directional, for example "the signal arm replied at about three times the
comparison, over 100 accounts per arm". Never as proven.

## 5. What happens next

| If kept | If retired |
|---|---|
| Scale it with the pre-send check still on every batch. Read it again in a quarter, because a signal that works now can stop working once more teams use it | Take the next signal off the shortlist and fill in its card |

## Sign-off

| | Name | Date |
|---|---|---|
| Owner of the number | | |
| Person who ran the test | | |
