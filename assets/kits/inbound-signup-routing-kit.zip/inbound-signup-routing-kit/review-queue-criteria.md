# Inbound Sign-Up Routing — review-queue criteria

Part of the Magnetiz Inbound Sign-Up Routing implementation kit. Uncertainty drops to a
person, with reasons. A queue that is always empty means the rules are guessing.

## What drops to review (any one is enough)

1. **Conflicting evidence.** The form says one company, the email domain says another.
2. **Borderline bands.** Within [5] points of a band edge, either score.
3. **Ambiguous duplicates.** Same domain, different person, or fuzzy name matches.
4. **Unverifiable identity, per the null rule.** Two or more fit signals scored null
   (free email + no company found, for example). Might be a buyer browsing privately,
   might be a bot. Null is never zero, and a person decides.
5. **Anything the enricher marked low confidence.**

## The review entry format

Each queued item carries: the brief, the specific reason it queued (never just
"review"), and the two most likely calls with what each implies.

## The rules

- Review decisions get recorded WITH the reason, because they are the calibration data
  for the next band review.
- The queue gets drained on a cadence (daily at volume, weekly early on). A stale queue
  is worse than no queue; the person waiting was possibly qualified.
- Patterns in the queue drive rule changes at reviews. Three of the same ambiguity is a
  rule waiting to be written.

## Graduating a lane to unattended routing

Every lane starts supervised: the router proposes, a person confirms, and nothing
routes on its own. Lanes graduate one at a time, never together, because they fail
differently and a single blanket switch hides which one was not ready.

| Lane | Consecutive clean passes before it runs unattended | Graduated on | By |
|---|---|---|---|
| QUALIFIED | [20] | | |
| NURTURE | [20] | | |
| MONITOR | [20] | | |
| NO FIT | [50] | | |

A **clean pass** is one routed sign-up the confirming person agreed with, route
unchanged. A route the reviewer changes resets that lane's count to zero. Not to the
count minus one — to zero, because a streak is the claim being tested and a single
break disproves it.

**NO FIT graduates last, and needs roughly twice the streak.** Every other lane's
mistake is visible and recoverable: a wrongly-qualified sign-up wastes a rep's time and
somebody notices. A wrongly-no-fitted one is a real buyer served politely and never
followed up, and nothing in the system will ever tell you it happened. Errors you can
see justify less patience than errors you cannot.

**Graduation is reversible and should be treated as routine.** Three route corrections
in a lane inside [30] days puts it back to supervised. Going back is not a failure of
the system; refusing to go back is.
