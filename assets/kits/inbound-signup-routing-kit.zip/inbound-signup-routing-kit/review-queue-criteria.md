# Inbound Sign-Up Routing — review-queue criteria

Part of the Magnetiz Inbound Sign-Up Routing implementation kit. Uncertainty drops to a
person, with reasons. A queue that is always empty means the rules are guessing.

## What drops to review (any one is enough)

1. **Conflicting evidence.** The form says one company, the email domain says another.
2. **Borderline bands.** Within [5] points of a band edge, either score.
3. **Ambiguous duplicates.** Same domain, different person, or fuzzy name matches.
4. **Unverifiable identity.** Free email + no company found. Might be a buyer browsing
   privately, might be a bot. A person decides.
5. **Anything the enricher marked low confidence.**

## The review entry format

Each queued item carries: the brief, the specific reason it queued (never just
"review"), and the two most likely calls with what each implies.

## The rules

- Review decisions get recorded WITH the reason, because they are the calibration data
  for the next band review.
- The queue gets drained on a cadence (daily at volume, weekly early on). A stale queue
  is worse than no queue; the person waiting was possibly qualified.
- Patterns in the queue drive rule changes at reviews. Three of the same ambiguity is a
  rule waiting to be written.
