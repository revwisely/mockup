# Inbound Sign-Up Routing — routing rules

Part of the Magnetiz Inbound Sign-Up Routing implementation kit.

## The routes

Routes are decided by the band table in `qualification-rules.md`, evaluated in its
stated precedence order (review first, then qualified, nurture, monitor, no fit). This
file covers what each route DOES once decided.

| Route | What happens | SLA |
|---|---|---|
| Qualified | Named owner assigned, dated next step, brief attached, channel alert | owner acts within [1 business day] |
| Nurture | Added to release emails; nothing manual | re-scored on new activity |
| Monitor | Watched; re-scored on return visits | none |
| No fit | The resource they asked for, delivered politely. Nothing else, ever | immediate |

## Duplicate handling (before anything is created)

1. Match on email, then on company domain, against existing accounts and open deals.
2. A match UPDATES the existing record and alerts its owner. It never creates a twin.
3. An ambiguous match (same domain, different person) goes to the review queue, both
   records linked.

## Assignment

- One owner per qualified sign-up, by name, with the brief attached. Round-robin only
  within people who agreed to the SLA.
- The alert lands in the channel the team already reads, with the brief, never a bare
  notification.

## The no-fit rule, spelled out

Students, recruiters, and bots get what they asked for and never enter a sequence.
Serving them politely costs nothing and protects the list, the domain, and the brand.
