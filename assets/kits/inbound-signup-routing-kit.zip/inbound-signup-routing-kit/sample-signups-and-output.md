# Inbound Sign-Up Routing — four sample sign-ups and the answer key

Part of the Magnetiz Inbound Sign-Up Routing implementation kit. Run these before any
real submission. Differences in wording are fine. Differences in ROUTE are failures
worth fixing on day one.

## The samples

1. **The potential customer.** jordan@meridianops.com requests the implementation kit.
   Source: LinkedIn. Company resolves to a 140-person logistics software firm; LinkedIn
   shows "VP Operations." Second visit in a week.
2. **The recruiter.** talent@peakstaffing.io requests the kit. Source: search. Company
   resolves to a staffing agency; profile says "Technical Recruiter."
3. **The student.** amara.chen@university.edu requests the kit. Source: an AI assistant.
   No company. Profile shows a graduate program.
4. **The unknown.** rt.factor@gmail.com requests the kit. Source: colleague. Free email,
   no company found, no profile match. One visit, eight pages, nine minutes.

## The answer key

| Sample | Fit | Intent | Route | The judgment, stated |
|---|---|---|---|---|
| Customer | high | high | **QUALIFIED** | role + shape verified; a kit request plus a return visit inside a week is high intent. Owner + dated step |
| Recruiter | low | low-medium | **NO FIT** | real person, wrong lane. Kit delivered politely, no sequence, tagged so a future job-change re-scores fresh |
| Student | low | low | **NO FIT** | serve the kit gladly; students become buyers in years, not quarters |
| Unknown | null (2+ fit signals unverifiable) | high | **REVIEW** | eight pages in nine minutes is real attention with zero identity. Nulls, never zeros, so the precedence order sends it to a person. The failure mode is routing it to sales OR discarding it |

## What the answer key is teaching

- Two NO FIT results that still get served well. The router protects the list without
  being rude.
- High intent with UNKNOWN fit goes to a person (review). High intent with KNOWN-low fit
  would go to monitor instead; the crawler is the classic case, and the null rule is
  what keeps those two lanes apart.
- Nobody was scored up for enthusiasm alone.
