# Inbound Sign-Up Routing — account brief template

Part of the Magnetiz Inbound Sign-Up Routing implementation kit. One screen. What we
verified, what we could not, with sources. The router and the human reviewer read the
same brief.

---

## [Person name] — [Company]

**Requested.** [what they asked for, verbatim] · arrived via [source]
**Date.** [date] · **Duplicate check.** [no match | matched existing account →link]

### Verified (each line carries a source)

| Claim | Evidence | Source | Date |
|---|---|---|---|
| Role | | | |
| Company, size, model | | | |
| Anything they told us, verbatim | | | |

### Could not verify

- [the unknowns, stated as unknowns — never guessed]

### Scores

Fit [ ]/50 because [one line]. Intent [ ]/50 because [one line].

### Decision

Route: [qualified | nurture | monitor | no fit | REVIEW] · Reason: [one line]
Owner: [name] · Next step: [action] by [date]
