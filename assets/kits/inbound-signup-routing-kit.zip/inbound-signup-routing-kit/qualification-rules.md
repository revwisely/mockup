# Inbound Sign-Up Routing — qualification rules

Part of the Magnetiz Inbound Sign-Up Routing implementation kit. The judgment at the
center is one split. FIT scores who they are. INTENT scores what they did. Kept apart,
enthusiasm cannot fake fit.

## Fit (0-50) — who they are

| Signal | Points | Your calibration |
|---|---|---|
| Role matches your buyer (define the titles) | 0-20 | |
| Company shape matches (size band, industry, model) | 0-20 | |
| Reachable, real identity (corporate email, real company) | 0-10 | |

## Intent (0-50) — what they did

| Signal | Points | Your calibration |
|---|---|---|
| What they requested (a kit, a call, pricing weigh differently) | 0-15 | |
| Return visits and depth (pages, time, repeat) | 0-15 | |
| Stated interest in their words (form fields, replies) | 0-20 | |

## Bands (set them, then leave them alone between reviews)

| Band | Condition | Route |
|---|---|---|
| Qualified | fit ≥ [ ] AND intent ≥ [ ] | named owner + dated next step |
| Nurture | fit ≥ [ ] AND intent < [ ] | release emails, no outreach |
| Monitor | intent high, fit low | watch; enthusiasm alone never routes to sales |
| No fit | fit < [ ] | polite fulfillment, nothing more |

## The three rules that keep scoring honest

1. **A download alone is not buying intent.** It is a request for a resource, scored as
   exactly that.
2. **Never one combined number.** A crawler with 25 visits is intent without fit. The
   split is what catches it.
3. **Bands change at reviews, never per lead.** Moving a band to qualify a lead you like
   is how the model stops meaning anything.
