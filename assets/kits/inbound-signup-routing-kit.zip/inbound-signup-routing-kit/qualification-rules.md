# Inbound Sign-Up Routing — qualification rules

Part of the Magnetiz Inbound Sign-Up Routing implementation kit. The judgment at the
center is one split. FIT scores who they are. INTENT scores what they did. Kept apart,
enthusiasm cannot fake fit.

## Fit (0-50) — who they are

| Signal | Points | Your calibration |
|---|---|---|
| Role matches your buyer (define the titles) | 0-20 | |
| Company shape matches (size band, industry, model) | 0-20 | |
| Reachable, real identity (corporate email, real company) | 0-10 | |

## Intent (0-50) — what they did

| Signal | Points | Your calibration |
|---|---|---|
| What they requested (a kit, a call, pricing weigh differently) | 0-15 | |
| Return visits and depth (pages, time, repeat) | 0-15 | |
| Stated interest in their words (form fields, replies) | 0-20 | |

## Nulls (the rule the whole design depends on)

**Unverified signals score null, never zero.** A zero says "verified bad." A null says
"could not verify." rt.factor@gmail.com with no company found is nulls on the fit side,
never a low fit score. **Two or more nulls among the fit signals drop the sign-up to
review**, whatever the intent side says.

That makes MONITOR and REVIEW different lanes, and the difference is the crux:

- **Monitor** = intent high, fit KNOWN-low. The crawler with 25 visits. We can see who
  it is, and who it is does not buy. Watch, never sell.
- **Review** = intent high, fit UNKNOWN (nulls). The anonymous visitor reading for nine
  minutes. A person decides, because the evidence cannot.

## Bands, evaluated IN THIS ORDER (precedence is part of the rules)

Two implementers must get the same route from the same rules, so the checks run top to
bottom and the first match wins.

| Order | Band | Condition | Route |
|---|---|---|---|
| 1 | Review | 2+ fit nulls, conflicting evidence, ambiguous duplicate, or within [5] of any band edge | a person decides, reasons attached |
| 2 | Qualified | fit ≥ [ ] AND intent ≥ [ ] | named owner + dated next step |
| 3 | Nurture | fit ≥ [ ] AND intent < [ ] | release emails, no outreach |
| 4 | Monitor | intent ≥ [ ] AND fit known-low | watch; enthusiasm alone never routes to sales |
| 5 | No fit | fit < [ ], known | polite fulfillment, nothing more |

## Intent decay

Intent signals older than [90] days score at half. Older than [180] days, they expire.
A second visit eleven months later is a new first visit, never momentum.

## The three rules that keep scoring honest

1. **A download alone is not buying intent.** It is a request for a resource, scored as
   exactly that.
2. **Never one combined number.** A crawler with 25 visits is intent without fit. The
   split is what catches it.
3. **Bands change at reviews, never per lead.** Moving a band to qualify a lead you like
   is how the model stops meaning anything.
4. **Null is not zero.** Scoring an unknown as bad quietly deletes the review lane, and
   the review lane is where the interesting sign-ups live.
