# AI-Ready Data — dedupe and merge rules

Part of the Magnetiz AI-Ready Data implementation kit. Write the rules before merging
anything. Rules mean the dedupe never gets done by hand twice, and next quarter's
duplicate meets the same rules instead of a new argument.

## 1. Match rules (what counts as the same record)

| Record type | Match on | Never match on |
|---|---|---|
| Company | domain (normalized, no www) | company name alone |
| Contact | email; else full name + company domain | full name alone |
| Deal | [your key] | |

## 2. Survivorship (which record lives)

The surviving record is the one with [most recent genuine activity / the CRM id
referenced elsewhere — pick one and write it here]: ______________________

## 3. Field-level winners (fill per field in scope)

| Field | Winning source | Why |
|---|---|---|
| Title | newest verified | titles decay fast |
| Owner | the CRM | ownership is a CRM fact |
| Revenue | the finance system | |
| | | |

## 4. The rules that keep merging safe

0. **A merge is a write, so the do-not-touch list is checked first, for BOTH records.**
   A current client or a legal hold never gets merged by a rule; it queues for a person,
   whatever the match score says.
1. **Merges are logged, with both prior states.** A merge you cannot describe afterward
   is a delete.
2. **Ambiguous pairs queue for a person.** The rule set decides the clear 90%; a human
   decides the rest. Never let the tool guess on the ambiguous 10%.
3. **Do-not-merge list.** Some near-duplicates are real (two subsidiaries, one domain).
   List them so no rule ever collapses them: ______________________

## 5. Consolidating two fields that hold the same fact

Everything above merges two RECORDS. The MERGE verdict in `field-census.md` is a
different job: one record, two fields, the same fact in both. `industry` and
`vertical`. `employee_count` and `headcount`. Same rules will not do, because there is
no survivorship question and no do-not-merge list; there is a field nobody agreed to
retire and two half-filled columns.

| | Field A | Field B |
|---|---|---|
| Name | | |
| Filled on how many records in scope | | |
| What reads it (integrations, reports, workflows, humans) | | |
| Which one wins, and why | | |

Then, in this order:

1. **Count the disagreement before migrating.** On records where both are filled, how
   often do they differ? Under [5%] is a clerical merge. Over it, the two fields mean
   different things to different teams and consolidating them destroys a distinction
   somebody relies on. Go and ask before you touch it.
2. **Migrate only where the winner is empty.** A populated winner is never overwritten
   by the loser. This makes the migration re-runnable and makes a mistake recoverable.
3. **Retire by making the loser read-only first, not by deleting it.** Watch for
   [two weeks]. Deleting a field is the one step here with no undo, and the census's
   "what reads it" column is a survey, not a guarantee — reports and integrations go
   unlisted more often than anyone expects.
4. **Delete only after nothing has broken and nothing has asked for it.** If something
   did, you have found the consumer the census missed, which is the answer you wanted.
