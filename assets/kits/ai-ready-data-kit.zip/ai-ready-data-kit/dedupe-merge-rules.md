# AI-Ready Data — dedupe and merge rules

Part of the Magnetiz AI-Ready Data implementation kit. Write the rules before merging
anything. Rules mean the dedupe never gets done by hand twice, and next quarter's
duplicate meets the same rules instead of a new argument.

## 1. Match rules (what counts as the same record)

| Record type | Match on | Never match on |
|---|---|---|
| Company | domain (normalized, no www) | company name alone |
| Contact | email; else full name + company domain | full name alone |
| Deal | [your key] | |

## 2. Survivorship (which record lives)

The surviving record is the one with [most recent genuine activity / the CRM id
referenced elsewhere — pick one and write it here]: ______________________

## 3. Field-level winners (fill per field in scope)

| Field | Winning source | Why |
|---|---|---|
| Title | newest verified | titles decay fast |
| Owner | the CRM | ownership is a CRM fact |
| Revenue | the finance system | |
| | | |

## 4. The rules that keep merging safe

0. **A merge is a write, so the do-not-touch list is checked first, for BOTH records.**
   A current client or a legal hold never gets merged by a rule; it queues for a person,
   whatever the match score says.
1. **Merges are logged, with both prior states.** A merge you cannot describe afterward
   is a delete.
2. **Ambiguous pairs queue for a person.** The rule set decides the clear 90%; a human
   decides the rest. Never let the tool guess on the ambiguous 10%.
3. **Do-not-merge list.** Some near-duplicates are real (two subsidiaries, one domain).
   List them so no rule ever collapses them: ______________________
