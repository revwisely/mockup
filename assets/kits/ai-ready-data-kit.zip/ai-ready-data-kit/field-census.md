# AI-Ready Data — the field census

Part of the Magnetiz AI-Ready Data implementation kit. Unused and duplicated fields are
noise, and AI will faithfully read the noise. The census asks before it deletes.

## The census, one row per custom field in scope

| Field | Last filled (date) | % of records filled | What reads it (report, workflow, person) | Verdict |
|---|---|---|---|---|
| | | | | |
| | | | | |
| | | | | |

## Verdicts

- **KEEP.** Filled, read, and meaningful. Leave it alone.
- **FIX.** Read by something, but sparsely or inconsistently filled. Route to source
  fixes (validation at entry) rather than manual backfill.
- **MERGE.** Two fields carrying the same fact. Pick the winner with the merge rules,
  migrate, then retire the loser.
- **RETIRE.** Nothing has read it in a year. Hide it first, delete it a month later.

## The two safety rules

1. **Ask before retiring.** The field someone quietly reports from is the classic
   casualty. One message to the team with the retirement list, one week of silence,
   THEN hide.
2. **Hide before deleting.** Hiding is reversible and produces the same cleanliness.
   The month between hide and delete is the census's undo button.
