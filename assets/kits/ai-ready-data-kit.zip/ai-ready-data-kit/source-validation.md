# AI-Ready Data — source validation (fixing it at the source)

Part of the Magnetiz AI-Ready Data implementation kit. This is the file the audit and
the census route to, and the step that decides whether the cleanup holds. Everything
else in this kit is a one-time scrub; entry validation is what stops the mess refilling.

## 1. Entry points in scope

List every place a scoped record or field gets born or edited. Forms, imports,
integrations, manual entry, enrichment tools.

| Entry point | Creates or edits which scoped fields | Owner, by name |
|---|---|---|
| | | |
| | | |

## 2. Field-by-field decisions

One row per scoped field the audit or census flagged. Three possible treatments,
chosen deliberately.

| Field | Treatment | Detail |
|---|---|---|
| | required-at-entry | only where the person entering it actually knows the answer |
| | picklist | replaces free text; list the allowed values, and where "other" goes |
| | leave free | some fields are honestly free text; saying so is a decision too |

## 3. Free-text to picklist conversions

For each conversion: the field, the value list (built from the census's distinct-value
read), the mapping for existing values, and the owner of the list. A picklist nobody
owns grows an "Other" bulge and becomes free text with extra steps.

## The test, applied to every new rule

A validation rule earns its place when it makes tomorrow's records cheaper to trust
WITHOUT making them slower to create. A required field the entering person cannot
answer produces fiction, not data. When in doubt, validate at the point where the
answer is actually known, even when that is a later step.

## The completion check

The audit closes by requiring every bad number to have a named destination in this kit.
Empty and drifting fields route HERE, and this file is done when every routed field has
a row in section 2 with a treatment and an owner.
