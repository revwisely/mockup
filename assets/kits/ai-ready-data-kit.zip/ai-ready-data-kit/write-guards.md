# AI-Ready Data — write-guard patterns

Part of the Magnetiz AI-Ready Data implementation kit. Fail loud, never plausible. A
deterministic check hits a wrong field and throws an error you can see. A model hits the
same wrong field, adapts, and writes something plausible anyway. Silence is the failure
mode these guards remove.

## Guard 1 — loop protection

Enrichment that triggers on record updates can re-trigger itself forever, or two tools
can ping-pong a record between them.

- Stamp every automated write with a flag or source tag the trigger checks. Automated
  writes never re-fire the automation.
- Cap updates per record per day. A record touched 20 times today is a loop, and the cap
  turns it into an alert instead of a bill.

## Guard 2 — the do-not-touch list

Some records must never be modified by any tool. Current clients. Legal holds. The CEO's
pet account.

- Keep the list as data (a field or a table), never as tribal knowledge.
- Check it at EVERY write path, not just the polite ones. A guard checked in one place
  is a guard that will be bypassed by the next integration. Merges are writes too, and
  the merge rules file checks this list before touching either record.
- The list holds FIELDS as well as records. Pricing, contract terms, owner, stage, and
  anything a human wrote prose into get the same protection as the protected records.

## Guard 3 — deterministic validation around AI writes

Before any AI-proposed value lands in a field:

1. **Schema check.** The field exists and the type matches. On mismatch, STOP and alert.
   Never let the writer adapt.
2. **Range check.** Revenue is not negative, dates are not in 1970, picklist values are
   from the picklist.
3. **Diff check.** The write is presented as a proposed change (old value, new value,
   source), and consequential fields, meaning pricing, contract terms, owner, stage,
   amounts, and anything a human wrote, keep a human approve step. Graduation, defined
   standalone: a stretch of consecutive supervised passes with zero wrong writes,
   dated, before any field class writes unattended. (The Meeting Intelligence kit
   carries the full graduation log if you run both.)

## The test for every guard

Ask what happens when it fires. If the answer is a silent skip, redesign it. Guards
report loudly or they are decoration.
