# AI-Ready Data — the readiness audit

Part of the Magnetiz AI-Ready Data implementation kit. Scope first, then count. The
audit covers ONLY the fields the first workflow will read. Never boil the whole database;
a whole-CRM cleanup is the project that already failed once.

## 1. Scope — what AI reads first

| Question | Your answer |
|---|---|
| The workflow you want to run, in one sentence | |
| The record types it reads (accounts, contacts, deals) | |
| The exact fields it reads, listed by name | |
| The fields it may WRITE, listed by name | |
| The systems those fields live in (CRM, sheet, tool) | |

## 1b. Ownership (recurring work needs names, not roles)

| Obligation | Owner, by name |
|---|---|
| The scope itself (what AI reads, and changes to it) | |
| Draining the ambiguous-merge queue | |
| Running the field census | |
| Re-running the scorecard monthly | |
| Maintaining the do-not-touch list | |

## 2. The before-numbers (count, don't estimate)

Run the counts against the scoped fields only. These numbers are what the re-measure
gate reads at the end, so they must come from queries, never from impressions.

| Measure | How to count it | Before | Date | After | Date |
|---|---|---|---|---|---|
| Duplicate records in scope | group by domain or email, count groups > 1 | | | | |
| Empty required fields | count records where the field is null | | | | |
| Conflicting values across systems | RANDOM sample of 50 from the scoped population (name it); the after-sample is freshly drawn, never the records you fixed | | | | |
| Stale records | untouched in 12+ months | | | | |
| Free-text fields doing a picklist's job | count distinct values; more than 30, or more than 5% of records, whichever fits your size. A starting heuristic, tune it | | | | |

## 3. The honest reading

- A high duplicate count routes you to the merge rules file.
- Empty fields route to the field census (is the field dead?) or to source-validation.md
  (is the form wrong?).
- Conflicts route to survivorship rules: name which system wins, per field, in writing.
- Free-text drift routes to source-validation.md, where the picklist conversion lives.
- **Stale records route to the SCOPE, not to cleaning.** The useful move on a record
  untouched for a year is usually excluding it from what AI reads, not scrubbing it.
  Archive the dead, clean the living, and record the exclusion as a scope decision.

The audit is done when every bad number has a named destination in this kit, and with
source-validation.md in the kit, every number now has one.
