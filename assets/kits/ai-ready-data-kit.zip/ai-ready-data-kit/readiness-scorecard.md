# AI-Ready Data — the readiness scorecard

Part of the Magnetiz AI-Ready Data implementation kit. The gate is simple. Until the
numbers move, no workflow reads these records. A gate that reads a number cannot be
argued with.

## The gate, per workflow

| Check | Threshold | Before | After | Pass? |
|---|---|---|---|---|
| Duplicate records in scope | under [2%] | | | |
| Required fields filled | over [90%] on records the workflow reads | | | |
| Cross-system conflicts in sample | zero unexplained in a 50-record sample | | | |
| Loop protection | in place and tested with a deliberate loop | | | |
| Do-not-touch list | in place, checked at every write path | | | |
| Deterministic validation on AI writes | in place, fails loud on schema surprise | | | |

Set the bracketed thresholds yourself, before the cleanup, and write down why.
Thresholds set after the work always equal whatever the work achieved.

## Reading the result

- **All rows pass.** Point the workflow at the records. Re-run this scorecard monthly;
  data decays and the scorecard is what notices.
- **A count row fails.** Back to the fixes. The number tells you which file in this kit
  to reopen.
- **A guard row fails.** Do not proceed on the strength of clean data alone. Clean data
  with unguarded writes is a mess on a schedule.

## The line worth keeping

AI on a mess makes the mess worse. The scorecard is how you know it is no longer a mess,
in numbers rather than vibes.
