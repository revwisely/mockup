# Deal evidence fields

Part of the Magnetiz Pipeline Slip Report implementation kit.

Fill this in second. For each rule in `slip-rules.md`, find the field your CRM already keeps.

Field names below are the standard ones. Check the internal name in your own portal or org before you build
a report on it, because admins rename fields.

## Where each rule reads from

| Rule | What it needs | HubSpot | Salesforce | If not tracked |
|---|---|---|---|---|
| Category | Which deals are Commit, Best Case or Pipeline | The deal's forecast category, or the stage-to-category mapping in your forecast settings | The opportunity's Forecast Category, set from stage in your forecast settings | Write down which stages your team counts as Commit and Best Case, and use stage |
| R1 | Days in the current stage, and won deals' average days in each stage | The Date entered and Date exited properties for each deal stage, or the deal stage history on the record | Opportunity History (stage and date per change), or the LastStageChangeDate field on Opportunity | Add a stage-entered date field and start stamping it today. Until it has a quarter of data, use days since the deal was created against your average cycle |
| R2 | Last activity date, and whether anything is booked next | Last activity date and Next activity date on the deal | LastActivityDate on Opportunity, plus open Events and Tasks with a future date | Ask reps to log the next meeting before they close the call. Count a deal with no logged next step as nothing booked |
| R3 | How many times the close date moved out | The property history on Close date, shown on the deal record | The opportunity's history of Close Date changes, from stage history or field history tracking. Check which your org shows | Add a number field for pushes. The rep adds one each time the close date moves later |
| R4 | Whether anyone with signing authority has been on a call, in a meeting, or in a reply | Contacts associated with the deal, their Job title, and the meetings and emails logged against the deal | Opportunity Contact Roles (check whether your role list includes a decision maker or economic buyer role), plus logged Events | Add a yes or no field for signer engaged, with the date. The rep sets it only when the signer was actually in the conversation |
| R5 | How many buyer contacts are engaged | Count of associated contacts with a logged meeting or a reply in the last 30 days | Count of Contact Roles with a logged Event or reply in the last 30 days | Count the names on the last two meeting invites from the buyer's side |
| R6 | A critical event, meaning the date or outside force behind the close date | No standard field. Add a text field for the critical event and a date field for when it lands | No standard field. Add the same two custom fields | Ask it in the weekly review and write the answer in the report |
| R7 | The steps from a yes to a signature | No standard field. Add a text field for signature steps, such as security review, legal, procurement or board | No standard field. Add the same custom field, or use a mutual action plan if you run one | Ask it in the weekly review and write the answer in the report |

## Before the first run

1. Check each field above exists in your CRM and is filled on most open deals.
2. For any rule whose field is missing or mostly empty, use the right-hand column for now.
3. Check that you can see past close dates on a deal (R3). If you cannot, turn on history tracking for the close date field today. Every week without it is a week of pushes you cannot count.
4. Pull won deals from the last four quarters and work out the average days in each stage (R1). Write
   them here.

| Stage | Won deals' average days in stage | 1.5 times that (the R1 line) |
|---|---|---|
| | | |
| | | |
| | | |
| | | |
