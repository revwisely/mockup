# Sample pipeline and report

Part of the Magnetiz Pipeline Review implementation kit.

A worked example from input to output. The company and every deal are made up. Harbor Analytics sells
software to mid-sized companies, and it is week six of its quarter.

## Harbor's thresholds

From `deal-evidence-fields.md`, Harbor pulled its won deals from the last four quarters.

| Stage | Won deals' average days in stage | R1 line |
|---|---|---|
| Discovery | 14 | 21 |
| Demo | 10 | 15 |
| Proposal | 18 | 27 |
| Negotiation | 12 | 18 |

Signers at Harbor's buyers are usually the CFO, the COO, or a VP who owns the budget.

## The input, six open deals closing this quarter

| Deal | Amount | Category | Stage | Days in stage | Last activity | Next booked | Close date pushes | Signer engaged | Buyer contacts engaged | Critical event | Signature steps known |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Brightmere Health | $84K | Commit | Negotiation | 25 | 3 days ago | yes | 0 | yes, VP Operations | 4 | new clinic opens Feb 1 | yes |
| Halden Logistics | $120K | Commit | Proposal | 30 | 11 days ago | no | 1 | no | 1 | none recorded | no |
| Corvid Software | $46K | Commit | Negotiation | 9 | 2 days ago | yes | 0 | yes, CFO | 3 | budget expires Dec 31 | yes |
| Ostrava Foods | $65K | Commit | Proposal | 12 | 5 days ago | yes | 1 | no | 2 | new plant online in Q1 | yes |
| Tamsin Labs | $38K | Best Case | Demo | 8 | 9 days ago | no | 0 | yes, COO | 1 | none recorded | no |
| Wexford Retail | $52K | Commit | Negotiation | 14 | 1 day ago | yes | 0 | yes, CFO | 5 | holiday season cutover | no |

## The rules applied

| Deal | R1 | R2 | R3 | R4 | R5 | R6 | R7 | Flags |
|---|---|---|---|---|---|---|---|---|
| Brightmere Health | flag, 25 days against 18 | | | | | | | 1 |
| Halden Logistics | flag, 30 days against 27 | flag | flag | flag | flag | flag | flag | 7 |
| Corvid Software | | | | | | | | 0 |
| Ostrava Foods | | | flag | flag | | | | 2 |
| Tamsin Labs | | flag | | | flag | flag | flag | 4 |
| Wexford Retail | | | | | | | flag | 1 |

## The report Harbor's revenue leader sent out

Most flags first, then largest amount.

| Deal | Owner | Amount | Category | Flags | The evidence | Question for the owner | Owner's answer | Category after the call |
|---|---|---|---|---|---|---|---|---|
| Halden Logistics | Dana | $120K | Commit | R1 R2 R3 R4 R5 R6 R7 | 30 days in Proposal, quiet for 11 days, pushed once, one contact, no signer | Who signs, and when do they join a conversation with us? | Our contact says the COO will sign but has not met us. No date yet | Best Case |
| Tamsin Labs | Priya | $38K | Best Case | R2 R5 R6 R7 | Quiet for 9 days, one contact, nothing booked | When did we last hear from them, and what is the next meeting? | Sent the proposal, no reply yet | Best Case, owner to book a call this week |
| Ostrava Foods | Marcus | $65K | Commit | R3 R4 | Pushed once, signer not yet engaged | What changed on their side when the date moved? | Their finance lead was out. The CFO joins Thursday's call | Best Case until Thursday |
| Brightmere Health | Dana | $84K | Commit | R1 | 25 days in Negotiation against a line of 18 | What has to happen to move to signature, and when is it booked? | Legal redlines back Monday, signature booked for the 14th | Commit, flag cleared with evidence |
| Wexford Retail | Marcus | $52K | Commit | R7 | Signature steps not written down | What happens between their yes and a signature? | Not sure if procurement is involved. Asking on Tuesday | Commit |

| Commit total before the call | Commit total after the call | Deals flagged | Deals moved out of Commit | Deals that cleared a flag with evidence |
|---|---|---|---|---|
| $367K | $182K | 5 | 2 | 1 |

## What the report changed

Before the call the quarter looked safe at $367K in Commit. After it, Commit stood at $182K, with
$185K moved to Best Case and a named question on each deal.

The board hears the smaller number in week
six instead of week twelve. Ostrava can move back to Commit after Thursday if the CFO joins the call.
