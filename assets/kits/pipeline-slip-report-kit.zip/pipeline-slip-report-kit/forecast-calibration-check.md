# Forecast calibration check

Part of the Magnetiz Pipeline Review implementation kit.

Run this once a quarter, in the first week after it closes. It answers the question nobody asks of a
forecast, which is whether the categories meant what they said.

## Why check the record

A forecast category is an estimate. Commit says this deal will close.

The only way to know whether
those calls are any good is to compare them with what happened. Douglas Hubbard, in How to Measure
Anything, puts the test plainly for a sales team.

"Of the large number of prospects she was 70% certain about closing, did about 70% actually close?"

The same test works for a whole team's categories, and for the slip rules themselves.

## 1. Freeze the snapshot at the start of the quarter

In the first week of the quarter, export every deal closing this quarter with its category, amount and
flags from the weekly report.

Save it and do not edit it. A snapshot changed after the fact will agree
with the outcome whether or not the forecast was any good.

## 2. Score the categories at the end

| Category at the start | Deals | Closed won | Close rate | What the category promised | Gap |
|---|---|---|---|---|---|
| Commit | | | | | |
| Best Case | | | | | |
| Pipeline | | | | | |

Write what each category promised before the quarter starts. A common line is that Commit closes at 90%
or better. If Commit closed at 60%, the forecast was 30 points too confident, and the number looked safe
because the category said so.

## 3. Score the rules

| Deals at the start | Count | Closed won | Close rate |
|---|---|---|---|
| No flags | | | |
| One flag | | | |
| Two or more flags | | | |

If flagged deals close about as often as unflagged ones, the rules are not finding your slips. Check
the thresholds in `slip-rules.md` before the next quarter.

## 4. Score each rule on its own

| Rule | Deals flagged | Closed won | Close rate | Keep, tighten or drop |
|---|---|---|---|---|
| R1 | | | | |
| R2 | | | | |
| R3 | | | | |
| R4 | | | | |
| R5 | | | | |
| R6 | | | | |
| R7 | | | | |

A rule earns its place when the deals it flags close less often than the deals it does not.

## After two quarters

Your own record now outranks the vendor research in `slip-rules.md`.

Replace the starting thresholds with
the ones your data supports, and keep the snapshot habit. A forecast that is checked every quarter is
one the board can start to trust.
