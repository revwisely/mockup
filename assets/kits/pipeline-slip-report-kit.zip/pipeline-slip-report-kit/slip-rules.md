# Slip rules

Part of the Magnetiz Pipeline Review implementation kit.

Fill this in first. Every other sheet in the kit reads these rules.

## Why the number looks safe until the last two weeks

Most pipeline reports read two things per deal, the stage and the amount.

A deal can sit in Commit
with both looking healthy while the evidence under it has gone quiet. The slip shows up in that
evidence weeks before it shows up in the number.

These rules read the evidence. Run them every week on every deal in Commit or Best Case.

## How to read a flag

A flag is a question for the rep, never a verdict on the deal.

The rules come from vendor research
on millions of deals, and that research shows which deals slip more often. It does not show why any
one of your deals will slip. The rep's answer, with evidence, decides.

## The rules

R1 to R5 rest on published research with a stated sample. R6 and R7 are sound method with no
published slip data behind them, so they are marked needs more research.

| Rule | Flag the deal when | What the research found | Grade |
|---|---|---|---|
| R1 | It has been in its current stage more than 1.5 times as long as your won deals spent in that stage | Ebsta and Pavilion, 4.2M opportunities. A deal whose Qualification stage ran 50% longer than average was 120% more likely to slip | B |
| R2 | No activity in more than 7 days, and nothing booked next | Ebsta and Pavilion. Deals with more than 7 days of inactivity and no future activity had win rates 65% lower | B |
| R3 | Its close date has already moved out at least once this quarter | Ebsta and Pavilion. 44% of deals were pushed back, and win rates on slipped deals fell 67%, most of all on deals delayed over 8 weeks | B |
| R4 | Nobody who can sign has been in the deal (on a call, in a meeting, or in a reply) | Gong Labs, 9,056 opportunities (2020). Deals without a decision maker involved were 80% less likely to close. Ebsta found top reps far more likely to have the economic buyer engaged before the solution was presented | B |
| R5 | Only one person on the buyer's side is engaged | Ebsta and Pavilion. Won deals had 9 contacts engaged by the solution stage, lost deals had 2. Gong Labs, 120M+ calls. Win rates were 30% higher when 4 or more people spoke up than when one person did all the talking | B |
| R6 | No critical event is recorded, meaning no date or outside force behind the close date | Winning by Design (SPICED) defines the critical event as the deadline or outside force that decides when a decision must be made. No published slip data | C, needs more research |
| R7 | The steps from a yes to a signature are unknown | MEDDICC, the paper process. "You cannot accurately forecast without fully understanding the Paper Process." No published slip data | C, needs more research |

Sources are listed at the end of this sheet.

## Set your thresholds

The research gives a starting point. Your own deals set the real line.

| Rule | Starting threshold | Your threshold |
|---|---|---|
| R1 | 1.5 times your won deals' average days in that stage | |
| R2 | 7 days with no activity and nothing booked | |
| R3 | One push this quarter | |
| R4 | No one with signing authority engaged | |
| R5 | One buyer contact engaged | |
| R6 | No critical event written on the deal | |
| R7 | Signature steps not written on the deal | |

Who counts as able to sign is your call. Write the titles here before the first run.

Signers at our buyers are usually

## What a flag does to the forecast

A starting point to test, set by judgment and checked each quarter in
`forecast-calibration-check.md`.

- **One flag.** The deal stays where it is. The rep answers the question in the weekly report.
- **Two or more flags.** The deal moves from Commit to Best Case unless the rep shows evidence that
  clears a flag.
- **R3 plus R4 together.** Treat it as Best Case until the person who signs has been in the deal.

## What these rules cannot tell you

- **They are correlation.** Deals that go quiet also lose more often, and the quiet may be a symptom.
  Ask what happened. The rule only tells you where to look.
- **The data is vendors' own.** Ebsta and Gong publish their samples, but not their full methods.
- **Your sales motion may differ.** After two quarters, `forecast-calibration-check.md` replaces
  these numbers with yours.

## Sources

- Ebsta and Pavilion, B2B Sales Benchmarks 2024 (4.2 million opportunities, 530 companies).
  https://www.ebsta.com/ebsta-pavilion-b2b-sales-benchmarks-2024/
- Gong Labs, Selling to Decision Makers and How it Impacts Win Rates (9,056 opportunities, 2020).
  https://www.gong.io/resources/labs/heres-how-selling-to-decision-makers-affects-your-win-rates-ignore-at-your-own-risk/
- Gong Labs, Silence is golden, unless it's your buyer (120 million+ sales calls, 2026).
  https://www.gong.io/blog/silence-is-golden-unless-it-s-your-buyer
- Winning by Design, SPICED. https://winningbydesign.com/spiced/
- MEDDICC, Economic Buyer and Paper Process. https://meddicc.com/what-is-meddpicc/paper-process
- Douglas Hubbard, How to Measure Anything, 3rd edition (2014), on calibrated estimates.
