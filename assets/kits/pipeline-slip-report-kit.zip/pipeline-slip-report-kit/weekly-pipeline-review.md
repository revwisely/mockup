# Weekly pipeline review

Part of the Magnetiz Pipeline Review implementation kit.

Run this every week, before the forecast call. It takes every deal in Commit or Best Case, checks it
against the rules in `slip-rules.md`, and puts the flagged deals first.

## The run

1. Pull every open deal in Commit or Best Case that closes this quarter.
2. Check each one against R1 to R7, using the fields in `deal-evidence-fields.md`.
3. List every flagged deal in the table below, most flags first, then largest amount.
4. Write one question per flagged deal, from the flag the owner can answer with evidence soonest. Ask what happened, never who failed.
5. Send the report to the deal owners a day before the forecast call, so they come with answers.
6. In the call, go through the flagged deals first. Unflagged deals need no discussion.
7. After the call, apply the moves from `slip-rules.md` and record them in the last column.

## The report

Week of

| Deal | Owner | Amount | Category | Close date | Flags | The evidence | Question for the owner | Owner's answer | Category after the call |
|---|---|---|---|---|---|---|---|---|---|
| | | | | | | | | | |
| | | | | | | | | | |
| | | | | | | | | | |
| | | | | | | | | | |
| | | | | | | | | | |

## The question for each flag, pick one per deal

| Rule | Ask |
|---|---|
| R1 | What has to happen for this deal to move to the next stage, and when is that booked? |
| R2 | When did we last hear from them, and what is the next meeting on the calendar? |
| R3 | What changed on their side when the date moved, and what makes the new date real? |
| R4 | Who signs, and when do they join a conversation with us? |
| R5 | Who else on their side knows about this deal and wants it? |
| R6 | What happens on their side if they do not decide by the close date? |
| R7 | What happens between their yes and a signature, step by step, and who owns each step? |

## The totals line

Write these at the bottom of every report. The same numbers every week are what make a quarter of
reports comparable.

| Commit total before the call | Commit total after the call | Deals flagged | Deals moved out of Commit | Deals that cleared a flag with evidence |
|---|---|---|---|---|
| | | | | |
