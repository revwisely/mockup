# Routing read

Part of the Magnetiz Lead Routing implementation kit.

Run this once a week, and once a month with the outcome columns. It answers one question. Is the
routing working?

## Write the rule before the first read

Decide what "working" means before you see a number. Fill in the blanks.

- **Working.** At least ___% of qualified leads touched inside the time limit, no lead without an
  owner at the end of any day, and the gap in `landed-lead-check.md` fully explained each day.
- **Needs a fix.** One of those missed for two weeks running. Name the lane and the cause.
- **Stop and repair.** A lead sat in the gap with no explanation. Routing changes wait
  until the path is fixed.

## The weekly read

| Measure | This week | Last week | Your target |
|---|---|---|---|
| Leads counted at the source | | | |
| Leads that reached the CRM | | | |
| Routed by the rules, no person needed | | | |
| Sent to review | | | |
| Median time from arrival to first touch, qualified lane | | | |
| Qualified leads touched inside the limit | | | |
| Leads with no active owner at any day's end | | | 0 |
| Review queue, oldest item in days | | | |
| Routes a person changed | | | |

## Read it by lane

A total hides the lane that is failing. Break the week out.

| Lane | Leads | Routes changed by a person | Median time to first touch | Note |
|---|---|---|---|---|
| Qualified | | | | |
| Nurture | | | | |
| Monitor | | | | |
| No fit | | | | |
| Review | | | | |

## The monthly read, by outcome

Routing earns trust on what happened next. Once a month, join each route to its result.

| Lane | Leads | Meetings held | Opportunities | Won | Lost |
|---|---|---|---|---|---|
| Qualified | | | | | |
| Nurture | | | | | |
| Monitor | | | | | |
| No fit | | | | | |
| Review, sent on to sales | | | | | |

Three things to look for.

- **Meetings from nurture, monitor or no fit.** Each one is a lead the rules ranked too low. Open
  the brief and find which signal missed.
- **Qualified leads that never got a meeting.** Either the band is too generous or the follow-up is
  slow. The time-to-first-touch row tells you which.
- **Small numbers.** When a lane holds only a handful of leads, read the individual leads and not
  the rate.

## What changes the rules

Rules change at this read and nowhere else. Each change gets one line.

| Date | What changed | The evidence | Who decided | Check again on |
|---|---|---|---|---|
| | | | | |
