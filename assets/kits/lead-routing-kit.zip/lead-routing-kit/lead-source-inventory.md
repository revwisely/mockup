# Lead source inventory

Part of the Magnetiz Lead Routing implementation kit.

Fill this in before you write a single rule. It answers one question. Where can a lead come in, and
where is it supposed to end up?

## Why this sheet comes first

Routing rules only act on leads that reach them. Most teams can name their main form. Few can list
every door, and the doors left off the list are where leads go missing.

## List every door

Walk the site and the tools, and write down every place a person can raise a hand. Include the ones
that feel minor.

| # | Source | Example | Counted here (the source of truth) | Lands in the CRM as | How it gets there | Owner of the connection |
|---|---|---|---|---|---|---|
| S1 | Demo or contact form | /demo | the form tool's own submission log | contact + open task | native form | |
| S2 | Resource or kit form | /guide | | | | |
| S3 | Chat | site chat widget | | | | |
| S4 | Meeting booking | scheduling link | | | | |
| S5 | Product sign-up | trial or free plan | | | | |
| S6 | Shared inbox | sales@, info@ | | | | |
| S7 | Event or list upload | webinar attendees | | | | |
| S8 | Partner or referral | intro email | | | | |
| S9 | | | | | | |

## The two columns that matter most

**Counted here.** Every source needs one place that records the lead before anything else touches
it. The form tool's submission log, the scheduler's booking list, the inbox itself. This is the count
you will check the CRM against in `landed-lead-check.md`. A source with no count of its own cannot be
checked, so fix that first.

**How it gets there.** Write the real path, hop by hop. Form, then a connector, then the CRM, then a
workflow, then an owner. Every hop is a place a lead can stop without an error.

## Mark the fragile ones

Put a mark beside any source where one of these is true.

- A third-party connector sits between the source and the CRM.
- The path was built by someone who has left.
- The source changed in the last 90 days (a new form, a new domain, a new tool).
- The person named as owner did not know they owned it.

Fragile sources get checked daily in `landed-lead-check.md`. The rest can be checked weekly.

## What good looks like

- Every source has a row, a count of its own, and a named owner of the connection.
- The list is dated. Re-walk it each quarter and whenever the site or a tool changes.
- A new form does not go live until it has a row here.
