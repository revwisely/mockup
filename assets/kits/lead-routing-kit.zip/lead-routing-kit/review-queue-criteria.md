# Review queue criteria

Part of the Magnetiz Lead Routing implementation kit.

When the evidence cannot decide, a person does, with the reasons in front of them. A review queue
that is always empty means the rules are guessing.

## What goes to review (any one is enough)

1. **Conflicting evidence.** The form names one company and the email domain names another.
2. **Close to a band edge.** Within [5] points of an edge on either score.
3. **An unclear duplicate.** Same domain and a different person, or names that nearly match.
4. **Identity that cannot be verified.** Two or more fit signals scored null.
5. **Anything the enrichment step marked low confidence.**

## What each queued lead carries

The brief, the specific reason it queued (never just "review"), and the two most likely calls with
what each one means.

## Rules for the queue

- Record every review decision with its reason. These are the evidence for the next band review.
- Empty the queue on a schedule. Daily at volume, weekly early on. A lead waiting in a stale queue
  may have been qualified.
- Three leads queued for the same reason is a rule waiting to be written.

## Moving a lane to unattended routing

Every lane starts supervised. The router proposes, a person confirms, and nothing routes on its own.
Lanes graduate one at a time, because they fail in different ways.

| Lane | Clean passes in a row before it runs unattended | Graduated on | By |
|---|---|---|---|
| Qualified | [20] | | |
| Nurture | [20] | | |
| Monitor | [20] | | |
| No fit | [50] | | |

A **clean pass** is one routed lead the confirming person agreed with, route unchanged. A changed
route sets that lane's count back to zero.

**No fit graduates last and needs about twice the streak.** A lead wrongly marked qualified wastes
a rep's time and somebody sees it. A buyer wrongly marked no fit is served politely and never
followed up, and no report will show it happened.

**Graduation can be reversed.** Three route corrections in a lane inside [30] days puts it back
under supervision.
