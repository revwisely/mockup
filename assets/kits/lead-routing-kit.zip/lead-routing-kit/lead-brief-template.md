# Lead brief template

Part of the Magnetiz Lead Routing implementation kit.

One screen. What was verified, what could not be, and where each fact came from. The router and the
person reviewing read the same brief.

---

## [Person name], [Company]

**Asked for.** [what they requested, word for word] · came in through [source, from the inventory]
**Date.** [date] · **Duplicate check.** [no match | matched an existing record, with the link]

### Verified (every line carries a source)

| Claim | Evidence | Source | Date |
|---|---|---|---|
| Role | | | |
| Company, size, model | | | |
| Anything they told us, word for word | | | |

### Could not verify

- [the unknowns, written as unknowns and never guessed]

### Scores

Fit [ ] of 50 because [one line]. Intent [ ] of 50 because [one line].

### Decision

Route. [qualified | nurture | monitor | no fit | review] · Reason. [one line]
Owner. [name] · Next step. [action] by [date]
