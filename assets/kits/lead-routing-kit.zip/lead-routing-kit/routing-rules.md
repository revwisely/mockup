# Routing rules

Part of the Magnetiz Lead Routing implementation kit.

The band table in `qualification-rules.md` decides the route. This sheet covers what each route does
once it is decided, and who ends up holding the lead.

## What each route does

| Route | What happens | Time limit |
|---|---|---|
| Qualified | Named owner assigned, dated next step, brief attached, alert sent | owner acts within [1 business day] |
| Nurture | Added to marketing emails. Nothing manual | re-scored on new activity |
| Monitor | Watched. Re-scored on return visits | none |
| No fit | The thing they asked for, delivered politely. Nothing else | immediate |
| Review | Queued for a person with the reason attached (`review-queue-criteria.md`) | decided within [1 business day] |

## Check for a duplicate before anything is created

1. Match on email, then on company domain, against existing contacts, accounts and open deals.
2. A match updates the existing record and alerts its owner. It never creates a second record.
3. An unclear match (same domain, different person) goes to review with both records linked.

## Assignment

Write the assignment rules in the order they are checked. The first match wins.

| Order | Rule | Assign to | Your version |
|---|---|---|---|
| 1 | The account already has an owner | that owner | |
| 2 | An open deal exists at the company | the deal owner | |
| 3 | A named-account list covers the company | the list's owner | |
| 4 | Territory or segment (region, size band, industry) | the segment's owner | |
| 5 | None of the above | round robin among people who agreed to the time limit | |
| 6 | Nothing matched, or the matched owner is inactive | the fallback owner, by name | |

**Rule 6 is the one teams skip.** Without a named fallback, a lead that matches no rule gets no
owner and no alert. Name one person. Check that they still work here each quarter.

## The alert

- It goes to the channel the team already reads.
- It carries the brief (`lead-brief-template.md`), never a bare "new lead" line.
- It names the owner and the time limit.

## If an AI model helps

A model can read the form text, summarize the company and propose a score. The route and the owner
are set by the rules above, in code or in the CRM's own workflow. A model's proposal is one input.
It never assigns a lead on its own.

## The no-fit rule

Students, recruiters and vendors get what they asked for and never enter a sales sequence. Serving
them politely costs nothing, and it protects the list and the sending domain.
