# Qualification rules

Part of the Magnetiz Lead Routing implementation kit.

This sheet decides what a lead is before anything decides where it goes. It keeps two scores apart.
Fit scores who they are. Intent scores what they did.

## Fit (0 to 50), who they are

| Signal | Points | Your calibration |
|---|---|---|
| Role matches your buyer (write the titles down) | 0 to 20 | |
| Company shape matches (size band, industry, model) | 0 to 20 | |
| Real, reachable identity (work email, a company that resolves) | 0 to 10 | |

## Intent (0 to 50), what they did

| Signal | Points | Your calibration |
|---|---|---|
| What they asked for (a demo, pricing and a guide weigh differently) | 0 to 15 | |
| Return visits and depth (pages, time, repeats) | 0 to 15 | |
| Stated interest in their own words (form fields, chat, replies) | 0 to 20 | |

## Unknown is a value

**A signal you could not verify scores null. It never scores zero.** Zero means you checked and the
answer was bad. Null means you could not check.

A free email address with no company found is nulls on the fit side. It is never a low fit score.
**Two or more nulls among the fit signals send the lead to review**, whatever the intent side says.

That makes monitor and review two different lanes.

- **Monitor** is high intent with fit known to be low. A scraper with 40 page views. You can see who
  it is, and who it is does not buy.
- **Review** is high intent with fit unknown. A visitor on a personal email who read for nine
  minutes. A person decides, because the evidence cannot.

## Bands, checked in this order

Two people must get the same route from the same rules. So the checks run top to bottom and the
first match wins.

| Order | Band | Condition | Route |
|---|---|---|---|
| 1 | Review | 2 or more fit nulls, conflicting evidence, an unclear duplicate, or within [5] points of a band edge | a person decides, with the reasons attached |
| 2 | Qualified | fit at least [ ] and intent at least [ ] | a named owner and a dated next step |
| 3 | Nurture | fit at least [ ] and intent below [ ] | marketing emails, no sales outreach |
| 4 | Monitor | intent at least [ ] and fit known low | watched, never sold to |
| 5 | No fit | fit below [ ], known | they get what they asked for and nothing else |

## Intent gets old

Intent signals older than [90] days count for half. Older than [180] days they expire. A second
visit eleven months later is a new first visit.

## Four rules that keep the scores honest

1. **A download alone is a request for a resource.** Score it as that.
2. **Never add the two scores into one number.** A scraper has intent without fit, and only the
   split catches it.
3. **Bands change at a scheduled review, never for one lead.** Moving a band to qualify a lead you
   like is how the model stops meaning anything.
4. **Null stays null.** Scoring an unknown as bad removes the review lane, and that lane holds the
   leads worth a second look.
