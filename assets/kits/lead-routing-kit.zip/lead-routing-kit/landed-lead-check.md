# Landed lead check

Part of the Magnetiz Lead Routing implementation kit.

Run this every business day once routing is live. It answers one question. Did every lead that came
in yesterday reach a person?

## Why routing needs its own check

A routing failure rarely shows an error. A form tool files submissions as spam. A connector returns
success and creates no record. A workflow assigns a lead to someone who left in March. The dashboard
shows a quiet week, and a quiet week looks the same as a broken path.

The fix is to stop trusting the CRM's own count. Count leads where they were first recorded, count
them again where they should have landed, and compare.

## The five places a lead can stop

| # | Where it stops | What it looks like | How to see it |
|---|---|---|---|
| 1 | At the source | the form tool holds or filters the submission (spam, a failed validation, a consent box) | read the source's own log, including its spam or held folder |
| 2 | Between tools | the connector reports success and the CRM has no record | compare the source count with the CRM count |
| 3 | In the CRM, no route | the record exists and no rule matched it | list records created yesterday with no route value |
| 4 | Routed, no owner | a route is set and the owner is blank or inactive | list routed records with no active owner |
| 5 | Owned, untouched | an owner is set and nothing has happened inside the time limit | list qualified records past the limit with no logged activity |

## The daily read

Fill one row per source from `lead-source-inventory.md`. Fragile sources every day, the rest weekly.

| Source | Counted at the source | Held or spam at the source | In the CRM | Routed | Has an active owner | Touched inside the limit | Gap |
|---|---|---|---|---|---|---|---|
| S1 | | | | | | | |
| S2 | | | | | | | |
| S3 | | | | | | | |

**Gap** is the source count minus the number touched inside the limit. Every lead in the gap gets a
name and a reason before the read is closed.

## Three rules for reading it

1. **Count at the source first.** If the first number you look at is the CRM's, you are checking the
   CRM against itself.
2. **Read the held folder every time.** A real lead filed as spam is still a lead at the source and
   absent everywhere else.
3. **A zero is a finding until explained.** A source that normally sends leads and sent none gets
   one test submission the same day. Write down the normal range for each source so a zero stands out.

## The test lead

Once a week, and after any change to a form, a domain or a connected tool, submit one test lead
through each fragile source. Use an address that marks it as a test.

| Source | Test sent | Seen at the source | In the CRM | Routed | Owner alerted | Minutes, end to end | Cleaned up |
|---|---|---|---|---|---|---|---|
| | | | | | | | |

A test that takes longer than the time limit is a failure, even if it arrives.

## When the check finds a missing lead

1. Recover the lead by hand first. Route it and tell the owner it is late and why.
2. Find which of the five places it stopped.
3. Write the cause in one line and add a check that would have caught it.
4. Look back as far as the cause goes. If the path broke two weeks ago, every lead from those two
   weeks is in the gap.

## The alert worth building

When the daily read is steady, automate the comparison. Send one message a day to the channel the
team reads, with the source count, the CRM count and the names in the gap. Send it on quiet days as
well. A check that only speaks when something breaks cannot be told apart from a check that stopped
running.

## What this sheet cannot tell you

It shows that a lead reached a person inside the limit. It does not show that the route was the
right one. That is what `routing-read.md` reads.
