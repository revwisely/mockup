# Sample leads and the answer key

Part of the Magnetiz Lead Routing implementation kit.

Every company, person and number on this sheet is invented. Run the five leads through your rules
before any real one. Then read the sample day, which shows the landed lead check finding a miss.

## Five sample leads

1. **The potential customer.** jordan@meridianops.example asks for a demo. Source S1. The company
   resolves to a 140-person logistics software firm. The profile reads VP Operations. Second visit
   in a week.
2. **The recruiter.** talent@peakstaffing.example downloads a guide. Source S2. The company resolves
   to a staffing agency. The profile reads Technical Recruiter.
3. **The student.** a.chen@stateuniversity.example downloads a guide. Source S2. No company. The
   profile shows a graduate program.
4. **The unknown.** rt.factor@freemail.example asks for pricing in chat. Source S3. Free email, no
   company found, no profile match. One visit, eight pages, nine minutes.
5. **The scraper.** research@dataharvest.example downloads a guide. Source S2. The company resolves
   to a data aggregation service. Forty pages in under two minutes.

## The answer key

| Lead | Fit | Intent | Route | The call, stated |
|---|---|---|---|---|
| Customer | high | high | **Qualified** | Role and company verified. A demo request plus a return visit inside a week. Owner and a dated step |
| Recruiter | low | low to medium | **No fit** | A real person in the wrong lane. Guide delivered, no sequence |
| Student | low | low | **No fit** | Serve the guide gladly and stop there |
| Unknown | null on two fit signals | high | **Review** | Nine minutes of reading with no identity. Nulls send it to a person. The failures are sending it to sales and throwing it away |
| Scraper | low, and known | high by volume | **Monitor** | Forty pages in two minutes is a machine. Fit is known low because the company resolved |

Different wording is fine. A different route is a failure to fix before go-live.

**The unknown and the scraper are the pair to study.** Both show high activity. One goes to a
person and one goes to monitor, and the only difference is whether fit is null or known low. Score
an unverified fit as zero and the unknown lands in monitor, where a real buyer on a personal email
goes unseen.

## A sample day, read with the landed lead check

Northgate Freight Software (invented) runs three sources. This is Tuesday's read of Monday.

| Source | Counted at the source | Held or spam at the source | In the CRM | Routed | Has an active owner | Touched inside the limit | Gap |
|---|---|---|---|---|---|---|---|
| S1 demo form | 6 | 2 | 4 | 4 | 3 | 3 | 3 |
| S2 guide form | 11 | 0 | 11 | 11 | 11 | 11 | 0 |
| S3 chat | 0 | 0 | 0 | 0 | 0 | 0 | 0 |

The CRM dashboard showed 15 new leads, all routed. It looked like a normal Monday.

**What the read found.**

- **S1, two held at the source.** Both sat in the form tool's spam folder. One was a real demo
  request from a 200-person company. The site had moved to a new domain the week before, and the
  form tool had started filtering submissions from it. Stopped at place 1.
- **S1, one routed with no active owner.** The territory rule assigned it to a rep who left last
  month. No fallback owner was named. Stopped at place 4.
- **S3, a zero.** Chat normally sends two to five leads a day. A test message showed the chat widget
  had lost its connection to the CRM after a plugin update. Stopped at place 2.

**What changed.**

1. The two real leads were routed by hand that morning, with a note that they were a day late.
2. The form tool's spam folder went on the daily read as its own column.
3. A fallback owner was named in rule 6 of `routing-rules.md`.
4. The look-back for S1 went to the day of the domain move. It found three more held submissions.

None of the three failures produced an error, and the CRM's own count was correct for the records
it held. The source count is what showed them.
