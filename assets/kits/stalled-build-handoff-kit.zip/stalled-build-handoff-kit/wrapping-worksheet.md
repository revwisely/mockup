# The Stalled-Build Handoff — the wrapping worksheet

Part of the Magnetiz Stalled-Build Handoff implementation kit. This is step 05, between
picking the doorbell and transferring ownership. The audit told you what exists and the
runnable definition told you what "runnable" has to mean. This decides what you build
over the top of it, and more importantly what you leave alone.

**The stalled build is the asset.** It already encodes decisions nobody wrote down and
edge cases nobody remembers hitting. Wrapping preserves that; rebuilding gambles it on
the belief that you understand a system whose original author is gone. You do not, yet.

## 1. Draw the line before you write anything

| | |
|---|---|
| What the build already does correctly, untouched | |
| What the wrapper adds | |
| What is deliberately NOT being fixed in this pass | |

The third row is the one that keeps this honest. A wrapping pass with nothing in it is a
rebuild that has not admitted itself yet.

## 2. Slice it, and ship the smallest one first

The audit's honest columns give you the order. Something that **runs** needs only a way
to start it. Something **manual** needs the manual step wrapped. Something **broken**
gets deferred unless the owner cannot work without it.

| Slice | What it makes runnable | Depends on | Ship order |
|---|---|---|---|
| | | | 1 |
| | | | 2 |
| | | | 3 |

Slice 1 ships alone, gets used by the named owner for [one week], and earns slice 2.
The point is not caution for its own sake. A slice nobody used is a slice whose
assumptions are still unverified, and stacking a second one on top of it doubles what
you will have to unpick when the first turns out to be wrong.

## 3. Every change reversible, one at a time

| Change | How to undo it | Undo tested on |
|---|---|---|
| | | |

An undo you have not run is a plan, not a rollback. Test it once, on purpose, while
nothing is wrong.

## 4. The four rules

1. **Wrap around, never edit inside**, until the owner has run it unassisted. Editing
   the build's internals during a handoff means a failure has two possible causes and
   the new owner cannot tell which, on the exact day their confidence is most fragile.
2. **A rewritten component needs a written reason and the previous version kept.** Some
   things genuinely have to be replaced. That is a decision worth recording, not a thing
   that happens quietly inside a wrapping pass.
3. **If the wrapper is bigger than what it wraps, stop.** You are rebuilding. That may
   be the correct call, but it is a different project with a different budget and a
   different risk, and it should be chosen rather than arrived at.
4. **The owner uses each slice before the next one is built.** Not reviews it. Uses it,
   for real work, unassisted.

## 5. Done when

- [ ] The named owner launched it unassisted, against the runnable definition
- [ ] Every baseline in `runnable-definition.md` was captured after wrapping
- [ ] Nothing inside the original build was edited, or every edit has a written reason
- [ ] Every change has an undo that was actually run
- [ ] The deliberately-not-fixed list is written down and the owner has seen it

The last box matters most at the handoff meeting. An owner who knows what is unfinished
can work around it. An owner who discovers it alone at 6pm concludes the thing is
broken, and that is how a build stalls the second time.
