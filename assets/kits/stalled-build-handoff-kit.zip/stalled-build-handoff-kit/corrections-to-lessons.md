# Stalled-Build Handoff — the corrections-to-lessons spec

Part of the Magnetiz Stalled-Build Handoff implementation kit. This is the mechanism
behind the kit's central promise: the owner comments in plain language, the system files
the note as a lesson, and no prompt engineering is asked of anyone. Fill the brackets
once; the runbook points here.

## 1. Where corrections land

Comments go where the OUTPUT lands, never in a separate tool. A thread on the Slack
message, a comment on the doc, a note on the CRM record. The owner corrects the thing
they are looking at, in the words they would use to a colleague.

| Question | Your answer |
|---|---|
| Where does output land (from the doorbell guide) | |
| What the owner does to correct it (reply / comment / emoji + reply) | |

## 2. What reads the corrections

Name the collector. A scheduled job, an agent step, or a person on a cadence, reading
the correction surface and filing each note into the lessons store.

| Question | Your answer |
|---|---|
| What picks corrections up, and how often | |
| Where lessons are stored (a file, a prompt section, a table) | |

## 3. How the system confirms what it learned

Every filed lesson gets confirmed IN THE THREAD it came from, restated in the system's
own words. "Filed: regional splits always list Canada separately." The restatement is
the check — if the confirmation misstates the lesson, the owner corrects the correction,
in the same thread.

## 4. How a wrong lesson gets rolled back

Lessons are entries with dates, never edits to something unversioned. Each one records
the words it came from and the date it took effect. Rolling one back is deleting or
countermanding the entry, in one step, and the runbook's history table records that too.

## The two rules

1. **Corrections are lessons, never configuration.** The moment fixing behavior requires
   editing a prompt by hand, the promise is broken. Route that need back to whoever
   maintains the internals.
2. **A lesson the system cannot restate is a lesson it did not learn.** The confirmation
   step is load-bearing, not politeness.
