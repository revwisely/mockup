# Stalled-Build Handoff — the doorbell decision guide

Part of the Magnetiz Stalled-Build Handoff implementation kit. The front end is a door,
never the house. Name the buyer's own door.

## The rule

Your team already opens some tool every morning. That tool is the front end. Slack shops
get a Slack front end. Microsoft shops get Teams. A team that lives in the CRM gets a
button in the CRM. The requirement is constant while the door varies: anyone can run it,
without watering down what it does.

## The decision, in three questions

| Question | Answer |
|---|---|
| What tool does the owner already have open all day | |
| Where does the OUTPUT need to land so others see it without being told | |
| What is the smallest trigger surface (a slash command, a button, a form, an email address) | |

## What a doorbell must carry (and nothing more)

1. **Run it.** One action starts the workflow with sane defaults.
2. **See it.** The result arrives where the team already reads, with its receipts.
3. **Correct it.** The owner comments in plain language; the note becomes a lesson.

## The two failures to refuse

- **The new tool.** A front end that asks the team to learn new software is a second
  stalled build waiting to happen.
- **The dashboard.** A page someone must remember to visit is not a door. Doors ring.
