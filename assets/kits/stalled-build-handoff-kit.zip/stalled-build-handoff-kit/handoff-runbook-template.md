# Runbook — [workflow name]

Part of the Magnetiz Stalled-Build Handoff implementation kit. Copy this file, fill every
bracket, and keep it where the work happens (the channel, the CRM, the wiki your team
actually opens). A runbook in a folder nobody visits is a note to nobody.

## What this workflow does

[One paragraph. What goes in, what comes out, who reads the output.]

## Owner

[Name]. Backup: [name]. The owner runs it, judges output, and files corrections.

## How to run it

1. [The trigger, exactly. Where to click or type, with the words to use.]
2. [What happens next and how long it takes.]
3. [Where the output lands and what a PASSING result looks like, with an example.]

## When it goes quiet

[How the system reports its own failure, and where.]

## The two most likely failures

| Symptom | Cause | Fix, step by step |
|---|---|---|
| | | |
| | | |

## How to teach it

Comment on any output in plain language. [Where corrections go and what picks them up.]
Corrections are lessons, never complaints. The system confirms what it learned.

## What never runs unattended

[The actions that always wait for a person, whatever the workflow proposes.]

## History

| Date | What changed | Who |
|---|---|---|
| | Handoff completed; owner ran end to end unassisted | |
