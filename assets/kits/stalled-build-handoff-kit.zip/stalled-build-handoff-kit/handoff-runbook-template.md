# Runbook — [workflow name]

Part of the Magnetiz Stalled-Build Handoff implementation kit. Copy this file, fill every
bracket, and keep it where the work happens (the channel, the CRM, the wiki your team
actually opens). A runbook in a folder nobody visits is a note to nobody.

## What this workflow does

[One paragraph. What goes in, what comes out, who reads the output.]

## Owner

[Name], [N] hrs/week. Backup: [name], who has run it end to end (date: ______).
Internals owner (fixes what this runbook cannot): [name, or "none — the failure table
below is the whole safety net; anything outside it is stop-and-reassess"].

## How to run it

1. [The trigger, exactly. Where to click or type, with the words to use.]
2. [What happens next and how long it takes.]
3. [Where the output lands and what a PASSING result looks like, with an example.]

## When it goes quiet

[How the system reports its own failure, and where.]

## The two most likely failures

| Symptom | Cause | Fix, step by step |
|---|---|---|
| | | |
| | | |

## How to teach it

Comment on any output in plain language, where the output landed. The full mechanism —
what picks corrections up, where lessons live, how the system confirms each one in the
thread, and how a wrong lesson rolls back — is `corrections-to-lessons.md`, filled in
for this workflow. Corrections are lessons, never complaints.

## What never runs unattended

[The actions that always wait for a person, whatever the workflow proposes.]

## Versioning (what "reversible" means here)

Every wrapper change is a dated version (a git commit, or a dated copy of the config
and prompts). Rolling back is restoring the prior version, and the history table
records both directions.

## History

| Date | What changed | Who |
|---|---|---|
| | Handoff completed; owner ran end to end unassisted | |
| | Backup proving run | |
| | Re-prove (quarterly or owner change) | |
