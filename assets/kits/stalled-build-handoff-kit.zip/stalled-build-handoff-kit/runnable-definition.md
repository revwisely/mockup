# Stalled-Build Handoff — the runnable definition

Part of the Magnetiz Stalled-Build Handoff implementation kit. Write the acceptance bar
BEFORE wrapping anything. "Runnable" defined after the work always drifts down to
whatever got built.

## The acceptance bar (all four, none negotiable)

1. **The owner launches it unassisted**, from the tool they already use, without asking
   anyone how.
2. **The owner knows what good output looks like** and can say why a given run passed or
   failed.
3. **The owner can recover the two most likely failures** using the runbook alone.
4. **The run is observable.** When it goes quiet, the owner finds out from the system,
   never from a customer.

## Baselines (capture NOW, before the revival)

| Metric | Before value | Date measured | After value | Date |
|---|---|---|---|---|
| Hours per week the manual version costs | | | | |
| The number the build moves (replies, meetings, time in stage) | | | | |
| How often the work happens at all today | | | | |

The revival gets proven against these numbers. An unproven revival stalls again the next
time attention moves, because nobody can say what it earns.

## What "watered down" means (the failure to refuse)

The buyer's bar, in their words: anyone can run it, without watering down the power of
what it is doing. A wrapper that only exposes the easy 20% fails this bar. The owner runs
the REAL capability through a simple door, and the door is the only thing that got simpler.
