# Stalled-Build Handoff — the owner checklist

Part of the Magnetiz Stalled-Build Handoff implementation kit. No named owner means the
revival does not start. It is the strongest kill signal in the record, and naming one is
a management decision no workflow can make.

## Naming the owner

- [ ] One person, by name. A team is not an owner.
- [ ] **Capacity, in numbers.** [ ] hours per week, and what they are dropping to make
      room: ______________________. An owner with no hours is a name, not an owner, and
      a manager who cannot name what moves off the plate has not actually decided.
- [ ] They agreed. Assigned-without-asking owners produce shelfware politely.
- [ ] Their manager knows this is part of the job now, so the hours survive a busy month.
- [ ] **A backup, by name, who will run it at least once during the handoff:** ________

## The internals question (answer it honestly, in writing)

The builder who left took the internals knowledge with them. So who fixes what the
runbook cannot?

- Internals owner: [name, or "none"]
- **If "none":** the wrapper must cover every failure the owner can realistically hit,
  and the runbook's failure table is the whole safety net. Say so in the runbook, size
  the failure table accordingly, and treat any failure outside it as a stop-and-reassess,
  never a muddle-through.

## What the owner is signing up for

- Run the workflow on its cadence, and judge its output.
- File corrections as plain-language comments where the output lands
  (`corrections-to-lessons.md` is the mechanism).
- Escalate what the runbook cannot fix, to the named internals owner above.
- Keep the runbook true. A runbook that drifted is a runbook that lies.

## What the owner is NOT signing up for

- Prompt engineering. If the system needs prompt skills to operate, the wrapper is not
  finished.
- Debugging the internals. That goes to the named internals owner, and if there is
  none, see the internals question above.
- Being the only person who knows. The backup exists, and the proving run below makes
  that a verified fact rather than a sentence.

## The proving run (all six, each with a date)

- [ ] The owner ran the workflow end to end, unassisted, from the doorbell. Date: ______
- [ ] The output passed, and the owner said why in their own words. Date: ______
- [ ] One failure was simulated, and the owner recovered it with the runbook alone.
      Date: ______
- [ ] **Silence was simulated** (a run suppressed or fed nothing), and the owner found
      out from the system, never by noticing the absence. Date: ______
- [ ] **The backup ran it end to end, unassisted.** Date: ______
- [ ] One correction was filed as a comment, and the system confirmed the lesson in the
      thread. Date: ______

## Re-proving (a handoff is a state, never a ceremony)

The handoff goes stale silently, which is how the build stalled the first time. Re-run
the proving run's first check **every [quarter], or on any owner or backup change,
whichever comes first**, and date it in the runbook history. A missed re-prove is the
early warning, and it costs twenty minutes.
