# Stalled-Build Handoff — the owner checklist

Part of the Magnetiz Stalled-Build Handoff implementation kit. No named owner means stop.
It is the strongest kill signal in the record, and naming one is a management decision no
workflow can make.

## Naming the owner

- [ ] One person, by name. A team is not an owner.
- [ ] They have capacity, on the record. An owner with no hours is a name, not an owner.
- [ ] They agreed. Assigned-without-asking owners produce shelfware politely.
- [ ] Their manager knows this is part of the job now, so the hours survive a busy month.

## What the owner is signing up for

- Run the workflow on its cadence, and judge its output.
- File corrections as plain-language comments where the output lands.
- Escalate what the runbook cannot fix, to a named second contact.
- Keep the runbook true. A runbook that drifted is a runbook that lies.

## What the owner is NOT signing up for

- Prompt engineering. If the system needs prompt skills to operate, the wrapper is not
  finished.
- Debugging the internals. That stays with whoever maintains the build.
- Being the only person who knows. The backup exists and has run it at least once.

## The proving run

- [ ] The owner ran the workflow end to end, unassisted, from the doorbell.
- [ ] The output passed, and the owner said why in their own words.
- [ ] One failure was simulated, and the owner recovered it with the runbook alone.
- [ ] The run has a date: __________. That date is when "handed off" became true.
