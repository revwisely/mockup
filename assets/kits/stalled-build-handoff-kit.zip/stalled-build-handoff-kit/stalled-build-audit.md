# Stalled-Build Handoff — the audit worksheet

Part of the Magnetiz Stalled-Build Handoff implementation kit. Fill this before touching
anything. Most stalled builds are closer to alive than anyone remembers; the audit proves
which parts, honestly.

## 1. The build, named (the first row is a precondition)

| Question | Your answer |
|---|---|
| **Is there a candidate owner with hours?** If no, STOP HERE. The revival does not start, the rest of this audit can wait, and naming one is the decision to make first | |
| What was the build supposed to do, in one sentence | |
| Who built it (person or vendor), and are they reachable | |
| When did it last produce useful output | |
| Where does it live (repo, platform, account) and who has access | |
| **Credentials.** Which accounts, tokens, or keys belonged to the person who left, and which have expired or been deprovisioned. This is the most common literal cause of a build that stopped when its builder did | |
| What it costs to run per month (API usage, hosting, licenses) | |

## 2. The three columns

List every piece of the build in exactly one column.

| Still runs on its own | Runs with a human hand on it | Broke — when, and WHY |
|---|---|---|
| | | |
| | | |
| | | |

## 3. The honest reading

- The "still runs" column is the asset. Wrapping it beats rebuilding it.
- The "human hand" column is the handoff's real scope. Each row asks who supplies the
  hand today and whether the wrapper can absorb it.
- The "broke" column gets a date AND a why. The why is the decision-relevant fact. A
  thing that broke last week is a repair; a thing that died six months ago for a reason
  nobody wrote down is a question before it is a project.
- **The threshold, stated plainly.** An empty "still runs" column means this is not a
  revival. It is a rebuild decision, and a different conversation.

## The rule that keeps the audit honest

The audit describes. It never pitches. If the audit is turning into an argument for a
rebuild, stop and ask what the rebuild would preserve from the columns above. Reviving
beats rebuilding until the columns prove otherwise.
