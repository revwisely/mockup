# Stalled-Build Handoff — the audit worksheet

Part of the Magnetiz Stalled-Build Handoff implementation kit. Fill this before touching
anything. Most stalled builds are closer to alive than anyone remembers; the audit proves
which parts, honestly.

## 1. The build, named

| Question | Your answer |
|---|---|
| What was the build supposed to do, in one sentence | |
| Who built it (person or vendor), and are they reachable | |
| When did it last produce useful output | |
| Where does it live (repo, platform, account) and who has access | |

## 2. The three columns

List every piece of the build in exactly one column.

| Still runs on its own | Runs with a human hand on it | Broke, and when |
|---|---|---|
| | | |
| | | |
| | | |

## 3. The honest reading

- The "still runs" column is the asset. Wrapping it beats rebuilding it.
- The "human hand" column is the handoff's real scope. Each row asks who supplies the
  hand today and whether the wrapper can absorb it.
- The "broke" column gets dated. A thing that broke last week is a repair. A thing that
  broke six months ago may have died for a reason worth knowing before reviving it.

## The rule that keeps the audit honest

The audit describes. It never pitches. If the audit is turning into an argument for a
rebuild, stop and ask what the rebuild would preserve from the columns above. Reviving
beats rebuilding until the columns prove otherwise.
