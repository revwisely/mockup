# Research questions

Part of the Magnetiz Account Research implementation kit.

Fill this in before any account is researched. It answers one question. What will someone do with
the brief?

## Why the questions come first

Account research with no decision behind it grows until it fills the time available. A model asked to
"research this company" returns a company profile, and most of a company profile changes nothing a
seller does. Pick the decision first. Then write only the questions whose answers could change it.

## Pick the decision

One brief serves one decision. Tick one. If you need two, write two question sets.

| Decision | Who makes it | What a good brief changes |
|---|---|---|
| Should we work this account at all | the person who owns the account list | the account moves up, down or off the list |
| What should the first message be about | the seller or the outreach owner | the message opens on something the account said about itself |
| What do I need to know before this call | the seller running the call | the first three questions of the call |
| Who else has to be in this deal | the seller and their manager | the people added to the account plan |

## Write the questions

Six to eight. Each one has to pass three tests before it goes on the list.

1. **A public page could answer it.** If the answer only exists inside the account, it is a call
   question. Put it on the call list below.
2. **The answer could change the decision.** Say how in the last column. If you cannot, cut it.
3. **It asks for a fact.** "What tools do they use for billing" is a fact. "Are they a good fit" is a
   judgment, and judgments are made by a person reading the facts.

| # | Question | Where an answer would be published | How the answer changes the decision |
|---|---|---|---|
| Q1 | | | |
| Q2 | | | |
| Q3 | | | |
| Q4 | | | |
| Q5 | | | |
| Q6 | | | |
| Q7 | | | |
| Q8 | | | |

## A starting set for a first message

Reword these for what you sell. They are a start, and each still has to pass the three tests.

| Question | Usual source |
|---|---|
| What does the company sell, and to whom, in its own words | home page, product pages |
| Which roles is it hiring for in the team we sell to | careers page, job board |
| What work do those job posts say the new hire will own or fix | the full text of each job post |
| Which tools does it name in job posts, docs or its site | job posts, help center, integrations page |
| What has it announced in the last 90 days | newsroom, company blog, filings |
| Who leads the team we sell to, and since when | leadership page, the person's own public profile |

## Questions for the call

Anything that failed test 1 goes here. The brief hands these to the seller as open questions. A model
must never answer them.

| Question | Why no public page can answer it |
|---|---|
| | |
| | |

## The limit on length

Set it now. A seller with ten minutes before a call reads one page.

| Limit | Your number |
|---|---|
| Most claims in one brief | |
| Most minutes a seller should need to read it | |
| Most pages opened per account | |

## What this sheet cannot tell you

It sets what to look for. It does not say which pages count as evidence. That is `source-list.md`.
