# Sample account and answer key

Part of the Magnetiz Account Research implementation kit.

Everything on this sheet is invented. Harborline Logistics is not a real company, and its pages do not
exist. Use the sheet to practise the citation check before you run it on a real account.

## The setup

You sell software that automates carrier invoicing. The brief serves one decision. What should the
first message be about?

| # | Question |
|---|---|
| Q1 | What does Harborline sell, and to whom |
| Q2 | Which roles is it hiring for in finance or operations |
| Q3 | What work do those job posts say the hire will own or fix |
| Q4 | Which tools does it name for billing or finance |
| Q5 | What has it announced in the last 90 days |
| Q6 | How many people work there |

## The pages fetched in this run

Three pages. These are the full texts the check compares against.

**Page A.** harborline.example/ (fetched 3 November)

> Harborline Logistics moves refrigerated freight for regional grocery chains across the Pacific
> Northwest. We run 140 trucks from four depots.

**Page B.** harborline.example/careers/billing-operations-manager (fetched 3 November)

> Billing Operations Manager. You will own carrier invoice reconciliation, which today is done by hand
> in spreadsheets by a team of three. You will work in NetSuite and lead the move off manual matching.
> Reports to the Controller.

**Page C.** harborline.example/news/tacoma-depot (fetched 3 November)

> Harborline opened its fourth depot in Tacoma on 14 September. The site adds cold storage for 600
> pallets.

## The lines the model proposed

Seven lines. Run the check from `citation-check.md` on each one before you read the answer key.

| # | Line | Citation |
|---|---|---|
| 1 | Harborline moves refrigerated freight for regional grocery chains in the Pacific Northwest. | Page A, "moves refrigerated freight for regional grocery chains across the Pacific Northwest" |
| 2 | It is hiring a Billing Operations Manager who will own carrier invoice reconciliation. | Page B, "You will own carrier invoice reconciliation" |
| 3 | Invoice reconciliation is done by hand in spreadsheets by a team of three. | Page B, "today is done by hand in spreadsheets by a team of three" |
| 4 | Harborline uses NetSuite and is replacing it. | Page B, "You will work in NetSuite and lead the move off NetSuite" |
| 5 | Harborline has about 450 employees. | harborline-profile.example/company, "Employees: 450" |
| 6 | It is hiring the billing role because the Tacoma depot increased invoice volume. | none |
| 7 | Harborline opened a fourth depot in Tacoma on 14 September. | Page C, "opened its fourth depot in Tacoma on 14 September" |

## Answer key

| # | Result | Why |
|---|---|---|
| 1 | Claim, stated fact, primary | the quote is on Page A, word for word |
| 2 | Claim, stated fact, primary | the quote is on Page B |
| 3 | Claim, stated fact, primary | the quote is on Page B |
| 4 | Refused, quote is not on the page | Page B says "lead the move off manual matching". The model changed two words, and the claim that they are leaving NetSuite is the opposite of what the page says |
| 5 | Refused, page was never fetched | harborline-profile.example is not in the list of pages fetched this run |
| 6 | Refused, no citation | two true facts joined with a reason no page gives |
| 7 | Claim, stated fact, primary | the quote is on Page C |

Seven lines proposed, four claims, three refusals. Four plus three is seven, so nothing went missing.

Q6, the headcount, ends as not found. The only line that answered it was refused.

## What the three refusals would have cost

| Line | If it had reached the seller |
|---|---|
| 4 | a first message about replacing NetSuite, sent to a company that is keeping it |
| 5 | an account sized on a number with no page behind it |
| 6 | a confident sentence about why they are hiring, which the Controller knows to be a guess |

Line 4 is the one to study. It carried a source link to a real page about the right role. A reader
who checked only that the link worked would have passed it.

## The brief that results

```
ACCOUNT BRIEF

Account: Harborline Logistics        Website: harborline.example
Decision it serves: what the first message should be about
Researched on: 3 November            Pages fetched: 3
Lines proposed: 7    Claims: 4    Refused: 3

WHAT THE PAGES SAY

C1  Harborline moves refrigerated freight for regional grocery chains in the Pacific Northwest.
    Kind: stated fact   Tier: primary
    "moves refrigerated freight for regional grocery chains across the Pacific Northwest"
    harborline.example/, fetched 3 November

C2  It is hiring a Billing Operations Manager who will own carrier invoice reconciliation.
    Kind: stated fact   Tier: primary
    "You will own carrier invoice reconciliation"
    harborline.example/careers/billing-operations-manager, fetched 3 November

C3  Invoice reconciliation is done by hand in spreadsheets by a team of three.
    Kind: stated fact   Tier: primary
    "today is done by hand in spreadsheets by a team of three"
    harborline.example/careers/billing-operations-manager, fetched 3 November

C4  Harborline opened a fourth depot in Tacoma on 14 September.
    Kind: stated fact   Tier: primary
    "opened its fourth depot in Tacoma on 14 September"
    harborline.example/news/tacoma-depot, fetched 3 November

WHAT WE THINK IT MEANS

R1  The first message should be about carrier invoice reconciliation done by hand. The account
    wrote that down itself. Rests on: C2, C3. Written by: the seller.

WHAT WE COULD NOT SUPPORT

X1  Harborline uses NetSuite and is replacing it.
    Reason: quote not on the page. The page says "lead the move off manual matching".
X2  Harborline has about 450 employees.
    Reason: page never fetched.
X3  It is hiring the billing role because the Tacoma depot increased invoice volume.
    Reason: no citation.

NOT FOUND

Q6  How many people work there. Pages tried: harborline.example/

QUESTIONS FOR THE CALL

How many carrier invoices a month go through the team of three?
Is the Tacoma depot part of why this role opened?

CHECK AGAIN BEFORE ACTING

C2, C3. Re-open the job post on the day the message is sent.
```

## Your turn

Write two more proposed lines for Harborline, one that should pass and one that should be refused, and
hand them to a colleague to check. If they pass the one you meant to fail, read
`citation-check.md` together.
