# Source list

Part of the Magnetiz Account Research implementation kit.

Fill this in once, and review it every quarter. It answers one question. Which pages are allowed to
be evidence?

## Why sources are ranked before research starts

A model will cite whatever it finds first. A data vendor's profile page, a two-year-old news story and
the company's own careers page all look the same in a list of links. They do not carry the same
weight. Rank them now, so the rank travels with every claim.

## Two tiers

| Tier | What it is | Examples | What it can support |
|---|---|---|---|
| Primary | the account saying it about itself, or a filing it is legally bound to | its website, careers page, job posts, help center, newsroom, regulatory filings, a leader's own public post | any claim |
| Secondary | someone else saying it about the account | news coverage, review sites, data vendor profiles, analyst notes, partner pages | a claim marked secondary, which a seller treats as a lead to confirm |

A claim built on a secondary source is still a claim. It is labelled, and the label is printed beside
it in the brief.

## Your source list

One row per kind of page you allow.

| Source | Tier | Good for which questions | Goes stale after | Notes |
|---|---|---|---|---|
| Company website, product and pricing pages | Primary | | | |
| Careers page and job posts | Primary | | | a post that has closed is still evidence of what they wanted on that date |
| Help center, docs, integrations page | Primary | | | |
| Newsroom and company blog | Primary | | | |
| Regulatory filings | Primary | | | |
| A leader's own public posts | Primary | | | the person, speaking for themselves |
| News coverage | Secondary | | | |
| Review sites | Secondary | | | |
| Data vendor profiles | Secondary | | | headcount and funding here are estimates |
| | | | | |

## Sources you do not allow

Write these down. A model follows a list of what is ruled out better than a general warning.

| Source | Why it is out |
|---|---|
| A search result snippet with the page never opened | the snippet is a summary of the page, and it can be wrong |
| Anything behind a login the researcher is not entitled to use | |
| Pages that restate other pages with no date and no author | |
| The model's own memory of the company | it carries no page and no date |
| | |

## How old is too old

Every claim carries the date its page was fetched. Set the age at which a claim has to be checked
again before anyone acts on it.

| Kind of fact | Check again after |
|---|---|
| Open roles | days |
| Tools in use | days |
| Leadership and titles | days |
| What the company sells | days |
| Announcements | never, the date is part of the claim |

## Three rules for using the list

1. **Open the page.** A source counts only if the page was fetched and read in this run.
2. **Prefer the page nearest the account.** If a news story quotes the company's announcement, fetch
   the announcement and cite that.
3. **Keep the tier with the claim.** A brief that mixes primary and secondary claims with no label
   reads as if everything in it is equally sure.

## What this sheet cannot tell you

It says which pages may be evidence. It does not say what a claim has to carry to stand. That is
`claim-rules.md`.
