# Research read

Part of the Magnetiz Account Research implementation kit.

Run this once a week. It answers one question. Is the research right, and is anyone using it?

## Why the check alone is not enough

The citation check proves that a page said something. It cannot prove that the claim follows from the
quote, that the page is correct, or that a seller read the brief. Those three need a person and a
count.

## Part 1. The numbers the check produces

Read these from the week's briefs.

| Number | This week | Last week | What a change means |
|---|---|---|---|
| Briefs produced | | | |
| Lines proposed | | | |
| Lines refused | | | |
| Share refused | | | a rise can mean a prompt change, a model change, or a batch of thin accounts |
| Refused, no citation | | | the model is answering from memory |
| Refused, quote not on the page | | | the model is paraphrasing, or pages are being fetched badly |
| Refused, page never fetched | | | the model is inventing or remembering links |
| Questions returned as not found | | | a question that is never found should be cut or moved to the call list |
| Briefs where claims plus refusals did not equal lines proposed | | | has to be zero |

**A refused share of zero is a finding.** Check that the check still runs. Feed it one of the test
lines from `citation-check.md`.

## Part 2. The sample a person reads

Pick ten claims that passed, at random, across the week's briefs. Open each page.

| # | Claim | Quote supports the claim | Page is what the tier says it is | Still true today | Verdict |
|---|---|---|---|---|---|
| 1 | | | | | |
| 2 | | | | | |
| 3 | | | | | |
| 4 | | | | | |
| 5 | | | | | |
| 6 | | | | | |
| 7 | | | | | |
| 8 | | | | | |
| 9 | | | | | |
| 10 | | | | | |

For each claim that fails the first column, write down what went wrong.

| Failure | What it looks like | The fix |
|---|---|---|
| The quote is real and the claim says more than it | the page says "exploring", the claim says "is moving to" | tighten rule 1 of the prompt, and add the pair to your test set |
| A reason was added | two true facts joined with "because" | point the model at rule 4, and move joins to the reads section |
| The quote is about a different company or product | a parent company, a customer story, a partner | add the page type to the ruled-out list in `source-list.md` |
| The page was already out of date | a closed job post, an old leadership page | shorten the age limit for that kind of fact |

## Part 3. What sellers reported

From the marks at the bottom of each brief.

| Number | This week |
|---|---|
| Briefs opened before the call or message they were for | |
| Claims used | |
| Claims that held up | |
| Claims that turned out wrong | |
| Claims that were out of date | |

A claim that turned out wrong on a call is the most useful row in this kit. Trace it back to its page
and its quote, and name which of the four failures it was.

## When a person can read less

Start by reading every brief. Move down only when the numbers say so, and move back up the week they
stop saying so.

| Level | A person reads | Move down when | Move back up when |
|---|---|---|---|
| 1 | every claim in every brief | four weeks in a row with no wrong claim found in the sample or reported by a seller | |
| 2 | ten claims a week, at random | eight more weeks the same | one wrong claim reaches a seller |
| 3 | ten claims a month, plus every seller report | | the model, the prompt or the page fetcher changes |

Any change to the model, the prompt or the way pages are fetched returns you to level 1 for two weeks.
The record that earned less reading belonged to the old setup.

## What this sheet cannot tell you

It shows whether the research is right and read. It does not show whether better research wins more
deals. Read that from your pipeline, by comparing accounts that had a brief with accounts that did
not.
