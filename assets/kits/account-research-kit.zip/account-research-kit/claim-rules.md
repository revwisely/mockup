# Claim rules

Part of the Magnetiz Account Research implementation kit.

These are the rules every line of a brief has to pass. They answer one question. What does a claim
have to carry before a seller is allowed to read it?

## The rule

Every claim carries a citation. A citation is three things.

| Part | What it is |
|---|---|
| The page | the full address of a page that was fetched in this run |
| The quote | the exact words on that page that support the claim, copied character for character |
| The date | when the page was fetched |

A source link alone does not meet the rule. A link says where to look. A quote says what was found
there, and a quote can be checked.

## The four refusals

Each of these can be decided by a short piece of code or by a person with the page open. No judgment
is involved, so there is nothing to argue about.

| # | Refusal | What it catches |
|---|---|---|
| 1 | The claim has no citation | a fact the model produced from memory |
| 2 | The quote is under 20 characters | one or two words that appear on almost any page |
| 3 | The page was never fetched in this run | a link the model invented or remembered |
| 4 | The quote is not on the page | a real page credited with words it never said |

## Two more rules that keep the four honest

1. **One bad citation refuses the whole claim.** If a claim carries two citations and one fails, the
   claim is refused. Otherwise a real source can cover for an invented one.
2. **Nothing is dropped.** Every line the model proposed ends as a claim or as a refusal. The count
   of claims plus the count of refusals equals the count proposed. Check that sum on every brief.

## Refusals stay in the brief

A refused line is printed in its own section with the reason beside it. Three things make this worth
the space.

- The seller sees what the research could not support, and does not repeat it on a call.
- A brief with few claims and several refusals is an honest brief about a thin account.
- The share of lines refused is the number you read each week in `research-read.md`.

## Label each claim

| Label | Values | Why it is there |
|---|---|---|
| Kind | a number, a stated fact, a stated reason | numbers and reasons are where a model most often goes past its source |
| Tier | primary, secondary | from `source-list.md` |

**A stated reason needs the reason in the quote.** "They are hiring because of the new product line"
stands only if a page says so. If the page says they are hiring and another page says they launched a
product, those are two claims. Joining them is a read, and reads go in their own section.

## Facts and reads are kept apart

The brief has two sections that must never mix.

| Section | Who writes it | What it holds |
|---|---|---|
| What the pages say | the model, through the check | claims that passed, each with its quote |
| What we think it means | a person, or the model in a clearly marked section | reads, each naming the claim numbers it rests on |

A read with no claim numbers under it is cut.

## If an AI model does the research

The model proposes lines. It never decides which ones stand. The check in `citation-check.md` decides
that, and the check has no model in it. Give the model the four refusals in its instructions, and
then check anyway. An instruction lowers the rate of bad citations. It does not bring it to zero.

## What the rules cannot tell you

They prove a page said something on a date. They do not prove the page is right, that it is still
true today, or that the quote really supports the claim. A person samples for that in
`research-read.md`.
