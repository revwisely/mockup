# Citation check

Part of the Magnetiz Account Research implementation kit.

Run this on every brief before a seller sees it. It answers one question. Does each claim carry a
quote that is really on a page that was really fetched?

## Why this is a separate step

The model that wrote a line is the worst judge of whether the line is supported. Asking it to
"double check your sources" returns the same confidence it had the first time. The check has to be
done by something that cannot be persuaded, which means a person with the page open or a short
program that compares text.

## What the check needs

| Input | Where it comes from |
|---|---|
| The lines the model proposed, each with its citations | the model's output |
| The full text of every page fetched in the run, with address and time | saved by the run, never retyped |

If the fetched pages were not saved, the check cannot run. Fix that first.

## The check, line by line

For each proposed line, in order. The first failure refuses the line.

| Step | Question | If no |
|---|---|---|
| 1 | Does the line carry at least one citation? | refuse, "no citation" |
| 2 | Is every quote at least 20 characters long? | refuse, "quote too short to prove anything" |
| 3 | Is every cited address in the list of pages fetched this run? | refuse, "page was never fetched" |
| 4 | Does every quote appear, character for character, in the saved text of its page? | refuse, "quote is not on the page" |
| 5 | All yes | the line stands as a claim |

Then one sum for the whole brief. Claims plus refusals has to equal the number of lines proposed. If
it does not, a line went missing, and the brief is held until it is found.

## Doing it by hand

For the first few weeks, do it by hand on every brief. It takes a few minutes and it teaches you how
your model fails.

1. Open the cited page.
2. Search the page for the quote. Use the browser's find, and paste the whole quote.
3. If find returns nothing, try the first six words. A near match is still a failure. Write down what
   the page really says.
4. Mark the line.

| Line | Citation present | Quote long enough | Page was fetched | Quote found | Result | If refused, what the page says |
|---|---|---|---|---|---|---|
| 1 | | | | | | |
| 2 | | | | | | |
| 3 | | | | | | |
| 4 | | | | | | |
| 5 | | | | | | |

## Doing it in code

The whole check is string comparison. No model is needed, and none should be used. A model asked
whether a quote is on a page will sometimes say yes when it is close.

Decide these four things before anyone writes it.

| Decision | Options | Our default |
|---|---|---|
| How are spaces and line breaks compared | exactly, or with runs of white space treated as one space | treat runs of white space as one space, and nothing else |
| Is upper and lower case ignored | yes or no | no |
| What happens to a line with two citations when one fails | refuse the line, or keep it on the good one | refuse the line |
| What does the run do when the check itself fails to run | show the brief anyway, or hold it | hold it |

Then test the check before it guards anything. Feed it lines you made up.

| Test line | The check should |
|---|---|
| a true claim with an exact quote | pass it |
| a claim with no citation | refuse it |
| a claim quoting a page that was fetched, with one word changed | refuse it |
| a claim citing an address that was never fetched | refuse it |
| a claim whose quote is the word "The" | refuse it |
| a claim with one good citation and one bad one | refuse it |

A check that passes all six of your test lines without refusing any is broken.

## What the check cannot see

It compares text. It cannot tell whether the quote supports the claim, whether the page is right, or
whether the fact is still true. A line can quote a real sentence and draw the wrong conclusion from
it. A person samples for that each week in `research-read.md`.
