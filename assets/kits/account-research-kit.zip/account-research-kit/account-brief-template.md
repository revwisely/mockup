# Account brief template

Part of the Magnetiz Account Research implementation kit.

This is the page a seller reads. It answers one question. What do we know about this account, and how
do we know it?

## The rules of the page

- One page. If it runs longer, the question list is too long.
- Every claim shows its quote. A seller should never have to click to find out what a page said.
- Refusals and open questions are printed. A brief that hides what it could not find reads as more
  complete than it is.

## The template

```
ACCOUNT BRIEF

Account:            [name]            Website: [domain]
Decision it serves: [from research-questions.md]
Researched on:      [date]            Pages fetched: [count]
Lines proposed: [n]    Claims: [n]    Refused: [n]    (claims + refused = proposed)

WHAT THE PAGES SAY

C1  [the claim, one fact]
    Kind: [number / stated fact / stated reason]   Tier: [primary / secondary]
    "[the exact quote]"
    [page address], fetched [date]

C2  ...

WHAT WE THINK IT MEANS

R1  [the read, in one or two sentences]
    Rests on: C1, C3
    Written by: [name, or "model, not reviewed"]

WHAT WE COULD NOT SUPPORT

X1  [the refused line]
    Reason: [no citation / quote not on the page / page never fetched / quote too short]
    [what the page really says, if known]

NOT FOUND

Q4  [the question]
    Pages tried: [addresses]

QUESTIONS FOR THE CALL

[the questions from research-questions.md that no public page can answer]

CHECK AGAIN BEFORE ACTING

[any claim older than its limit in source-list.md, by claim number]
```

## Where each part comes from

| Section | Source | Who may write it |
|---|---|---|
| What the pages say | lines that passed `citation-check.md` | the model, through the check |
| What we think it means | a person reading the claims | a person, or the model in this section only |
| What we could not support | lines the check refused | the check |
| Not found | questions the model returned as not found | the model |
| Questions for the call | `research-questions.md` | written once, by you |
| Check again before acting | the fetch dates against `source-list.md` | computed |

## Using a brief

| When | What the seller does |
|---|---|
| Before a first message | opens on one claim, in the account's own words, and reads the quote before using it |
| Before a call | reads the claims and the questions for the call, and skips nothing under "could not support" |
| Before anything that cannot be taken back | re-opens the page behind the claim the action rests on |

That last row matters most. A brief is true on the day it was researched. A role that was open on
Monday can be filled by Friday, and a message about it then reads as careless.

## After the call

The seller marks each claim they used.

| Claim | Used on the call | Held up | Turned out wrong | Out of date |
|---|---|---|---|---|
| C1 | | | | |
| C2 | | | | |
| C3 | | | | |

These marks are the only evidence that the research is right in a way the check cannot see. They feed
`research-read.md`.

## What this sheet cannot tell you

It shows what was found and how. It does not show whether briefs are being read, or whether they are
changing what sellers do.
