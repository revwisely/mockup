# The Context Layer — the mechanical / judgment split

Part of the Magnetiz Brand Voice Context Layer implementation kit. Most voice documents
fail because they mix two different kinds of rule and enforce neither. Sort every rule
before you enforce anything.

## The test

**Could a person with no taste check this rule correctly, every time, with no argument?**
Yes means mechanical: it belongs in the linter. No means judgment: it belongs in the
judge rubric and the exemplars.

## The sort (fill from your harvest)

| Rule, as you'd say it | Mechanical or judgment | Where it goes |
|---|---|---|
| | | linter / rubric |
| | | linter / rubric |
| | | linter / rubric |

## Mechanical, typically

- Banned words and phrases, with the list written out
- Punctuation habits your voice rejects
- Capitalization and casing conventions
- Sentence or paragraph length ceilings
- Required or forbidden structural elements
- Named-entity conventions (how you refer to your own product, your customers)

## Judgment, typically

- Whether the piece says something the reader could not have predicted
- Whether it sounds like a person your reader would trust
- Whether the claim is earned by evidence in the piece
- Whether the opening does work or performs
- Whether it serves the reader or the writer

## The two failures this split prevents

1. **Judgment rules in a checklist.** "Be authentic" as a checkbox does nothing, and
   everyone stops reading the checklist that contains it.
2. **Mechanical rules left to taste.** A human catching em dashes by eye is a human
   spending judgment on something a script does perfectly, forever, for free.
