# The Context Layer — the calibration set

Part of the Magnetiz Brand Voice Context Layer implementation kit. This is the step
almost nobody does, and it is the one that tells you whether your rubric means anything.

## Build the set (thirty minutes, once)

From the harvest, pick pieces you already know the answer on.

| Slot | How many | Source |
|---|---|---|
| Known GOOD | [5] | published, worked, you know why |
| Known BAD | [5] | rejected drafts, or published misses |
| Borderline | [2] | pieces your own team argued about |

Keep the answers out of the judge's reach. The set is only useful while the judge is
guessing.

## Run it

Score all twelve, three runs each, majority per piece. Then count.

| Measure | Your result | Starting bar |
|---|---|---|
| Known-good passing | | [5 of 5] |
| Known-bad failing | | [5 of 5] |
| Borderline pieces, verdict stable across three runs | | [1 of 2] |

**Write your bars down before the first run.** A bar set afterward equals whatever the
run achieved, which is the same failure mode as a threshold set after a cleanup.

## Reading the result, and this is the whole point

- **The judge passes a known-bad piece.** The rubric is missing the axis that makes that
  piece bad. Name it and add it.
- **The judge fails a known-good piece.** The rubric is enforcing something your voice
  does not actually believe. Cut it, or the judge will slowly flatten the writing.
- **Verdicts swing on identical input.** The rubric is too vague to be stable. Sharpen
  the axis that moved.

**If the judge cannot separate your known-good from your known-bad, the rubric is
wrong, not the drafts.** Fix the rubric before a single real draft is scored against it.

## When to re-run

Whenever the rubric changes, the model changes, or the exemplar set grows. And quarterly
regardless, because the voice moves and a rubric that never re-calibrates is enforcing
last year's taste.
