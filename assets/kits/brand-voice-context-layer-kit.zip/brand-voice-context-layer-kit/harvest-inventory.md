# The Context Layer — the harvest inventory

Part of the Magnetiz Brand Voice Context Layer implementation kit. Start here. A
guideline says "confident but approachable." An exemplar set SHOWS it, which is why the
harvest comes before any writing.

## 1. What to collect (artifacts, never adjectives)

| Class | How many | Where yours live |
|---|---|---|
| Pieces that worked, and you know why | [10-20] | |
| Pieces that missed, and you know why | [5-10] | |
| Lines a customer quoted back to you, verbatim | all of them | |
| Things a person outside the company wrote that sound like you | a few | |
| Pieces you rejected in draft, with the reason | [5] | |

The rejected drafts matter as much as the published ones. A layer built only from
winners teaches what to imitate; the losers teach where the line is.

## 2. For every exemplar, one line of why

An exemplar with no annotation is a sample, not a lesson. One sentence each, in plain
language: what this piece does that the others do not.

| Piece | Worked or missed | Why, in one line |
|---|---|---|
| | | |
| | | |

## 3. The sources most teams forget

- **Sales call recordings.** Your customers' own words about their problem are the
  highest-value voice material you own, and they are already recorded.
- **Support threads and replies.** How your team writes when nobody is performing.
- **The founder's unedited writing.** Usually the truest sample of the voice everyone
  is trying to imitate.

## The rule

**Harvest before you write rules.** Rules extracted from artifacts describe a voice that
exists. Rules written from scratch describe a voice you wish you had, and every draft
against them comes back needing you.
