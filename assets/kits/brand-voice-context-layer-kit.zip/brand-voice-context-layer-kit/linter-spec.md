# The Context Layer — the linter spec

Part of the Magnetiz Brand Voice Context Layer implementation kit. The linter enforces
the mechanical half. It runs before a person reads a word, it fails loud, and it never
has an opinion.

## What the linter must do

1. **Check the whole draft, every time.** Sampling defeats the purpose.
2. **Report the exact line and the exact rule.** "Voice issue" is not a report. "Line
   14, banned phrase: [phrase]" is.
3. **Exit non-zero on error.** If the linter can pass silently while a rule is broken,
   it is decoration.
4. **Separate errors from warnings.** Errors block. Warnings inform. Length overruns are
   usually warnings; banned constructions are usually errors.

## The starting rule set (yours will differ, and should)

| Check | Type | Example of what it catches |
|---|---|---|
| Banned phrase list | error | the words your voice never uses, spelled out |
| Punctuation tells | error | the marks your voice rejects, wherever they appear |
| Casing convention | error | headline styles that drift from house style |
| Forbidden constructions | error | sentence shapes that read as machine-written |
| Length budgets per block | warn | headlines, subheads, card bodies, list items |

**Register is deliberately not on this list**, even though it is one of the most
valuable things to catch. Deciding whether a sentence is about the market or about the
reader's situation takes a reading, and the kit's own test settles where it belongs: a
person with no taste cannot check it every time with no argument. It lives in the judge
rubric instead.

The test is worth applying to your own list before you build it. A rule that feels
mechanical because you are sure of the answer is not mechanical; it is a rule you
happen to have taste about. The linter should only hold rules that survive being
checked by someone who does not.

## Where it runs

- On the writer's machine, before they submit the draft.
- In whatever pipeline publishes, as a blocking step.
- Against drafts from outside the team on arrival, so the feedback is mechanical and
  immediate instead of a thread three days later.

## The honest limit, stated so nobody over-trusts it

**A clean lint is not a good draft.** It means the mechanical tells are gone. Everything
that makes a piece worth reading lives in the judge rubric and the exemplars, and a
linter that starts getting credit for quality is a linter about to be ignored.
