# The Context Layer — distribution and versioning

Part of the Magnetiz Brand Voice Context Layer implementation kit. A context layer that
lives in one person's cloud and gets downloaded, edited, and re-uploaded is a layer with
as many versions as it has readers.

## One source, named

| Question | Your answer |
|---|---|
| Where the layer lives (one location, not "the drive") | |
| Who owns it, by name | |
| How a change is proposed | |
| How readers know it changed | |

## Who reads it, and how

| Reader | How they get it | Checked how |
|---|---|---|
| Your team | | |
| Contractors and outside writers | | |
| AI assistants and agents | | |
| New hires, day one | | |

Anyone outside your core team is the test case. If bringing a new writer to your voice
takes a meeting and a follow-up thread, the layer is described rather than distributed.
The brief should be a link.

## Versioning rules

1. **Dated versions, never silent edits.** Every change has a date and a one-line
   reason, so a draft can be judged against the version it was written under.
2. **One live version.** Copies are how a layer forks. Point at the source.
3. **Retire loudly.** When a rule is replaced, record what replaced it and when. A
   retired rule that survives in an uncorrected copy keeps being enforced by people who
   cannot tell it is stale.

## The loop that keeps it alive

What ships goes back in. A piece that landed becomes an exemplar; a piece that missed
becomes a known-bad; a repeated correction becomes a rule, mechanical if it can be one.
**A context layer that never grows is a document again**, and documents are what sent
the drafts back needing you.
