# The Context Layer — the judge rubric

Part of the Magnetiz Brand Voice Context Layer implementation kit. The judge scores the
half a linter cannot hold. It is blind, it names failure modes rather than giving a
vibe score, and **it runs three times.**

## Run it three times and take the majority (the finding behind the rule)

We measured this in our own content system: the same draft, the same rubric, the same
model, scored CLEAN and SLOP in consecutive runs. Across nine runs of one unchanged
piece, four came back clean. A single run is a coin weighted by nothing you control.

Three consequences, all load-bearing:

1. **Run the rubric three times and take the majority verdict.** One run is an opinion.
2. **Trust the REPRODUCED finding over the verdict label.** If two runs flag the same
   sentence for different reasons, that sentence is the problem, whatever the headline
   verdict said.
3. **A rubric whose verdicts swing on identical input is too vague.** Instability is
   rubric feedback, not model noise to be lived with.

## The rubric shape

Score each axis independently. No composite number, because a composite hides which
axis failed.

| Axis | The question | Pass condition |
|---|---|---|
| Predictability | Could a smart reader predict this from the first two lines? | No |
| Earned claim | Is the central claim supported by evidence inside the piece? | Yes |
| Register | Is the subject the reader's situation, or the market in general? | The reader's |
| Voice match | Against the exemplars, would a reader place this with the winners? | Yes |
| Contribution | What can the reader do after reading that they could not before? | Nameable in one sentence |

## The prompt shape

> You are scoring a draft against a voice rubric. You have not seen the writer and you
> do not know who wrote it. Score each axis independently, quote the exact sentence that
> decided each one, and name the failure mode rather than describing your impression.
> Return a verdict per axis and nothing else.

Blind matters. A judge told the founder wrote it scores the founder, not the draft.

## What the judge never does

- It never rewrites. A judge that edits stops being a measurement.
- It never publishes. Its verdict is an input to a person.
- It never overrules the linter. Mechanical failures are already decided.
