# Reply Triage — the taxonomy

Part of the Magnetiz Reply Triage implementation kit. Four classes, each with tells.
Classification carries a confidence score, and low confidence routes to a person. The
human verdict on every ambiguous reply is the calibration data.

## The classes

| Class | The tells | What happens |
|---|---|---|
| **INTERESTED** | asks to talk, names a time, asks price, "send more" with specifics | sequence stops · channel alert with the thread · a person replies |
| **QUESTION / OBJECTION** | a real question, a pushback with content, "we already use X" | sequence stops · channel alert · a person answers the actual question |
| **NOT INTERESTED** | "no thanks," "remove me," "not a fit," anger of any size | sequence stops · do-not-contact, forever · logged verbatim |
| **OUT OF OFFICE** | auto-reply signature, return date, delegate contact | sequence pauses · re-enrolls after the stated return date |

## Edge rules

- **Unsubscribe language ANYWHERE beats every other tell.** "Interesting, but take me
  off your list" is NOT INTERESTED.
- **A delegate in an OOO** ("contact Sam while I'm out") is a fact for the record, never
  an invitation to cold-message Sam.
- **Anger is NOT INTERESTED plus a flag.** A person reads it same-day; nobody replies
  with a template.
- **Multi-signal replies route to the strongest negative.** Politeness plus a no is a no.

## Confidence

The classifier states confidence per reply. Below your threshold (start at 0.8), the
class decision goes to a person, and the verdict gets logged next to the model's guess.
Review the disagreements monthly; they are the taxonomy earning its next revision.
