# Reply Triage — the taxonomy

Part of the Magnetiz Reply Triage implementation kit. Six classes, each with tells.
Classification carries a numeric confidence, and anything below the threshold routes to
a person. The human verdict on every ambiguous reply is the calibration data.

## The classes

| Class | The tells | What happens |
|---|---|---|
| **INTERESTED** | asks to talk, names a time, asks price, "send more" with specifics | sequence stops · channel alert · a person replies within [1 business hour] |
| **QUESTION / OBJECTION** | a real question, a pushback with content, "we already use X" | sequence stops · channel alert · a person answers within [the same business day] |
| **NOT INTERESTED** | "no thanks," "not a fit," a clear no | sequence stops · EXPLICIT unsubscribe language lands on do-not-contact instantly; an INFERRED no waits for the human verdict before DNC |
| **OUT OF OFFICE** | auto-reply signature, return date, delegate contact | sequence pauses · re-enrolls after the stated return date plus [2 business days] |
| **ROUTED AWAY** | "I've left the company," "contact Dana instead," "looping in my colleague," referrals | sequence stops · record updated · never DNC · the new-contact question goes to a person |
| **UNCLASSIFIED** | too little signal to read ("k"), or none of the above fits | always a person. The system's honesty here is what makes its confident calls trustworthy |

## Edge rules

- **Explicit unsubscribe language ANYWHERE is deterministic.** "Remove me," "take me off
  your list," "stop emailing me" land on do-not-contact the moment words arrive, with no
  model in the path. This is the one irreversible action, and it never rests on an
  inference.
- **A negative that also contains a direct question is below threshold by definition.**
  "We have an agency, good luck. How is this different?" goes to a person, and no DNC
  applies until a person decides. Politeness plus a bare no, with no question, is a no.
- **Anger is its own flag on top of the class.** A person reads it the same day, nobody
  replies with a template, and explicit unsubscribe inside anger still lands DNC
  deterministically.
- **A delegate or successor named in any reply** ("contact Sam," "Dana runs this now")
  is a fact for the record and a question for a person, never an automatic new target.
- **Connection accepts are not replies.** No words, no classification, no pause.

## Channel differences (email rules do not all survive LinkedIn)

- No signatures or footers to strip; cleaning still removes quoted history.
- No unsubscribe convention, so the deterministic DNC rule rarely fires there. An
  inferred no on LinkedIn therefore ALWAYS waits for the human verdict.
- OOO auto-replies are rare; silence rules cover what OOO covers on email.
- Accepts, emoji reactions, and profile views are signals, never replies.

## Confidence

The classifier states confidence as a number, 0.0 to 1.0. Below [0.8], the class
decision goes to a person, and the verdict gets logged next to the model's guess WITH
the reason. Review disagreements monthly; three same-shaped disagreements are a
taxonomy revision waiting to be written.
