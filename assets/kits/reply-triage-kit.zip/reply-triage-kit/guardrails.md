# Reply Triage — the guardrails

Part of the Magnetiz Reply Triage implementation kit. Every guard exists because a busy
queue forgets that a reply is a person.

## The four guards

1. **Any reply pauses the sequence, instantly, before classification.** Never a send
   past a reply. The pause is deterministic; the classification decides what happens
   next, not whether sending stops.
2. **The do-not-contact list is forever and everywhere.** A not-interested lands on it
   the moment words arrive, and every send path checks it. One list, honored by every
   tool, including the next tool you add.
3. **Nothing auto-replies. Ever.** The system classifies, alerts, and logs. A person
   writes every response. An objection answered by a machine reads as exactly that.
4. **OOO re-enrollment respects the stated date plus a buffer.** Resume where the
   sequence left off, never from the top. No return date stated means pause [14] days.

## The test for each guard

Simulate the failure. Send a test reply mid-sequence and verify the next touch never
fires. Add a test address to the do-not-contact list and verify every tool refuses it.
A guard you have not watched fire is a guard you are hoping about.
