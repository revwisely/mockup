# Reply Triage — the guardrails

Part of the Magnetiz Reply Triage implementation kit. Every guard exists because a busy
queue forgets that a reply is a person.

## 0. Name the send paths (the guards are only as wide as this table)

A guard checked in one place gets bypassed by the next integration, so enumerate every
place a send can originate. The DNC guard below is checked at EVERY row, and adding a
tool adds a row before it sends anything.

| Sending tool | Where its replies land | Owner, by name | Honors the shared DNC list? |
|---|---|---|---|
| | | | |
| | | | |
| | | | |

## The four guards

1. **Any reply pauses the sequence, instantly, before classification.** Never a send
   past a reply. The pause is deterministic, implemented in the capture path, and a
   classifier failure can never cost a send.
2. **Do-not-contact is forever, everywhere, and split by how the no arrived.**
   EXPLICIT unsubscribe language ("remove me," "stop emailing me") lands on the list
   the moment words arrive, deterministically, no model in the path. An INFERRED no —
   the model's not_interested without unsubscribe language — stops the sequence
   immediately but waits for the human verdict before the list. The irreversible action
   never rests on an inference. One list, honored by every row of the table above.
3. **Nothing auto-replies. Ever.** The system classifies, alerts, and logs. A person
   writes every response.
4. **OOO re-enrollment respects the stated date plus [2 business days].** Dates resolve
   against the reply's received date; relative language ("back in two weeks") resolves
   the same way; unresolvable dates fall to the default pause of [14] days. Resume
   where the sequence left off, never from the top.

## The test for each guard

Simulate the failure. Send a test reply mid-sequence and verify the next touch never
fires. Add a test address to the DNC list and verify every tool in the table refuses
it. Suppress a run and verify the silence gets reported. A guard you have not watched
fire is a guard you are hoping about.
