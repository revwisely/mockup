# Reply Triage — routing and alert formats

Part of the Magnetiz Reply Triage implementation kit. The alert lands where the team
already reads, with everything a person needs to act in one look.

## The channel alert (interested / question)

```
🔵 REPLY · [class] · [confidence]
[Name], [Title] at [Company] · campaign: [name] · touch: [T3]
────────────────────────────
"[the reply, verbatim]"
────────────────────────────
Context: [one line on who they are + the message they replied to]
Owner: @[name] · answer by [interested: 1 business hour · question: same business day]
```

## The anger alert (its own format, because it needs the fastest eyes)

```
🔴 ANGER FLAG · [class] · read today
[Name], [Company] · campaign: [name] · touch: [T4]
────────────────────────────
"[the reply, verbatim]"
────────────────────────────
DNC: [already applied (explicit) | awaiting your verdict (inferred)]
Owner: @[name] · read by end of business TODAY · never a template
```

## The class alert (unclassified, below threshold)

Same shape as the reply alert, headed `⚪ CLASS NEEDED`, with the model's guess and
confidence shown, and one ask: pick the class.

## The successor alert (routed_away)

Headed `⚪ CONTACT CHANGED`, and it is a different alert because the class is not in
doubt. A reply saying "I left, Dana owns this now" classifies cleanly and at high
confidence; sample 8 in the answer key scores it 0.9. Asking a person to "pick the
class" on a reply the model read correctly trains them to dismiss the alert.

One ask instead: what happens with the named successor. Adding a new contact is a
person's call, never an automation's, and that decision is the only thing here a
human is needed for.

## The CRM log (every reply, every class)

| Field | Content |
|---|---|
| Reply verbatim | always, uncleaned |
| Class + confidence (number) | from the classifier |
| Human verdict | when a person decided; blank means the model's call stood |
| **Verdict reason** | one line on WHY, in the person's words. This is the calibration data |
| Sequence state | stopped / paused-until [date] |
| DNC state | none / applied-explicit / applied-by-verdict |
| Outcome | replied-by [name] / DNC / re-enrolled / record-updated |

## The weekly read

Replies by class, disagreement rate between classifier and human verdicts, the verdict
reasons, and the verbatim objections. Three same-shaped disagreements are a taxonomy
revision candidate. The objection language is next month's better messaging; collecting
it is half the system's value.
