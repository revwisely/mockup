# Reply Triage — routing and alert formats

Part of the Magnetiz Reply Triage implementation kit. The alert lands where the team
already reads, with everything a person needs to act in one look.

## The channel alert (interested / question)

```
🔵 REPLY · [class] · [confidence]
[Name], [Title] at [Company] · campaign: [name] · touch: [T3]
────────────────────────────
"[the reply, verbatim]"
────────────────────────────
Context: [one line on who they are + the message they replied to]
Owner: @[name] · answer by [time]
```

One-click links: the full thread · the CRM record · their profile.

## The CRM log (every reply, every class)

| Field | Content |
|---|---|
| Reply verbatim | always, uncleaned |
| Class + confidence | from the classifier |
| Human verdict | when a person decided; blank means the model's call stood |
| Sequence state | stopped / paused-until [date] |
| Outcome | replied-by [name] / DNC / re-enrolled |

## The weekly read

Replies by class, disagreement rate between classifier and human verdicts, and the
verbatim objections. The objection language is next month's better messaging; collecting
it is half the system's value.
