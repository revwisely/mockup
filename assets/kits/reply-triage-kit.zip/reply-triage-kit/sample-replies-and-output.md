# Reply Triage — sample replies and the answer key

Part of the Magnetiz Reply Triage implementation kit. Run these through the prompt
before any real reply. Route differences are failures; wording differences are fine.
Three of eight route to a person by design.

## The samples

1. "Interesting timing. We were just talking about this. Do you have 20 minutes Thursday?"
2. "What does this cost, roughly? We got burned on a similar tool last year."
3. "Please remove me from your list."
4. "I am out of the office until March 3 with limited email access. For urgent matters
   contact Priya Shah."
5. "Thanks, but we already have an agency handling this. Good luck though. Actually,
   how is this different from what an agency does?"
6. "k"
7. "Stop emailing me. This is the third time."
8. "I left the company last month. Dana Okafor owns this now."

## The answer key

| # | Class | Confidence | The judgment, stated |
|---|---|---|---|
| 1 | interested | 0.95 | named a time. Sequence stops, alert fires, a person confirms Thursday inside the hour |
| 2 | question_objection | 0.9 | a price question wrapped in a scar. The person answering addresses the burn, never just the price |
| 3 | not_interested | 0.98 | explicit unsubscribe language. DNC applied deterministically before the model even ran; the classification confirms the record |
| 4 | out_of_office | 0.95 | March 3 resolves against the received date; pause until March 3 plus the buffer. Priya is a fact for the record, never a new target |
| 5 | question_objection | 0.55 | a negative WITHOUT unsubscribe language plus a direct question is below threshold by rule. A person decides, and no DNC until they do. The failure mode is auto-filing it either way |
| 6 | unclassified | 0.2 | one letter is not evidence, and the schema can say so. A person decides; the sequence stays paused meanwhile |
| 7 | not_interested | 0.97 | "stop emailing me" is explicit, so DNC is already applied in code. The anger flag routes it to a person TODAY, and nobody replies with a template |
| 8 | routed_away | 0.9 | an honest answer, never a DNC. The record updates, and whether Dana becomes a contact is a person's call, not an automation's |

## What the key is teaching

- The one irreversible action (DNC) lands two ways and only two. Deterministically on
  explicit words, or on a human verdict. Never on an inference alone.
- Three of eight go to a person (5, 6, and 8's successor question). The system's honesty
  about what it cannot decide is what makes its confident calls trustworthy.
- Sample 8 is the class most kits forget, and it is common. People leave companies;
  treating that as rejection burns a live account.
