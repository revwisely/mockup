# Reply Triage — sample replies and the answer key

Part of the Magnetiz Reply Triage implementation kit. Run these through the prompt before
any real reply. Route differences are failures; wording differences are fine.

## The samples

1. "Interesting timing. We were just talking about this. Do you have 20 minutes Thursday?"
2. "What does this cost, roughly? We got burned on a similar tool last year."
3. "Please remove me from your list."
4. "I am out of the office until March 3 with limited email access. For urgent matters
   contact Priya Shah."
5. "Thanks, but we already have an agency handling this. Good luck though. Actually,
   how is this different from what an agency does?"
6. "k"

## The answer key

| # | Class | Confidence | The judgment, stated |
|---|---|---|---|
| 1 | interested | high | named a time. Sequence stops, alert fires, a person confirms Thursday |
| 2 | question_objection | high | a price question wrapped in a scar. The person answering addresses the burn, never just the price |
| 3 | not_interested | high | unsubscribe language. DNC forever, logged, nobody replies |
| 4 | out_of_office | high | pause until Mar 3 + buffer. Priya is a fact for the record, never a new target |
| 5 | question_objection | MEDIUM | polite no + a real question. Strongest-negative rule pulls toward not_interested, the direct question pulls back. Below threshold → a person decides. The failure is auto-filing it either way |
| 6 | — | LOW | one letter is not evidence. Human decides; sequence stays paused meanwhile |

## What the key is teaching

Two of six route to a person, by design. The system's honesty about what it cannot
classify is what makes its confident calls trustworthy.
