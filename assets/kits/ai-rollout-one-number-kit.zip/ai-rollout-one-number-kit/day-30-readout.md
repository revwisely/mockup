# Day 30 readout

Part of the Magnetiz "AI Rollout Changed Nothing? Make It Move One Number in 30 Days" implementation kit.

On the read date, apply the rule signed in `rollout-rule.md`. The rule was written before anyone knew
the result, so this page reads it. It does not reopen it.

## 1. The read

| Field | Value |
|---|---|
| Read date | |
| Count in the period | [below the minimum means stop here and keep recording] |
| Weeks past the line | [n of the last three] |
| Holdout past the line? | [yes / no / no holdout] |
| Usage over the 30 days | |
| Anything on the "what else" list that happened | |

## 2. The decision

Circle one, using the table in `rollout-rule.md`.

**Keep** · **Hold** · **Fix** · **Fix adoption, or kill** · **Kill or roll back** · **Keep recording**

## 3. The record

| Field | Value |
|---|---|
| The decision, in one sentence | |
| What happens next | [the next number, the one change, or the shutdown date] |
| Next read date (if any) | |
| Owner of the number signs | |
| Owner of the rollout signs | |

## If the answer is Keep

Name the next number the rollout should move and start a new charter. A tool that moved one number
earns its next test, never a pass for life.
