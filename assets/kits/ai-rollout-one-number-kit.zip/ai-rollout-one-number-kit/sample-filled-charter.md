# Sample, filled in

Part of the Magnetiz AI Rollout Measurement implementation kit.

A worked example of the charter and the rule, so you can see what a finished page looks like. **Every
company, number and name here is illustrative, made up for this example.**

## The charter

| Field | Example |
|---|---|
| The rollout | An AI assistant that drafts a research brief before every first call |
| The number it should move | First calls that turn into a second meeting, per week |
| Who owns that number | VP Sales |
| Why this number | Reps who walk in prepared should earn more second meetings |
| Direction | Up |
| Exactly what counts | A second meeting held within 21 days of the first call |
| Does not count | Internal meetings, reschedules of the first call |
| Source of record | The CRM meetings report, filtered to first calls |
| Usage number | Share of first calls that had a brief opened before the call |

## The baseline (four weeks before)

| Week | Second meetings | Notes |
|---|---|---|
| 1 | 14 | |
| 2 | 11 | one rep out |
| 3 | 16 | |
| 4 | 13 | |

Lowest week 11, highest week 16, swing 5.

## The rule

| Field | Example |
|---|---|
| The line | Above 16 a week |
| Weeks past the line needed | Two of the last three |
| Expected count | 40 first calls in the 30 days |
| Comparison | Holdout. The EMEA team keeps its current prep for 30 days |
| What else could move it | A new outbound campaign starts in week 2, logged for both teams |

## How day 30 read (example)

The team landed above 16 in two of the last three weeks, at 18 and 19.

The EMEA holdout stayed inside its own range. The campaign ran for both teams, so it cannot explain the gap. Usage was 80% of first
calls.

**The decision is Keep.** The next number is the second-meeting-to-opportunity rate.
