# Baseline log

Part of the Magnetiz "AI Rollout Changed Nothing? Make It Move One Number in 30 Days" implementation kit.

Record the number for four weeks before the rollout, read exactly the way `one-number-charter.md`
defines it. The baseline is what "moved" gets measured against, so it has to exist before the tool does.

## Why four weeks, and why the range

One week can be high or low for reasons that have nothing to do with the tool, like a holiday, a big
campaign or two reps out sick.

Four weeks show how much the number swings on its own. The readout uses
that swing, so a normal good week is never mistaken for the rollout working.

## The four weeks before

| Week starting | The number | Usage (if the tool exists yet) | Anything unusual that week |
|---|---|---|---|
| | | | |
| | | | |
| | | | |
| | | | |

## What the four weeks say

| Field | Value |
|---|---|
| Lowest week | |
| Highest week | |
| Average | |
| The swing (highest minus lowest) | |

## No four weeks of history?

Pull the same number for the same four weeks last quarter from the source of record, if it was recorded
then.

With no record at all, start the log now and launch once four weeks exist. A rollout launched without a
baseline can only be judged by usage.
