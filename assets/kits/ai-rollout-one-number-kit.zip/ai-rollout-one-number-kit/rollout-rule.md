# The rollout rule

Part of the Magnetiz AI Rollout Measurement implementation kit.

Write this before launch and sign it. On day 30 the readout applies this rule, so the decision is made
now, while nobody has a stake in the result.

## 1. What counts as moved

The number counts as moved when it lands past the baseline's swing, in the direction the charter names.

| Field | Your value |
|---|---|
| Baseline highest week (from `baseline-log.md`) | |
| Baseline lowest week | |
| The line, the level that counts as moved | [above the highest week if the number should go up, below the lowest if it should go down] |
| Weeks past the line needed | [two of the last three weeks is a sensible default. With four baseline weeks it says "moved" about one time in seven when nothing changed, about one in nine with five. A holdout cuts it further] |

## 2. The read date

| Field | Your value |
|---|---|
| Launch date | |
| Read date | [launch plus 30 days] |
| Expected count in the period | [e.g. 20 meetings across the team. A low count is not a reason to wait. It makes the weekly number swing more, and the baseline already shows that swing] |

## 3. The comparison

Pick one. A holdout is stronger, because it shows what the number did without the tool over the same weeks.

| Option | Use when | Your choice |
|---|---|---|
| **Holdout.** One team, segment or region keeps working without the tool for the 30 days | you have two groups doing the same work | [ ] which group |
| **Before and after.** The same team, against its own baseline | there is only one group | [ ] |

## 4. What else could move the number

List anything planned in the 30 days that could move the number on its own, such as hiring, a pricing
change, a campaign, a season or a territory change. The readout checks the list before giving the tool credit.

- [ ]
- [ ]

## 5. The decision rule

| On the read date, the log shows | Decision |
|---|---|
| Past the line, the holdout is not (or no holdout and nothing on the list happened) | **Keep.** Pick the next number |
| Past the line, but the holdout moved too, or something on the list happened | **Hold.** Run 30 more days with a cleaner comparison |
| Not past the line, and usage is high | **Fix.** It is used and does not touch the number. Change what it does, one change, 30 more days |
| Not past the line, and usage is low | **Fix adoption, or kill.** Find out why it goes unused before judging it |
| Moved the wrong way | **Kill or roll back** |
| Read date not reached | **Keep recording.** Decide nothing yet |

## Sign-off

| | Name | Date |
|---|---|---|
| Owner of the number | | |
| Owner of the rollout | | |
