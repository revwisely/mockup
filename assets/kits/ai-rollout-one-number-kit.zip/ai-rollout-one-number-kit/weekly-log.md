# Weekly log

Part of the Magnetiz "AI Rollout Changed Nothing? Make It Move One Number in 30 Days" implementation kit.

One row a week for the 30 days, read the same way as the baseline. It takes five minutes, and it is what
the day-30 readout reads.

## The rows

| Week starting | The number | The holdout's number (if any) | Usage | Past the line? | Anything on the "what else" list this week |
|---|---|---|---|---|---|
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |

## Notes for the readout

Write down anything a person noticed that the numbers will not show, like a rep who stopped using the
tool and why, or a week the source of record was late.

-
