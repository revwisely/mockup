# One number charter

Part of the Magnetiz AI Rollout Measurement implementation kit.

Fill this in before the rollout starts. Every other worksheet in the kit measures the number this page
names. Without a number named in advance, the rollout can only be judged by whether people use it.

## Why one number

A rollout judged by usage reads as done the day it ships, whether anything changed or not.

Logins, messages generated and seats activated measure use. A revenue owner pays for a result. Name the one
result this rollout exists to move, and name it before anyone touches the tool.

## 1. The number

| Field | Your answer |
|---|---|
| The rollout | [the AI tool or workflow, in one line] |
| The number it should move | [one number, e.g. meetings held per rep per week] |
| Who owns that number | [a person, by name or role, who answers for it today] |
| Why this number | [one sentence on how the rollout touches it] |
| Direction | [up or down] |

## 2. The definition, so two people get the same count

| Field | Your answer |
|---|---|
| Exactly what counts | [e.g. a meeting that happened, not one booked] |
| What does not count | [e.g. internal meetings, reschedules, no-shows] |
| The source of record | [the report, field or table it is read from] |
| The unit of time | [per week is usually right; per day is noisy] |
| Who reads it | [the person who pulls the number every week] |

## 3. The usage check

Write one usage number too, so the readout can tell "not used" from "used and did nothing". It never
decides the rollout on its own.

| Field | Your answer |
|---|---|
| Usage number | [e.g. share of reps who used it at least three days that week] |
| Its source | [where it is read from] |

## 4. Is this number really the result?

Answer each in a line. A "no" means pick a different number before going on.

- Would the owner of the number care if it moved, and lose sleep if it fell? [yes / no]
- Could it move only because people used the tool more, with no change in the result? [yes / no, if yes it is a usage number]
- Can it be read every week from the source above, without a special project? [yes / no]

## Sign-off

| | Name | Date |
|---|---|---|
| Owner of the number | | |
| Owner of the rollout | | |
