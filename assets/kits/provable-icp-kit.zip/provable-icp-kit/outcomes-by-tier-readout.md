# The ICP You Can Prove: the outcomes readout, by tier

Part of the Magnetiz Provable ICP implementation kit. The golden set proves the verdict
matches your rules. This readout proves your rules match the market. Each month, every
meeting, opportunity, win and loss is credited to the tier that routed the account, and
the tiers are compared.

## Why read outcomes by tier

The ICP model says Tier 1 should convert better than Tier 2. Almost nobody checks
whether it does, after launch, on the accounts the model actually routed. If the tiers
convert at the same rate, the tiering is costing effort and deciding nothing.

## 1. Record each outcome against the account

| Field | Value |
|---|---|
| Domain | the account's domain, normalised (lowercase, no `www.`) |
| Kind | meeting held · opportunity · won · lost |
| Date it happened | the day, not the day it was entered |
| Entered by | [name] |

Entered by hand in the same weekly pass as the rest of your pipeline review. At the end
of the pass, write down the **covered-through date**. It means "every outcome up to this
day is entered."

## 2. Credit the tier that routed it

Three rules keep the readout honest.

1. **The tier is the verdict in force before the month opened.** A re-score after a meeting
   can be caused by the meeting. Crediting the new verdict would let a good outcome promote
   the account into Tier 1 after the fact.
2. **Read from the verdict history, never the current score.** The current score is
   overwritten by every re-score. Keep an append-only log of every verdict with its date.
3. **An account with no readable verdict lands in unknown, with a reason.** It is never
   dropped and never assigned to the nearest tier.

## 3. The monthly table

| Tier | Accounts routed | Meetings | Meeting rate | Decided | Wins | Win rate |
|---|---|---|---|---|---|---|
| Tier 1 (fit) | | | | | | |
| Tier 2 (marginal) | | | | | | |
| Tier 3 (no_fit) | | | | | | |
| **Unknown** | | | not rated | | | not rated |

Unknown reasons: [no verdict before the outcome · verdict unreadable · unstable verdict · ...]

### Refuse a rate rather than print a wrong one

| Condition | The cell reads |
|---|---|
| fewer than **10** accounts in the denominator | `only n=7, need 10` |
| the month opened before outcomes recording began | `recording began [date], after this window opened` |
| no outcomes entered for a covered month | `no outcomes recorded. A zero here would be unentered, not measured` |
| days after the covered-through date | counted and listed, but not in any rate until the next pass |

A rate of 0% from a month nobody entered looks exactly like a month where nothing
happened. Only the refusal tells them apart.

If you run two definitions side by side, print this table once per definition, plus one
line per account where the two disagreed and an outcome landed.

## 4. Widen, hold, or pull back

Decide the rule before the first readout, so the readout decides and the mood does not.

| What the readout shows, at or above the minimum count | Decision |
|---|---|
| Tier 1 converts clearly above Tier 2 | hold. The tiering works |
| Tier 2 converts as well as Tier 1 for [two] months running | **widen**. Give Tier 2 Tier 1 treatment |
| Tier 1 converts no better than Tier 2 for [two] months | **pull back**. The definition is not separating buyers. Return to `fit-definition.md` |
| Unknown holds more outcomes than any tier | work the unknown queue first. The rules are missing the accounts that buy |
| Every rate refuses | keep recording. Decide nothing yet |

## Readout

```
OUTCOMES BY TIER · [month] · covered through [date]
────────────────────────────
Tier 1   [__] meetings of [__] routed   [__]% | only n=_, need 10
Tier 2   [__] meetings of [__] routed   [__]% | only n=_, need 10
Unknown  [__] meetings, not rated        reasons: [...]
────────────────────────────
Rule says: [hold | widen | pull back | keep recording]
Decision (a person): _______   Reason: _______   Date: _______
```
