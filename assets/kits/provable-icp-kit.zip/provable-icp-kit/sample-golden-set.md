# The ICP You Can Prove: sample golden set and answer key

Part of the Magnetiz Provable ICP implementation kit. Ten invented companies, labelled
blind, run through the verdict prompt three times and once on a second model. Use it to
test your own setup before you trust it with real accounts. Every name and domain below
is fictional.

Definition used (evidenced profile): US, 50 to 250 employees, private, sells to
businesses, with a stated AI priority and no visible plan to put it into operation.

## The labels (written first, by a person, blind)

| Company | Domain | Label | Note |
|---|---|---|---|
| Keystone Freight Systems | keystonefreight.example | fit | 180 staff, CEO post on an "AI-first" push, no AI roles |
| Oakline Payroll | oaklinepayroll.example | fit | 240 staff, AI ops role open five months |
| Veridian Analytics | veridian.example | no_fit | headquartered in Canada |
| Harbor Lane Dental | harborlanedental.example | no_fit | local practice, serves individuals |
| Tessel Labs | globaltechcorp.example | no_fit | subsidiary on the parent's domain |
| Brightwater Logistics | brightwaterlog.example | marginal | 60 staff, under the band |
| Quarry Point Software | quarrypoint.example | marginal | in band, no AI signal either way |
| Cardinal Parts Supply | cardinalparts.example | fit | 120 staff, automation lead left in the spring |
| Meridian Staffing Group | meridianstaff.example | unknown | LinkedIn says 90, the site says 900. Could not resolve in two minutes |
| Fernhill Industrial | fernhill.example | marginal | 150 staff, AI program run by the training team |

## The agent's verdicts

| Company | Run 1 | Run 2 | Run 3 | Second model | Stable? | Effective | Agrees with label? |
|---|---|---|---|---|---|---|---|
| Keystone Freight | fit | fit | fit | fit | yes | fit | yes |
| Oakline Payroll | fit | fit | fit | fit | yes | fit | yes |
| Veridian Analytics | no_fit | no_fit | no_fit | no_fit | yes | no_fit | yes |
| Harbor Lane Dental | no_fit | no_fit | no_fit | no_fit | yes | no_fit | yes |
| Tessel Labs | no_fit | no_fit | no_fit | no_fit | yes | no_fit | yes |
| Brightwater Logistics | marginal | marginal | marginal | marginal | yes | marginal | yes |
| Quarry Point Software | marginal | fit | marginal | fit | **no** | **unknown** | no |
| Cardinal Parts Supply | fit | fit | fit | marginal | **no** | **unknown** | no |
| Meridian Staffing | unknown | unknown | unknown | unknown | yes | unknown | yes |
| Fernhill Industrial | fit | fit | fit | fit | yes | fit | **no** |

## Reading it

- **Agreement:** 7 of 10 effective verdicts match the labels. The two flips count as
  disagreements, because a flipped verdict cannot route.
- **Stability:** 2 of 10 flipped (20%). That is in the "a rule is ambiguous" band.
- **Quarry Point flipped between fit and marginal.** The rule for "a stated AI priority"
  does not say what counts. One run read a blog post as a priority and another did not.
  The fix is in `fit-definition.md`: name the evidence (an executive statement, a budget
  line, an open role) and say what does not count.
- **Cardinal Parts was stable on one model and not the other.** The departed automation lead
  was found by one model's search and not the other's. The verdict is correct when the
  source is found, so the fix is in the prompt: tell the agent to look for departures
  explicitly.
- **Fernhill was stable and wrong.** Every run said fit. The label said marginal, because the
  AI program sits with the training team, which is a teach-first signal. The rule existed,
  and the agent never applied it. Only the label catches this.
- **Meridian agreed on unknown.** That is a pass. Two sources disagreed and the agent said
  so instead of picking one.

## What a person does with this

1. Rewrites the AI-priority rule to name the evidence that counts.
2. Adds "search for departures of automation or AI roles" to the prompt.
3. Makes the teach-first rule explicit in the definition, with the example.
4. Re-runs the set. Accepts the run when the flips are gone and the disagreements are ones
   they can explain.

Fernhill is the reason both checks exist. Stability alone would have passed it, three
runs out of three.
