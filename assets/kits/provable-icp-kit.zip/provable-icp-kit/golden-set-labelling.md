# The ICP You Can Prove: labelling the golden set

Part of the Magnetiz Provable ICP implementation kit. A golden set is a list of accounts
with the right answer written down by a person, before the agent's answer is seen. It is
the only thing that can tell you the verdict is wrong while the dashboards still look fine.

## Why the usual backtest is not enough

The standard check is a backtest. Take last year's closed-won deals, score them, and
confirm most of them land in Tier 1. It is a good check, and it answers a narrow
question. Would this model have recognised accounts we already won? It does not test the
verdict the routing runs on today, against accounts nobody has closed yet, which is where
every routing decision actually happens.

| | The backtest | The golden set |
|---|---|---|
| What it scores | history, closed accounts | accounts the routing will meet |
| Who wrote the answer | the CRM outcome | a person, blind |
| What it catches | a model that misses past winners | a verdict that drifted after a prompt edit, model change, or rule change |
| When it runs | once, when the model is built | after every change, and on a schedule |

Run both. The backtest says the model was right about the past. The golden set says it
is still right about the field you route on.

## 1. Pick the accounts

| Rule | Why |
|---|---|
| **20 to 30 accounts** | below about 10 the agreement number is noise, so the check refuses to read it |
| **Mix the answers on purpose** | a set of all-fit accounts cannot catch an agent that starts saying fit to everything. Include clear no_fits |
| **Draw from where the routing draws** | your actual inbound, visitor, or list sources, in a fixed order you write down |
| **Include the hard ones** | thin websites, a subsidiary on a parent's domain, a company near the edge of the band |

## 2. Label blind

- [ ] Do not open the agent's rationale, the CRM score, or any earlier verdict for these accounts
- [ ] Use the company's site, its LinkedIn page, and one search. About two minutes each
- [ ] Label against the definition as written in `fit-definition.md`, not the one in your head
- [ ] If you labelled under two definitions, decide each column on its own
- [ ] If you cannot decide, write `unknown` and a reason. That is a valid label

The point is an answer the agent did not produce. A person who has seen the agent's
verdict tends to agree with it, and the set then measures the agent against itself.

## 3. The sheet

```
domain,company_name,declared_label,evidenced_label,note
acme-freight.example,Acme Freight,fit,marginal,
...
```

Labels are `fit`, `marginal`, `no_fit`, or `unknown`. A blank cell is an error, never a
skip. A skipped account quietly shrinks the number the agreement is measured against.

## 4. When to re-label

| Trigger | Re-label |
|---|---|
| The definition in `fit-definition.md` changed | every account |
| A labelled company was acquired, shrank, or moved | that account |
| Six months passed | spot-check [five] at random. If more than one has changed, re-label all |

## Record

| Labelled by | Date | Accounts | Definition version | Time taken |
|---|---|---|---|---|
| | | | | |
