# The ICP You Can Prove: the agreement and stability check

Part of the Magnetiz Provable ICP implementation kit. Two checks run on the golden set.
The first asks whether the agent agrees with the person who labelled it. The second asks
whether the agent agrees with itself. Both have to pass before a verdict is allowed to
route.

## Check 1. Agreement

Run the verdict prompt on every golden account. Only the name and domain go in. Compare
each verdict with the label.

| Account | Label | Agent verdict | Agree? |
|---|---|---|---|
| | | | |

**Agreement** = accounts where the verdict matches the label ÷ accounts scored.

### Setting the threshold

1. Run the set once. Read every disagreement by hand.
2. If the disagreements are the agent's mistakes, fix the prompt or the rules and run again.
   If they are labelling mistakes, fix the label and write down why.
3. When a run looks right to you, accept it. That run's agreement is the **baseline**.
4. Set the threshold about **0.15 under the baseline**.

A threshold at the baseline fails on ordinary run-to-run noise and gets ignored within a
month. A threshold at zero passes everything. Both end in the same place.

| Baseline (accepted run) | Threshold | Minimum accounts scored | Date accepted |
|---|---|---|---|
| | | [two thirds of the set] | |

**Below the minimum, the run is unreadable and does not pass.** A small run that happens
to agree proves nothing, so it fails instead of passing.

## Check 2. Stability

A backtest runs once, so it cannot see this. Run the same golden set [three] times, then
once on a second model. A verdict that changes between runs was not decided by your
rules. It was decided by chance.

| Account | Run 1 | Run 2 | Run 3 | Second model | Stable? | Effective verdict |
|---|---|---|---|---|---|---|
| | | | | | | |

**The rule: a verdict that flips is unknown, never a tier.** It goes to the unknown queue
with the reason "unstable", even when most runs agreed. Majority voting hides exactly the
accounts your rules do not cover.

| Flip rate | What it means | What to do |
|---|---|---|
| 0 to [10]% | the rules decide almost every account | route on the verdict |
| [10] to [25]% | a rule is ambiguous at the edges | read the flipped accounts. They usually share one rule. Rewrite it |
| above [25]% | the definition is not decidable from outside | stop routing on this verdict. Fix `fit-definition.md` first |

## When both checks run

| Trigger | Agreement | Stability |
|---|---|---|
| Prompt edit | yes | yes |
| Model change or upgrade | yes | yes |
| Definition change | re-label first, then yes | yes |
| On a schedule, while the agent runs live | [weekly] | [monthly] |

## The run record

```
FIT VERDICT CHECK · [date] · definition v[__]
────────────────────────────
Agreement   [__] of [__] scored   threshold [__]    → [PASSED | FAILED | UNREADABLE]
Stability   [__] of [__] flipped  limit [__]%       → [PASSED | FAILED]
Flipped:    [account] (fit, marginal, fit) · ...
Disagreed:  [account] (label no_fit, agent fit) · ...
────────────────────────────
Routing on this verdict: [allowed | held]   Decided by: _______   Date: _______
```

A failed check holds the routing. A person reads the flipped and disagreeing accounts,
names the rule that caused them, and decides. The check reports and does not fix.
