# The ICP You Can Prove: the verdict prompt

Part of the Magnetiz Provable ICP implementation kit. One agent, one account at a time,
one verdict per definition. Runs in any model with web search (Claude, ChatGPT, or a Clay
AI column with web access). The output is the field your routing reads, so its shape is
fixed and checked before it lands.

## The prompt

```
You are judging one company against a customer definition. Your verdict decides
whether this company is contacted, so a wrong verdict costs real effort.

THE DEFINITION
{paste sections 1 and 3 of fit-definition.md}

COMPANY: {company}   DOMAIN: {domain}

Search the web. For each rule, find the value and the page you found it on.
Only the company name and domain are given to you. Do not use anything you
remember about this company without finding a source for it this time.

Then give a verdict:
- fit       every checkable rule passes, and you have a source for each
- marginal  near the rules (say which one is near), a real operating company
- no_fit    a rule plainly fails, or a disqualifier applies. Name the rule
- unknown   a source is missing, two sources disagree, or the domain does not
            load this company's own site. Say which

A missing source is unknown, never fit. Do not round unknown up to marginal.

Return JSON only:
{
  "company": "",
  "domain": "",
  "rules": [
    { "rule": "", "value": "", "source_url": "", "evidence_date": "" }
  ],
  "verdict": "fit | marginal | no_fit | unknown",
  "unknown_reason": "",
  "rationale": ""
}
```

## Two definitions, two calls

If you are scoring a declared and an evidenced profile side by side, run the prompt
twice, once per definition, in separate calls. A single call that judges both lets the
first verdict pull the second, and the two stop being independent tests.

## Check the output before it lands

The CRM never reads raw model output. A short script or a Clay formula checks each
result first.

| Check | If it fails |
|---|---|
| The JSON parses and every field is present | reject the row, re-run once, then queue it as unknown |
| `verdict` is one of the four values | reject the row |
| A `fit` has a `source_url` on every rule | downgrade to unknown, reason "unsourced fit" |
| `unknown` carries an `unknown_reason` | reject the row |
| `evidence_date` is within [12] months for the rules that decided it | downgrade to unknown, reason "stale evidence" |

## What the agent never decides

- **The tier boundaries.** Code maps verdicts to routing. The model never picks a channel.
- **Intent.** Whether the account is in market is a separate signal, scored separately.
- **Its own correctness.** That is the golden set's job, in `agreement-and-stability-check.md`.
