# The ICP You Can Prove: the fit definition

Part of the Magnetiz Provable ICP implementation kit. Fill this in before anything is
scored. Every other worksheet in the kit tests the verdict this page defines, so a rule
that two people would apply differently becomes a test that cannot pass or fail.

## Why the definition is one verdict field

Most ICP documents describe a customer. Routing reads one field per account, and that field decides who gets researched, who gets a message,
and who gets ignored. Write the ICP as that field.

| The verdict | What it means | What routing does with it |
|---|---|---|
| **fit** | every checkable rule passes, with a source for each | [outreach, Tier 1, a person's attention] |
| **marginal** | near the rules, a real operating company where the offer could land | [automated sequence, Tier 2] |
| **no_fit** | wrong kind of entity, or a rule plainly fails | [nothing. Record the reason] |
| **unknown** | a source is missing, two sources disagree, or the verdict flipped between runs | [the unknown queue, with an owner. See `outcomes-by-tier-readout.md`] |

The fourth row is the one most ICP models leave out. Without it, an account with thin
data is forced into one of the other three, and the guess routes like a fact.

## 1. The rules, written so a stranger gets your answer

| Rule | Your value | How it is checked |
|---|---|---|
| Headquarters | [country or region] | company site, LinkedIn page |
| Employee band | [e.g. 75 to 300] | LinkedIn employee count, company site |
| Ownership | [private, PE-backed counts, public excluded] | about page, press |
| Model | [sells to businesses] | what the company sells, in its own words |
| The condition you sell into | [your trigger] | often NOT checkable from outside. Say what evidence would count |
| Disqualifiers | [schools, government, agencies, your competitors] | cut on sight |

## 2. Two definitions, side by side

Most teams have two ICPs and only score one. The **declared** profile is the one in the
board deck. The **evidenced** profile is who has actually bought. Write both and score
every account against each, independently, until the evidence picks one.

| | Declared profile | Evidenced profile |
|---|---|---|
| Where it came from | [strategy, the market you want] | [the deals you actually closed, read from the CRM] |
| Size band | | |
| Buyer seat | | |
| The condition | | |
| Signals that count IN | | |
| Signals that count OUT | | |
| Deals it explains | [how many closed deals fit it] | [how many closed deals fit it] |

**The rule for retiring one:** a definition is retired when the outcomes readout shows
the other one's tiers converting and its own not, at a count above the minimum. Not
before, and not on how the closed deals feel in a meeting.

## 3. What decides the verdict, and what never does

| Decides | Never decides |
|---|---|
| a rule with a source attached | what the model remembers about the company |
| evidence younger than [12] months | a single source when two disagree (that is unknown) |
| the domain's own site | a parent company's domain or headcount |
| | intent signals. Fit and intent are separate fields. Mixing them makes both untestable |

## Sign-off

| Who owns this definition | Last changed | Golden set re-labelled after the change? |
|---|---|---|
| [name] | [date] | [ ] yes. A changed definition makes the old labels a test of the old rules |
