# CRM Enrichment With Change Review — the review checklist

Part of the Magnetiz CRM Enrichment implementation kit. A person approves before the
record moves. Seconds per change, because the preview did the work.

## The preview format (what the reviewer sees)

```
[Company name] · 4 proposed changes · agent run [date]
─────────────────────────────────────────────
  employee_count   140  →  210        source: company careers page, Mar 2026   HIGH
  title (J. Ríos)  Dir Ops → VP Ops   source: profile, updated last week       HIGH
  industry         blank → logistics  source: company site                     HIGH
  revenue          $18M → $25M        source: news estimate, undated           LOW ⚠
─────────────────────────────────────────────
[Approve all high] [Pick individually] [Reject all] · every source is a link
```

## The reviewer's three questions, per change

1. Does the source actually say this? (Click it. It is one click by design.)
2. Is it fresher than what it replaces?
3. Would I act on this value in a deal? If not, reject; a rejected proposal costs
   nothing, a wrong record costs a bad call later.

## Rules

- Low-confidence and human-value-conflicting changes are never in "approve all."
- Rejections get logged with a word of reason; they are the agent's error data.
- **Graduation.** After [20] reviews where a field class was approved every time, that
  class may auto-apply, still logged and reversible. Owner, stage, amounts, and human
  prose never graduate.
- Every applied change stores the prior value. Undo is one click, forever.
