# CRM Enrichment With Change Review — the review checklist

Part of the Magnetiz CRM Enrichment implementation kit. A person approves before the
record moves. Seconds per change, because the preview did the work.

## The preview format (what the reviewer sees)

```
[Company name] · 4 proposed changes · agent run [date]
─────────────────────────────────────────────
  employee_count   140  →  210        source: company careers page, Mar 2026   HIGH
  title (J. Ríos)  Dir Ops → VP Ops   source: profile, updated last week       HIGH
  industry         blank → logistics  source: company site                     HIGH
  title (M. Chen)  blank → Dir Ops    source: conference speaker page, undated LOW ⚠
─────────────────────────────────────────────
  CONFLICT  revenue: CRM says $18M · invoice system says $25M — a person picks
  UNKNOWNS  funding stage, employee region split (searched, not found)
  SUPPRESSED (2)  older-than-current proposals, collapsed — view why
─────────────────────────────────────────────
[Approve all HIGH] [Pick individually] [Reject all] · every source is a link
```

The revenue conflict is in the conflict block, never in the proposals, because the
survivorship table blocks revenue proposals from estimates before review. Conflicts and
unknowns always render; a rule that says "never silently resolved" needs a place on the
screen, or the screen silently resolves it.

## The reviewer's three questions, per change

1. Does the source actually say this? (Click it. It is one click by design.)
2. Is it fresher than what it replaces?
3. Would I act on this value in a deal? If not, reject; a rejected proposal costs
   nothing, a wrong record costs a bad call later.

## Rules

- "Approve all" covers HIGH only. Medium rides with low through individual review,
  because confident wrongness is the expensive failure and medium is not confidence.
- Human-value-conflicting changes are never in any bulk action.
- Rejections get logged with a word of reason; they are the agent's error data.
- **Graduation requires BOTH instruments.** An approval streak measures reviewer
  agreement; the eval measures correctness; a field class auto-applies only when both
  hold: [20] consecutive approvals with zero rejections (one rejection resets the
  streak to zero) AND a passing golden-records score on that field class. Owner, stage,
  amounts, and human prose never graduate. Graduation here means what it means in every
  Magnetiz playbook: a pre-committed streak of consecutive clean, dated checks against
  named failure modes, with the threshold set before you start.
- Every applied change stores the prior value. **Undo restores only when the current
  value still equals what this change wrote; anything else means a human edited after,
  and the undo surfaces as a conflict for a person instead of clobbering their entry.**

## The review has an owner and a clock

| Question | Your answer |
|---|---|
| Who drains the review queue, by name | |
| Drain cadence (starting point: daily) | |

Review is synchronous with the pipeline: proposals sit unapplied until a person acts,
so an undrained queue means records stay wrong while the system reports it is working.
