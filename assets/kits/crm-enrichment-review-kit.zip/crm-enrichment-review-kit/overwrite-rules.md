# CRM Enrichment With Change Review — overwrite rules

Part of the Magnetiz CRM Enrichment implementation kit. Silent overwrites are how trust
dies. These rules decide what may even be PROPOSED over what exists.

## Freshness

- Every fact carries its source_date. A proposal older than the current value's date is
  discarded before review; stale evidence never challenges fresh.
- Fields decay at different speeds. Set a shelf life per field: titles [90] days,
  headcount [180], industry [rarely changes]. Past shelf life, the current value is
  challengeable; inside it, a proposal needs a HIGH-confidence, newer source.

## Survivorship (which source may propose over which)

| Field | May be proposed from | Never overwritten from |
|---|---|---|
| Title | fresh public profile, company site | aggregator older than profile |
| Revenue / size | filings, company statements | inferred estimates |
| Owner, deal fields | NEVER proposed by enrichment | everything — human territory |
| Notes a human wrote | NEVER | everything |

## The two hard walls

1. **Human-entered values outrank enriched values by default.** A proposal against a
   human entry is flagged as exactly that in the review, and the reviewer decides.
2. **Some fields are never enrichment's to touch.** Owner, stage, amounts, and anything
   a human wrote prose into. This is the do-not-touch list, the same artifact the
   AI-Ready Data playbook maintains — one list, maintained once, checked at every write
   path. List yours here: ______________________
