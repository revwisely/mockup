# CRM Enrichment With Change Review — spend gates

Part of the Magnetiz CRM Enrichment implementation kit. Enrich only what something will
use. An enrichment nobody reads is a bill with no customer.

## The gate, per record

A record earns enrichment when ANY of these is true, and queues otherwise.

- [ ] A workflow downstream will read the enriched fields this week
- [ ] A person asked for this record by name
- [ ] The record just entered a route that requires the fields (e.g. qualified inbound)

## The caps

| Cap | Value | Why |
|---|---|---|
| Records enriched per day | [ ] | the daily bill has a ceiling before the month starts |
| Re-enrichment of the same record | not within [30] days unless a person asks | freshness has a price; churn is not freshness |
| Sources per record per run | [ ] | diminishing returns arrive fast |

## The queue

Records that miss the gate queue rather than burn. The queue drains inside the cap,
oldest first, and a person can jump any record to the front. A growing queue is a
signal to raise the cap deliberately, never a reason to bypass the gate.
