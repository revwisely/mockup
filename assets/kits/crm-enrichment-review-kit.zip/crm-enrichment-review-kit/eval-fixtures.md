# CRM Enrichment With Change Review — the golden-records eval

Part of the Magnetiz CRM Enrichment implementation kit. The eval is the difference
between an agent you tested once and an agent you can keep trusting.

## Build the golden set (one hour, once)

1. Pick [5] accounts you know cold. A client, a lost deal, your own company, a famous
   company in your space, and one genuinely obscure one.
2. Write down the truth: the fields, the correct values, and the best public source for
   each. This answer sheet is the asset; keep it out of the agent's reach.
3. Blank the fields on COPIES of the records. Never run evals against live records.

## Score a run (per golden record)

| Measure | Count |
|---|---|
| Correct proposals (value right, source real) | |
| Wrong proposals (value wrong, stated confidently) | |
| Hallucinated sources (link dead or does not say it) | |
| Honest unknowns (blank where truth was findable = miss; blank where it is not = correct) | |
| Conflicts correctly surfaced as conflicts | |

**A wrong-but-confident proposal costs 5x a miss.** Score accordingly. The failure mode
that kills trust is never the gap, it is the confident fiction.

## When to re-run

- Before first trusting the agent (obviously).
- Whenever the prompt, the model, or the source strategy changes.
- Monthly regardless, because the web under the agent changes without telling you.

Keep every run's scores. The trend line is the drift detector, and a clean run today
with a declining trend is a warning, not a pass.
