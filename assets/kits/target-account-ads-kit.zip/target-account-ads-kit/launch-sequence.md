# Target Account Ads: the launch sequence

Part of the Magnetiz Target Account Ads implementation kit. The ads and the outreach use
the same list, in a set order. Ads introduce you, outreach asks for the meeting, and the
person receiving your first message has already seen your name.

## 1. Check the audience size before you design the campaign

LinkedIn will not serve a matched audience below **300 members**. A company list is
matched to people over roughly two days, and the member count you get back is always
smaller than the companies you uploaded times their headcount, because not everyone is
on LinkedIn and your job filters narrow it again.

| Layer | Companies uploaded | Members matched | After job filters | At or above 300? |
|---|---|---|---|---|
| Account list | | | | |
| Website visitors (retargeting) | n/a | | | |
| Engaged with your ads or page | n/a | | | |

**If a layer is under 300, do not build it yet.** A layer below the minimum sits in the
campaign doing nothing, and nobody notices for weeks. Fix it in this order:

1. Loosen seniority (for example, Director and up to Manager and up).
2. Remove the job function filter.
3. Combine the list with your retargeting audience in one campaign.
4. Run the accounts as outreach only until the list grows.

Never grow the list by adding back companies the list check cut.

## 2. The order of operations

| Day | Ads | Outreach | Who |
|---|---|---|---|
| 0 | campaign launches on the list | nothing yet | [ads owner] |
| [7] | running | first connection request or message goes out | [outreach owner] |
| [7 to 28] | running | the sequence continues | [outreach owner] |
| any day | the account leaves the audience | the account leaves the sequence | whoever sees the trigger |

The gap on day 0 to [7] is the whole method. Launching ads and outreach on the same day
means the same money and the same effort, with no introduction before the ask.

## 3. What removes an account from both

Suppression runs in both directions. When any of these happens, the account comes off
the ad audience AND out of the sequence.

- [ ] Replied (any reply, including a no)
- [ ] Booked a meeting
- [ ] Became a customer or an open deal
- [ ] Asked not to be contacted
- [ ] [your own trigger]

| Trigger | Who removes it from the ads | Who removes it from outreach | How fast |
|---|---|---|---|
| | | | |

LinkedIn company lists cannot always be edited in place. If yours cannot, keep the
exclusion list current and re-upload it [weekly].

## 4. Tools, named

| Job | Tool | Owner |
|---|---|---|
| The list and suppression | [CRM, e.g. HubSpot or Salesforce] | |
| The list check | [Claude, ChatGPT, or a Clay AI column] | |
| The ads | LinkedIn Campaign Manager | |
| The outreach | [HeyReach, Sales Navigator, or your sequencer] | |
| The weekly readout | [the same model, reading an export] | |
