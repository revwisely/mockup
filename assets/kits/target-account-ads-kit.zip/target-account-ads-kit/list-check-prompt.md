# Target Account Ads: the list-check agent

Part of the Magnetiz Target Account Ads implementation kit. One agent, two passes, one
output file a person reads before anything is uploaded. Runs in any model with web search
(Claude, ChatGPT, or a Clay AI column with web access).

## Pass 1. The screen (no web search, fast)

Cuts the obvious rows from the name and domain alone. Cheap, and it removes most of the
noise before the expensive pass.

```
You are screening a list of companies for a LinkedIn ad audience.

THE RULES
{paste sections 1 to 3 of account-rules.md}

For each row, decide from the company name and domain ONLY:
- CUT if it plainly matches an automatic exclusion (a school, a government body,
  a nonprofit, a fund) or the domain obviously belongs to a very large company
  (see "the domain trap").
- PASS otherwise. Do not guess. If you are not sure, PASS it to the research pass.

Return one line per row:
company, domain, verdict (CUT | PASS), reason (one short line, required on every CUT)
```

## Pass 2. The research (web search, one company at a time)

Runs only on the PASS rows. Each company is checked against sources, never against what
the model remembers.

```
You are verifying one company for a LinkedIn ad audience.

THE RULES
{paste sections 1 to 3 of account-rules.md}

COMPANY: {company}   DOMAIN: {domain}

Search the web. Find:
1. Headquarters country
2. Ownership (independent private, PE-backed, public, or a subsidiary. If a
   subsidiary, name the parent)
3. Employee count (give the number and where you found it)
4. Whether the domain loads this company's own site or redirects elsewhere

Then give a verdict:
- KEEP only if every checkable rule passes and you found a source for each.
- CUT if any rule fails. Name the rule.
- UNSURE if a source is missing or two sources disagree. Say which.

Never mark KEEP from memory alone. A missing source is UNSURE, not KEEP.

Return JSON:
{
  "company": "",
  "domain": "",
  "hq_country": "",
  "ownership": "",
  "parent": "",
  "employees": "",
  "domain_resolves_to_self": true,
  "confidence": "high | medium | low",
  "source_url": "",
  "verdict": "KEEP | CUT | UNSURE",
  "reason": ""
}
```

## What the agent never decides

- **The upload.** A person reads every CUT reason and every UNSURE row, then uploads.
- **Whether the company is a buyer.** The agent checks firmographics. Fit beyond that
  (the situation you sell into) belongs to the ad and the first conversation.
- **Adding companies back.** If the list comes back small, the fix is a looser targeting
  setting on the campaign, never re-adding rows the check cut.

## Spot-check before you trust it

Pick [three] CUT rows and [two] KEEP rows at random and check them yourself. If any is
wrong, fix the rule that produced it and rerun. Record what you checked:

| Row | Agent verdict | Your verdict | Rule fixed? |
|---|---|---|---|
| | | | |
| | | | |
| | | | |
