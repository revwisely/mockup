# Target Account Ads: the gate card and the weekly readout

Part of the Magnetiz Target Account Ads implementation kit. The numbers that decide the
campaign are written down before it launches. Each week an agent fills in the readout, and
a person decides to continue, change, or stop.

## The gate card (fill in before launch)

Write the number, the date you read it, and what happens under each outcome. If you
cannot say what you would do differently at a given number, it is not a gate.

| Gate | Read on | The number that decides | If it passes | If it fails |
|---|---|---|---|---|
| Delivery | day [3] | ads are serving on LinkedIn's feed at a normal CPM | keep running | recheck the settings, see `campaign-settings-check.md` |
| Reach | day [7] | [__]% of listed companies have seen an ad | open the outreach sequence | check the size layer, see `launch-sequence.md` |
| Response | day [14] | [__] clicks or engagements from listed companies | continue | change one thing: the creative, or the job filters |
| Outcome | day [28] | [__] replies or meetings from accounts that saw ads first | keep the budget | stop, and write down which gate named the problem |

**Read each number where your tool actually shows it.** If the gate says "companies
reached" and Campaign Manager only shows impressions, find the report that shows
companies (the company engagement report) before launch, or rewrite the gate.

## The readout prompt

```
You are writing the weekly readout for a LinkedIn target account campaign.

THE GATE CARD
{paste the filled gate card}

THIS WEEK'S DATA
{paste the Campaign Manager export, the company engagement report, and the
 outreach tool's reply and meeting counts for the same accounts}

Write:
1. Which gate is due this week, its number, and the actual number.
2. PASSED, FAILED, or CANNOT READ (the data needed is not in what you were given).
3. The accounts that engaged, by name, with what they did.
4. One line on what the gate card says happens next.

Do not recommend a decision beyond what the gate card says. Do not explain a miss
with a theory the data does not show.
```

## The readout, as it lands

```
TARGET ACCOUNT ADS · week [2] · gate: Response (day 14)
────────────────────────────
Needed: [__] engagements from listed companies
Actual: [__]                                       → [PASSED | FAILED]
────────────────────────────
Engaged: [Company A] (3 clicks, 1 page follow) · [Company B] (1 click)
Gate card says: [continue | change one thing | stop]
Decision (a person): _______   Reason: _______   Date: _______
```

## The decision is a person's

The agent reports. A person decides and writes one line of reason. When a campaign stops,
the reason names the gate that failed, so the next campaign fixes that layer rather than
rewriting the ads by default. Most failed campaigns fail on the list or the settings,
which a new ad does not fix.
