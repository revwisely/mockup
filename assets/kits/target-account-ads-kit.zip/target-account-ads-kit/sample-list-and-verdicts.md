# Target Account Ads: sample list and verdicts

Part of the Magnetiz Target Account Ads implementation kit. Ten invented companies run
through both passes of `list-check-prompt.md`, with the answer key. Use it to test your
own prompt before you trust it with a real list. Every name and domain below is fictional.

Rules used: US headquarters, independent private or PE-backed, 25 to 500 employees,
B2B. Domain trap threshold 5x the top of the band (2,500 employees).

## Pass 1. The screen

| Company | Domain | Verdict | Reason |
|---|---|---|---|
| Northgate State University | northgate.edu | CUT | university |
| Harlow County Transit | harlowtransit.gov | CUT | government |
| Bramble Ventures | brambleventures.com | CUT | investment fund |
| Keystone Freight Systems | keystonefreight.com | PASS | |
| Veridian Analytics | veridian-analytics.com | PASS | |
| Oakline Payroll | oaklinepayroll.com | PASS | |
| Tessel Labs | globaltechcorp.com | PASS | name and domain disagree, research it |
| Marrow & Finch Legal | marrowfinch.com | PASS | |
| Solace Home Goods | solacehome.com | PASS | |
| Cardinal Parts Supply | cardinalparts.com | PASS | |

The screen cuts only what the name makes obvious. Tessel Labs passes because the
mismatch needs a source, not a guess.

## Pass 2. The research

| Company | HQ | Ownership | Employees | Verdict | Reason |
|---|---|---|---|---|---|
| Keystone Freight Systems | US | PE-backed | ~180 | **KEEP** | all rules pass, sources for each |
| Veridian Analytics | Canada | private | ~90 | **CUT** | HQ outside the US |
| Oakline Payroll | US | private | ~340 | **KEEP** | all rules pass |
| Tessel Labs | US | subsidiary of Global Tech Corp | parent ~40,000 | **CUT** | domain trap. The domain belongs to the parent, so the list would match the parent's whole workforce |
| Marrow & Finch Legal | US | private | ~60 | **CUT** | family law practice, serves individuals, not businesses |
| Solace Home Goods | US | private | ~120 | **CUT** | consumer retail |
| Cardinal Parts Supply | US | private | 40 or 600, two sources disagree | **UNSURE** | the LinkedIn page and the company site give different headcounts |

## What a person does with this

- Reads the four CUT reasons. They hold.
- Opens Cardinal Parts Supply. The company site counts all locations including a
  distribution partner; LinkedIn shows about 45 staff. **Flips to KEEP** and writes down
  why.
- Uploads three companies: Keystone, Oakline, Cardinal.

Three companies is too few for a LinkedIn audience on its own (see
`launch-sequence.md`, the size check). The right response is a looser seniority setting
or running these accounts as outreach targets only. It is never re-adding the seven the
check cut.
