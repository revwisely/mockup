# Target Account Ads: the account rules

Part of the Magnetiz Target Account Ads implementation kit. Fill this in before anyone
builds a list. The agent in `list-check-prompt.md` screens every company against these
rules, so a vague rule here becomes a wrong audience later.

## Why rules come first

LinkedIn will serve ads to whatever list you hand it and report the results as normal.
A list built from the wrong kind of company spends at the usual rate, shows the usual
dashboard, and never tells you who actually saw the ads. The rules are the only place
that mistake gets caught cheaply.

## 1. The class test

Write each rule so a stranger could apply it to one company and get your answer.

| Rule | Your value | How it is checked |
|---|---|---|
| Headquarters country | [United States] | company site, LinkedIn page |
| Ownership | [independent private, PE-backed counts] | about page, press, acquisition news |
| Employee band | [25 to 500] | LinkedIn employee count, company site |
| Industry or model | [B2B, sells to other businesses] | what the company sells, in its own words |
| The situation you sell into | [your trigger, e.g. "has a stalled internal AI project"] | usually NOT checkable from outside. Leave it to the ad and the first call |

The last row is the honest one. Most of what makes a company a real buyer cannot be seen
from a website. The list checks what it can check and stops there.

## 2. Automatic exclusions

Cut on sight, no research needed.

- [ ] Schools, universities, and research institutes
- [ ] Government and military
- [ ] Nonprofits and religious organisations
- [ ] Investment funds and VC firms (unless funds are your buyer)
- [ ] Your current customers and anyone in an open deal (see suppression below)
- [ ] Your own company and your parent or sister companies
- [ ] Competitors
- [ ] [add your own]

## 3. The domain trap

**LinkedIn company lists match on the company website domain.** A row with a small
subsidiary's name and its giant parent's domain (a division of a global bank, a regional
office of a big consultancy, a startup that was acquired and now redirects) matches the
parent. Your ads then go to a global company's whole workforce while the matched count
looks healthy.

The rule, written so the agent can apply it:

> If the domain belongs to a company more than [5x] the top of your employee band, or
> redirects to a different company's site, CUT the row and record the parent's name.

## 4. Suppression, both directions

| List | Who is on it | Where it is maintained | Owner |
|---|---|---|---|
| Customers | every paying account | [CRM view name] | [name] |
| Open deals | anyone past first meeting | [CRM view name] | [name] |
| Do not contact | explicit opt-outs, from every channel | [CRM view name] | [name] |
| Recently lost | closed-lost in the last [90] days | [CRM view name] | [name] |

These accounts leave the ad audience AND the outbound sequence. Upload them as a
LinkedIn exclusion list so the suppression lives in the platform, not in someone's memory.

## 5. Where the list comes from

Write down the source so the next list can be rebuilt the same way.

| Source | Filter used | Date pulled | Row count |
|---|---|---|---|
| [CRM, target account view] | | | |
| [website visitor identification] | | | |
| [enrichment tool search] | | | |
