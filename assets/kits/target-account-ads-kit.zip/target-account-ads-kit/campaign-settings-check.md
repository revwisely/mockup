# Target Account Ads: the campaign settings check

Part of the Magnetiz Target Account Ads implementation kit. Fill in the worksheet once.
Then, before every launch, an agent compares the campaign as it is actually configured
against this worksheet and lists every difference. A person approves the launch.

## Why an agent checks, and not the person who built it

The person who built the campaign reads what they meant to set. LinkedIn's defaults are
set in LinkedIn's favour, and two of them quietly move your spend away from your list.
A second reader that only knows the worksheet catches what the builder skims past.

## The worksheet

| Setting | What it should be | Why | Checked |
|---|---|---|---|
| **Objective** | [Website visits, or Engagement for thought leader ads] | Locked once the campaign is created. Changing it means a new campaign. Awareness objectives optimise for impressions, which the platform can always deliver | [ ] |
| **Audience** | the uploaded company list, plus [job function and seniority] | the list is the point. Everything else narrows it | [ ] |
| **Exclusions** | the suppression list from `account-rules.md` | customers and open deals never see prospecting ads | [ ] |
| **LinkedIn Audience Network** | **OFF** | ON serves your ads in other apps and sites. Impressions get cheap and stop being your list | [ ] |
| **Audience expansion** | **OFF** | ON adds people "similar" to your audience. On an account list, that means people outside the list | [ ] |
| **Conversion tracking** | [named events, e.g. booked call, key page view] | a campaign with no conversion defined can only report impressions | [ ] |
| **Budget and schedule** | [daily cap, start date, end date] | an end date forces the readout to happen | [ ] |
| **Bid strategy** | [maximum delivery, or a manual cap] | fine either way at small budgets. Write down which | [ ] |
| **Creative count** | [2 to 4 ads] | enough to compare, few enough that each gets served | [ ] |

## The check prompt

Give the agent this worksheet and the campaign as configured. The configuration can come
from the LinkedIn Marketing API (the campaign record lists the objective, targeting, and
both network flags), a CSV export, or screenshots of the campaign review screen.

```
You are checking a LinkedIn ad campaign before launch.

THE WORKSHEET (what the campaign should be)
{paste the filled worksheet}

THE CAMPAIGN AS CONFIGURED
{paste the API record, export, or describe the screenshots}

For every row of the worksheet, compare the intended value with the configured value.
Return a table: setting, intended, configured, MATCH | DIFFERENT | CANNOT SEE.

Rules:
- Audience Network ON or audience expansion ON is always DIFFERENT, even if the
  worksheet row was left blank.
- If you cannot find a setting in what you were given, say CANNOT SEE. Never assume
  the default.
- End with one line: READY TO LAUNCH, or NOT READY and the rows that block it.
```

## After launch, one more check

Read the first [3] days of delivery. If the cost per thousand impressions is far below
what LinkedIn normally charges for your audience, the ads are probably running somewhere
other than LinkedIn's feed. Cheap is the warning sign here.

| Day | Impressions | CPM | Within the normal range? |
|---|---|---|---|
| 1 | | | |
| 2 | | | |
| 3 | | | |
