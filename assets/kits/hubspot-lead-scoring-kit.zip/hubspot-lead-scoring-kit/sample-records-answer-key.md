# Ten sample records with the answer key

Part of the Magnetiz HubSpot Lead Scoring implementation kit.

Grade these ten by hand against the sample model below before you build your own. Then check the
answer key. The traps are the ones a points model gets wrong when nobody looks.

The company, the model and the records are made up for illustration.

## The sample model

*The example company sells revenue software to B2B firms of 100 to 500 people in North America.*

| Group | Criterion | Points |
|---|---|---|
| Fit | Employee count between 100 and 500 | +25 |
| Fit | Industry is B2B software or business services | +20 |
| Fit | Job title is VP or Director of Sales, Marketing or Revenue Operations | +20 |
| Fit | Headquarters in the US or Canada | +10 |
| Fit | Email domain is a school, government body or competitor | -100 |
| Engagement | Demo request submitted | +40 |
| Engagement | Pricing page viewed (counted once, decays after 3 months) | +15 |
| Engagement | Webinar attended | +10 each |
| Engagement | Marketing email clicked (capped at 10 points) | +2 each |

The fit letter is A at 60 points or more, B at 30 to 59 and C under 30. The engagement number is 1
at 40 or more, 2 at 15 to 39 and 3 under 15.

## The records

| # | Record | Your grade | Your action |
|---|---|---|---|
| 1 | VP Sales, 240-person B2B software company in Toronto, demo request yesterday | | |
| 2 | Director of RevOps, 180-person services firm in Denver, no activity in 4 months | | |
| 3 | Student at a state university, 6 pricing page views, 2 webinars, 9 email clicks | | |
| 4 | Marketing Manager, 320-person software company in Austin, pricing page viewed twice this week | | |
| 5 | VP Marketing at a 90-person software company in Boston, demo request | | |
| 6 | VP Sales, Number of employees blank, Industry blank, demo request | | |
| 7 | Analyst at a known competitor, 14 email clicks and 3 webinars | | |
| 8 | VP Revenue Operations at a software subsidiary in Seattle, on its 4,000-person parent's domain, demo request | | |
| 9 | Director of Sales, 260-person B2B software company in London, pricing page and webinar | | |
| 10 | Director of Marketing, 150-person software company in Chicago, 11 pricing views 5 months ago, nothing since | | |

## Answer key

| # | Fit points | Engagement points | Grade | Action | Why |
|---|---|---|---|---|---|
| 1 | 75 | 40 | A1 | rep within 1 day | the case the score is for |
| 2 | 75 | 0 | A3 | nurture, monthly review | right company, quiet. A sequence, never a discard |
| 3 | -100 | 45 (pricing 15, webinars 20, clicks capped at 10) | C1 | resource only | the busiest record in the set, and it cannot buy. The disqualifier is what keeps it out of A |
| 4 | 55 | 15 | B2 | nurture | right company, wrong seat. A rep may still check who the buyer is |
| 5 | 50 | 40 | B1 | rep reviews first | just under the size band. Review, since the band edge is a judgment |
| 6 | 20 (title only) | 40 | review list | person fills the blanks | missing data scores like a fail. Without the review list this would be C1 and a real buyer gets ignored |
| 7 | -100 | 40 (webinars 30, clicks capped at 10) | C1 | none | competitor. Engagement alone would have made it a top lead |
| 8 | 50 on paper | 40 | B1 | rep reviews first, checks the subsidiary's own headcount | the size on the domain belongs to the parent. If the subsidiary itself is inside the band, it is an A1 |
| 9 | 65 | 25 | A2 | rep within 3 days | the region rule fails and it still grades A. Decide if London is in market before routing |
| 10 | 75 | 0 after decay | A3 | nurture | decay worked. Five months ago this read as A2 |

Records 3, 6, 7 and 8 are the traps. If your own model would route any of them to a rep without a
person looking, fix that before the backtest.
