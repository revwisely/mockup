# Fit rules

Part of the Magnetiz HubSpot Lead Scoring implementation kit.

Fill this in first, before any points are set. Fit decides who could buy, and every later sheet
reads it.

## Why start from the deals you closed

Your closed deals show who actually buys. Write the rules from them, set them beside the profile in
your strategy deck, and let the backtest (`backtest.md`) pick.

## 1. Pull the deals

Export closed-won and closed-lost deals from the last 12 months, with the associated company.

| Field to export | HubSpot property (check the internal name in your portal) |
|---|---|
| Deal stage and close date | Deal stage, Close date |
| Company size | Number of employees |
| Industry | Industry |
| Region | Country/Region |
| Who signed or led the deal | the primary contact's Job title |
| Lost reason | your closed-lost reason property |

## 2. Write the rules

Write each rule so two people applying it get the same answer.

| Rule | Your value | Evidenced by closed deals? (how many of your wins match) | Where it is checked |
|---|---|---|---|
| Employee band | [e.g. 100 to 500] | [e.g. 31 of 40 wins] | Number of employees, LinkedIn company page |
| Industry | [your industries] | | Industry property |
| Region | [your markets] | | Country/Region |
| Buyer seat | [titles that signed or led] | | contact Job title |
| [your own rule] | | | |

"Mid-market and growing" is an opinion. "Employee count between 100 and 500, checked on the LinkedIn
company page" is a rule.

## 3. Disqualifiers

These get large negative points, so no amount of engagement can lift them into a top grade.

| Disqualifier | How it is spotted | Points |
|---|---|---|
| Student or school | email domain ends in .edu or a school name | -100 |
| Government body | email domain, Industry | -100 |
| Competitor | your list of competitor domains | -100 |
| Agency or consultant reselling | Industry, company description | [decide] |
| [your own] | | |

## 4. Missing data

HubSpot points cannot tell "checked and failed" apart from "never filled in". Both score zero.

So list the fit properties that must be filled before a score is trusted. A record missing any of
them goes to the review list in `grade-actions.md`, where a person looks it up.

| Required before the score counts | Filled on what share of your contacts today |
|---|---|
| Number of employees | [%] |
| Industry | [%] |
| Job title | [%] |

If a required property is filled on under half your records, fix the data before tuning the points.
