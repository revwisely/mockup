# Monthly readout

Part of the Magnetiz HubSpot Lead Scoring implementation kit.

Read it once a month, after the score has routed for a full month. The backtest said the score
ranks the past correctly. This says whether it is ranking the accounts it meets now.

## Why credit the grade from before the month

A meeting raises engagement, so an account often moves up a grade after it has already converted.
Crediting the new grade would let the outcome promote the account after the fact. Credit the grade
the account held on the first day of the month.

HubSpot keeps score history (see its article on lead score history and performance). If your tier
does not show it, export the grades to a sheet on the first of each month.

## 1. The rule, signed before the first read

| Field | Our answer |
|---|---|
| What we count | opportunities created per account worked, by grade held on the first of the month |
| Compared | A1 and A2 against A3 and B together |
| The chance that counts | [we use 90%, the chance that A1 and A2 really convert better] |
| Read on | [first business day of each month] |

## 2. Look the counts up

With 50 A1 and A2 accounts worked and 120 A3 and B accounts worked.

| Opportunities, A1-A2 vs A3-B | Chance A1-A2 really convert better | Range of the gap |
|---|---|---|
| 10 of 50 vs 8 of 120 | 99.4% | 4 to 24 points |
| 8 of 50 vs 10 of 120 | 93%, past the line | -1 to 18 points |
| 6 of 50 vs 10 of 120 | 80%, too close to call | -4 to 14 points |
| 5 of 50 vs 12 of 120 | 55%, no difference yet | -7 to 10 points |

One month is often too few accounts to call. Pool the months until the chance passes the line or
the range rules out a useful gap.

## 3. The decision

| The read shows | Decision |
|---|---|
| The chance that counts or better | **Keep.** Re-run the backtest after any rule change |
| Too close to call | **Keep recording.** Pool next month's counts with this one |
| No difference after three pooled months | **Back to the fit rules.** The top grades are not converting better, so the line between them is costing rep time and deciding nothing |
| The review list is growing every month | **Fix the data.** Missing fit properties are the problem, not the weights |

## 4. The record

| Month | A1-A2 worked | A1-A2 opportunities | A3-B worked | A3-B opportunities | Chance | Review list size | Decision | Signed by |
|---|---|---|---|---|---|---|---|---|
| | | | | | | | | |
