# HubSpot build sheet

Part of the Magnetiz HubSpot Lead Scoring implementation kit.

Use this when the fit rules and the engagement evidence are filled in. It records how the score
is built in HubSpot, so the next person can read it without opening the tool.

HubSpot details below are from its knowledge base (Overview of the lead scoring tool, updated
2026-09-02; Build lead scores, updated 2026-08-14). Check those pages before building, since
HubSpot updates them often.

## 1. What you need

| Check | Yes / no |
|---|---|
| Marketing Hub or Sales Hub, Professional or Enterprise | |
| Contact scores need Marketing Hub. Company scores work with Marketing Hub or Sales Hub. Deal scores need Sales Hub | |
| AI-drafted contact scores need Marketing Hub Enterprise, and at least 50 contacts (25 converted, 25 not) | |

The tool is under Marketing, then Lead Scoring.

## 2. Build the new score beside the old one

HubSpot allows more than one score per object. Build the new model as its own score and leave any
existing score running until the backtest reads.

| Field | Our value |
|---|---|
| Score name | [e.g. Company fit and engagement v2, 2026-11] |
| Object | Contact / Company / Deal |
| Type | Combined (fit and engagement) |
| Fit groups and criteria | from `fit-rules.md` |
| Engagement groups and criteria | from `engagement-evidence.md` |
| Score limit per group | |
| Decay (engagement groups only) | interval, amount |
| Thresholds | HubSpot's combined grades run A1 to C3. The letter is fit (A high), the number is engagement (1 high) |

## 3. Check it is calculated as designed

HubSpot lets you test an individual record and preview the score distribution (in large portals the
preview uses a sample of about 20% of eligible contacts).

| Check | Result |
|---|---|
| Test 3 records you know are a strong fit. Do they grade A? | |
| Test 3 known disqualifiers. Do they grade C? | |
| Preview the distribution. What share lands in A1 and A2? | |

These checks confirm the arithmetic. Whether the score ranks buyers is the job of `backtest.md`.

## 4. Change log

Every change to a rule, a weight or a threshold gets a line. The backtest is re-run after each one.

| Date | What changed | Why | Backtest re-run? | Changed by |
|---|---|---|---|---|
| | | | | |
