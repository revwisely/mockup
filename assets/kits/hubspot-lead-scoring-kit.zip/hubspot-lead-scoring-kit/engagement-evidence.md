# Engagement evidence

Part of the Magnetiz HubSpot Lead Scoring implementation kit.

Fill this in after the fit rules. It decides which actions earn engagement points, from what
happened before your deals, instead of from what feels like interest.

## Why check each event against wins and losses

An event earns points when it shows up more often before wins than before losses. A pricing page
view that appears on 70% of wins and 70% of losses tells you someone was shopping. It does not tell
you who buys.

## 1. Count each event before the deal was created

For each closed **build deal** (never the test deals set aside in `fit-rules.md`), look at the associated contacts' activity in the 90 days before the deal was
created.

Activity after the deal opened is the sales process, and counting it would credit the
event for the rep's work.

| Event | Wins where it happened (of [n]) | Losses where it happened (of [n]) | Share of wins | Share of losses | Earns points? |
|---|---|---|---|---|---|
| Demo request form submitted | | | | | |
| Pricing page viewed | | | | | |
| Case study or comparison page viewed | | | | | |
| Webinar or event attended | | | | | |
| Marketing email clicked | | | | | |
| Content download | | | | | |
| [your own] | | | | | |

## 2. Set the points from the gap

| Gap between share of wins and share of losses | Points |
|---|---|
| 30 points or more | high, e.g. +30 to +40 |
| 10 to 30 points | medium, e.g. +10 to +20 |
| under 10 points | +0 to +2, or leave it out |
| more common before losses | 0, and note it |

Small counts make the gap noisy. With 40 wins, a gap under 10 points can be chance, so give it
little weight until more deals close.

## 3. Caps and decay

| Setting | Our choice | Why |
|---|---|---|
| Score limit per group (HubSpot default maximum is 100 points) | | so one noisy event cannot fill the score |
| Points per repeat event (e.g. each email click) | | |
| Score decay interval (HubSpot offers 1, 3, 6 or 12 months) | | so last spring's clicks stop counting as interest today |
| Decay amount | | |

Write the interval to match your sales cycle. A 60-day cycle and a 12-month decay keep stale
interest in the score for most of a year.
