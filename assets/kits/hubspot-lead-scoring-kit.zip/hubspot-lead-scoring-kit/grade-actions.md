# Grade actions

Part of the Magnetiz HubSpot Lead Scoring implementation kit.

Fill this in before the score is used for routing. A grade earns its place when it changes what
someone does next.

## Why every grade names an action

A threshold with no action attached outlives the definition it was set for. When the customer
definition changes, an unnamed threshold keeps sorting accounts the old way and nobody notices.

## 1. The grade table

HubSpot's combined score grades run A1 to C3. The letter is fit, the number is engagement.

| Grade | What it means | Action | Owner | Within |
|---|---|---|---|---|
| A1 | right company, active now | rep reaches out | [AE / SDR] | [1 business day] |
| A2 | right company, some interest | rep reaches out | | [3 business days] |
| A3 | right company, quiet | nurture sequence, reviewed monthly | | |
| B1 | partial fit, active | rep reviews the account before any outreach | | |
| B2, B3 | partial fit, low interest | nurture | | |
| C1 | poor fit, very active (often students, job seekers, competitors) | no sales outreach, send the resource they asked for | | |
| C2, C3 | poor fit | no outreach, reason recorded | | |

## 2. The review list

Records missing a required fit property (see `fit-rules.md` section 4) score as if the property
failed. They go to a person instead of a grade.

Build it as an active list or a workflow in HubSpot with these filters.

| Filter | Value |
|---|---|
| Required fit property is unknown | Number of employees, Industry, Job title (any of them) |
| Engagement score | above your A2 engagement line |
| Not already in review | |

| Field | Our value |
|---|---|
| Who works the list | |
| How often | |
| What they do | look up the missing property, fill it in, let the score recalculate |

Watch for an empty review list. If it never has anything in it, check that the filters are
catching records with missing data.

## 3. Signed

| Name | Role | Date |
|---|---|---|
| | Sales owner | |
| | Marketing owner | |
