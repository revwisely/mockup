# Backtest

Part of the Magnetiz HubSpot Lead Scoring implementation kit.

Run this after the score is built and before anything routes on it. It answers one question. Would
this score have ranked your past wins above your past losses?

## Why read the fit grade

Fit properties barely change after a deal closes, so the fit letter on a closed account today is
close to what it would have been then. Engagement does change. A won customer keeps opening emails
and logging in, which inflates the engagement number on every win. Read the fit letter here, and
leave engagement to the evidence in `engagement-evidence.md`.

If you wrote two sets of fit rules (from your closed deals and from the strategy deck), build each
as its own score and run this sheet for both. Keep the one that separates wins from losses.

## 1. Write the rule before you look

| Field | Our answer |
|---|---|
| What we count | share of closed-won deals whose company grades A, against the share of closed-lost deals that grade A |
| Window | closed in the last 12 months |
| The chance that counts | [we use 90%, the chance that wins really grade A more often than losses] |
| Signed by, date | |

## 2. Count

| | Deals | Graded A (A1 to A3) | Share |
|---|---|---|---|
| Closed-won | | | |
| Closed-lost | | | |

## 3. Look the counts up

With 40 wins and 60 losses. Report the chance and the range together. The range is where the real
gap between the two shares probably sits, in percentage points.

| Wins graded A vs losses graded A | Chance wins really grade A more often | Range of the gap |
|---|---|---|
| 32 of 40 vs 18 of 60 | over 99.9% | 33 to 61 points |
| 28 of 40 vs 24 of 60 | 99.8% | 13 to 44 points |
| 26 of 40 vs 30 of 60 | 93%, past the line | -2 to 30 points |
| 24 of 40 vs 33 of 60 | 69%, too close to call | -11 to 21 points |

Small counts give wide ranges. The direction can be clear well before the size of the gap is.

## 4. The decision

| The count shows | Decision |
|---|---|
| The chance that counts or better | **Use it.** Route on the new score, keep the old one for a month as a check |
| Below the chance that counts | **Rewrite the fit rules.** Find the rule that lets losses into A, usually size or industry, and run again |
| Wins and losses land in A at about the same share | **Start over from the closed deals.** The rules describe someone other than your buyers |

## 5. The record

| Date | Wins graded A | Losses graded A | Chance | Decision | Signed by |
|---|---|---|---|---|---|
| | | | | | |
