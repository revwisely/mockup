# Backtest

Part of the Magnetiz HubSpot Lead Scoring implementation kit.

Run this after the score is built and before anything routes on it. It answers one question. Would
this score have ranked wins above losses on deals it was never built from?

## Why the test deals are kept apart

Rules written from a set of deals will sort that same set well, whether or not they describe your
buyers.

So the deals that test the score are set aside before any rule is written, and nothing in
`fit-rules.md` or `engagement-evidence.md` is taken from them.

Sort your closed deals by close date. The oldest two thirds are the **build deals**. The newest
third are the **test deals**. Testing on the newest deals also shows whether the market has moved
since the older ones closed.

## Why read the fit grade, as it was at the close

A won customer keeps opening emails and logging in, which inflates the engagement number on every
win. Read the fit letter here, and leave engagement to `engagement-evidence.md`.

Fit can drift too. A company that had 90 people when the deal closed may have 300 today.

HubSpot keeps each record's property history (past values with dates). For each test deal, read the fit
properties as they stood on the close date, or at least flag the deals whose size, industry or
buyer's title changed since.

If you wrote two sets of fit rules (from your build deals and from the strategy deck), build each as
its own score and run this sheet for both. Keep the one that separates wins from losses.

## 1. Write the rule before you look

| Field | Our answer |
|---|---|
| Build deals | [closed between ____ and ____, the oldest two thirds] |
| Test deals | [closed between ____ and ____, the newest third, never used to write a rule] |
| What we count | share of test-deal wins whose company grades A, against the share of test-deal losses that grade A |
| The pass line | [we use 90%, the probability, worked out from the counts, that won deals land in A at a higher rate than lost deals] |
| Signed by, date | |

## 2. Count (test deals only)

| | Deals | Graded A (A1 to A3) | Share | Fit changed since the close |
|---|---|---|---|---|
| Closed-won | | | | |
| Closed-lost | | | | |

## 3. Look the counts up

With 40 test-deal wins and 60 test-deal losses. Report the probability and the range together. The
range is where the real gap between the two shares probably sits, in percentage points.

| Wins graded A vs losses graded A | Probability wins land in A at a higher rate | Range of the gap |
|---|---|---|
| 32 of 40 vs 18 of 60 | over 99.9% | 33 to 61 points |
| 28 of 40 vs 24 of 60 | 99.8% | 13 to 44 points |
| 26 of 40 vs 30 of 60 | 93%, past the line | -2 to 30 points |
| 24 of 40 vs 33 of 60 | 69%, too close to call | -11 to 21 points |

Small counts give wide ranges. The direction can be clear well before the size of the gap is.

## 4. The decision

| The count shows | Decision |
|---|---|
| The pass line or better | **Use it.** Route on the new score, keep the old one for a month as a check |
| Below the pass line | **Rewrite the fit rules from the build deals.** Find the rule that lets losses into A, usually size or industry. The test deals have now been looked at, so the next read waits for deals that close after the rewrite, or is labelled as a re-read of the same deals |
| Wins and losses land in A at about the same share | **Start over from the build deals.** The rules describe someone other than your buyers |

## 5. The record

| Date | Build deals | Test deals | Wins graded A | Losses graded A | Probability | Decision | Signed by |
|---|---|---|---|---|---|---|---|
| | | | | | | | |
