# Meeting Intelligence — sample transcript and expected output

Part of the Magnetiz Meeting Intelligence implementation kit. Run the extraction prompt
against this transcript first. Compare your model's output to the expected extraction
below before touching a real call. Differences in wording are fine. **Differences in
commitment, scope, route, ownership, or tier, invented items, and unfaithful quotes are
failures worth fixing before day one** — the same modes the graduation log scores.

## Sample transcript (synthetic, speaker-labeled)

> **Dana (them, VP Ops):** Thanks for making time. So, the report automation you set up
> is working, the Monday numbers just show up now, which honestly still feels like magic.
>
> **Alex (us):** Good. Anything off in the numbers?
>
> **Dana:** One thing. The regional split counts the two Canadian accounts under US East.
> Can you fix that before the board meeting on the 24th?
>
> **Alex:** Yes, we'll fix the region mapping this week.
>
> **Dana:** Great. Oh, and Marco keeps asking whether we could someday pipe these into
> the investor portal too. Down the road, maybe. Not urgent at all.
>
> **Alex:** Noted. What about the CRM cleanup we scoped out last month?
>
> **Dana:** Still parked, we said no to that for this quarter and I would keep it there.
> Although... honestly if the region fix goes well, maybe we revisit. We'll see.
>
> **Alex:** Understood. Anything else?
>
> **Dana:** Yes, one real ask. We need the weekly report to also go to our new CFO,
> Priya, starting next week. She wants it in her inbox, not in Slack.
>
> **Alex:** Can do. We will need her email from you.
>
> **Dana:** I'll send it today after this call. And I'll pull the updated org chart for
> the report footer by Wednesday, that one's on me.

## Expected extraction (the answer key)

```json
{
  "meeting_date": "YYYY-MM-DD",
  "counterparty": "Dana (VP Ops)",
  "source_format": "transcript",
  "work_items": [
    {
      "title": "Fix region mapping so Canadian accounts leave US East",
      "type": "fix",
      "owner": "us",
      "estimate": "S",
      "confidence": "high",
      "tier_proposed": "auto",
      "due_signal": "before the board meeting on the 24th",
      "commitment": "committed",
      "scope": "in",
      "route": "committed",
      "source_quote": "Can you fix that before the board meeting on the 24th?"
    },
    {
      "title": "Add CFO Priya to weekly report distribution by email",
      "type": "feature",
      "owner": "us",
      "estimate": "S",
      "confidence": "high",
      "tier_proposed": "review",
      "due_signal": "starting next week",
      "commitment": "committed",
      "scope": "out",
      "route": "scoped_commitment",
      "source_quote": "We need the weekly report to also go to our new CFO, Priya, starting next week."
    },
    {
      "title": "Send updated org chart for the report footer",
      "type": "chore",
      "owner": "them:Dana",
      "estimate": "S",
      "confidence": "high",
      "tier_proposed": "review",
      "due_signal": "by Wednesday",
      "commitment": "committed",
      "scope": "in",
      "route": "committed",
      "source_quote": "I'll pull the updated org chart for the report footer by Wednesday, that one's on me."
    }
  ],
  "deal_facts": [
    { "fact": "New CFO named Priya", "crm_field": "stakeholders", "source_quote": "our new CFO, Priya" },
    { "fact": "Board meeting on the 24th", "crm_field": "timeline signal", "source_quote": "before the board meeting on the 24th" }
  ],
  "parking_lot": [
    {
      "topic": "Pipe reports into the investor portal",
      "who_raised": "them:Marco (via Dana)",
      "energy_read": "explicitly not urgent, second-hand interest",
      "source_quote": "whether we could someday pipe these into the investor portal too. Down the road, maybe."
    }
  ],
  "decisions": [
    { "decision": "CRM cleanup stays out of scope this quarter", "owner": "Dana", "side": "them", "source_quote": "we said no to that for this quarter and I would keep it there" }
  ],
  "blockers": [
    { "blocker": "Need Priya's email address", "owned_by": "them:Dana", "expected_resolution": "I'll send it today after this call", "blocks": ["Add CFO Priya to weekly report distribution"], "source_quote": "We will need her email from you. — I'll send it today after this call." }
  ],
  "changes_to_existing": [
    { "record_ref": "report automation build", "change": "confirmed working; praise on the record", "source_quote": "the report automation you set up is working, the Monday numbers just show up now" }
  ],
  "followups_for_next_meeting": ["Confirm Priya received the first emailed report", "Org chart received from Dana?"]
}
```

## Why the answer key routes the way it does (the judgment, stated)

- **The region fix is committed and in scope.** Owner, yes, and a date. AUTO-eligible
  because it is a scoped, testable internal fix. The date language also produced a
  timeline deal fact, because a board meeting is a stakeholder moment the record should
  hold.
- **The Priya ask shows why commitment and scope are separate axes.** "Can do" is
  committed. The weekly report's recipients are outside the agreed scope, so scope is
  out, and the matrix routes it `scoped_commitment`: it proceeds, and it ALWAYS carries
  a scope note. One field could not have said both things. tier_proposed is review
  because a person outside the team sees the output.
- **The org chart is the owner fork, demonstrated.** Committed, in scope, and owned by
  `them:Dana`, so it is never executed by us. It becomes a waiting-on entry, and
  tomorrow's brief can say "waiting on Dana since Wednesday."
- **The investor portal is `explored`.** Secondhand interest, "someday," "not urgent."
  Parking lot, energy read recorded honestly, and promotion out of the lot is a human
  act.
- **The CRM cleanup mention is a decision, never a work item.** Dana re-affirmed the
  exclusion herself. Her "maybe we revisit" is explored energy inside a standing no, so
  the record keeps the no and the follow-up keeps the door.
- **Every array carries its receipt.** The blocker and the change-to-existing hold
  quotes too, because the change-to-existing array writes to live records, and that is
  the last place a receipt should be optional.
- **Nothing else became work.** The praise updated an existing record. That restraint is
  the product.
