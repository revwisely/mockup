# Meeting Intelligence — sample transcript and expected output

Part of the Magnetiz Meeting Intelligence implementation kit. Run the extraction prompt
against this transcript first. Compare your model's output to the expected extraction
below before touching a real call. Differences in wording are fine. Differences in
routing, ownership, or invented items are failures worth fixing before day one.

## Sample transcript (synthetic, speaker-labeled)

> **Dana (them, VP Ops):** Thanks for making time. So, the report automation you set up
> is working, the Monday numbers just show up now, which honestly still feels like magic.
>
> **Alex (us):** Good. Anything off in the numbers?
>
> **Dana:** One thing. The regional split counts the two Canadian accounts under US East.
> Can you fix that before the board meeting on the 24th?
>
> **Alex:** Yes, we'll fix the region mapping this week.
>
> **Dana:** Great. Oh, and Marco keeps asking whether we could someday pipe these into
> the investor portal too. Down the road, maybe. Not urgent at all.
>
> **Alex:** Noted. What about the CRM cleanup we scoped out last month?
>
> **Dana:** Still parked, we said no to that for this quarter and I would keep it there.
> Although... honestly if the region fix goes well, maybe we revisit. We'll see.
>
> **Alex:** Understood. Anything else?
>
> **Dana:** Yes, one real ask. We need the weekly report to also go to our new CFO,
> Priya, starting next week. She wants it in her inbox, not in Slack.
>
> **Alex:** Can do. We will need her email from you.
>
> **Dana:** I'll send it today after this call.

## Expected extraction (the answer key)

```json
{
  "meeting_date": "YYYY-MM-DD",
  "counterparty": "Dana (VP Ops)",
  "source_format": "transcript",
  "work_items": [
    {
      "title": "Fix region mapping so Canadian accounts leave US East",
      "type": "fix",
      "owner": "us",
      "priority": "p1",
      "estimate": "S",
      "confidence": "high",
      "tier_proposed": "auto",
      "due_signal": "before the board meeting on the 24th",
      "scope_route": "committed",
      "source_quote": "Can you fix that before the board meeting on the 24th?"
    },
    {
      "title": "Add CFO Priya to weekly report distribution by email",
      "type": "feature",
      "owner": "us",
      "priority": "p2",
      "estimate": "S",
      "confidence": "high",
      "tier_proposed": "review",
      "due_signal": "starting next week",
      "scope_route": "new_ask",
      "source_quote": "We need the weekly report to also go to our new CFO, Priya, starting next week."
    }
  ],
  "deal_facts": [
    { "fact": "New CFO named Priya", "crm_field": "stakeholders", "source_quote": "our new CFO, Priya" }
  ],
  "parking_lot": [
    {
      "topic": "Pipe reports into the investor portal",
      "who_raised": "them:Marco (via Dana)",
      "energy_read": "explicitly not urgent, second-hand interest",
      "source_quote": "whether we could someday pipe these into the investor portal too. Down the road, maybe."
    }
  ],
  "decisions": [
    { "decision": "CRM cleanup stays out of scope this quarter", "owner": "Dana", "side": "them", "source_quote": "we said no to that for this quarter and I would keep it there" }
  ],
  "blockers": [
    { "blocker": "Need Priya's email address", "owned_by": "them:Dana", "expected_resolution": "I'll send it today after this call", "blocks": ["Add CFO Priya to weekly report distribution"] }
  ],
  "changes_to_existing": [
    { "record_ref": "report automation build", "change": "confirmed working; praise on the record" }
  ],
  "followups_for_next_meeting": ["Confirm Priya received the first emailed report"]
}
```

## Why the answer key routes the way it does (the judgment, stated)

- **The region fix is committed.** Owner, yes, and a date. AUTO-eligible because it is a
  scoped, testable internal fix.
- **The Priya ask is a new_ask, not committed scope.** It was agreed, so it proceeds, and
  it carries the scope note because it expands the deliverable. It proposes REVIEW
  because a new external recipient sees the output.
- **The investor portal is exploration.** Secondhand interest, "someday," "not urgent."
  No task. Parking lot, with the energy read recorded honestly.
- **The CRM cleanup mention is a decision, not a resurrected non-goal item.** Dana
  re-affirmed the exclusion herself. Her "maybe we revisit" is exploration energy inside
  a standing no, so the record keeps the no and the follow-up keeps the door.
- **Priya's email is a blocker owned by them.** It is never our task, and the brief can
  say "waiting on Dana" tomorrow.
- **Nothing else became work.** The praise updated an existing record. That restraint is
  the product.
