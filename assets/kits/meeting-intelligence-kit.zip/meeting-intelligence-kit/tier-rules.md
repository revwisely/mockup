# Meeting Intelligence — tier rules

Part of the Magnetiz Meeting Intelligence implementation kit. The extraction PROPOSES a
tier. These rules DECIDE it. Rules beat proposals, so a misclassified item can be
under-privileged (annoying) but never over-privileged (dangerous).

## AUTO — may run or write unattended (after graduation)

- Drafting an internal record update from stated facts
- Creating a task with owner, quote, and acceptance criteria
- Posting the channel brief
- Research confined to your own systems with a written output
- Docs and internal notes

## REVIEW — always waits for a person

- Any customer- or prospect-facing content, always
- CRM writes to live deal records (until graduated per below)
- Anything touching pricing, legal terms, or commitments
- Large (estimate L), vague, or untestable items
- confidence: low from the extraction, regardless of size
- Anything that cannot be traced or rolled back

## Deterministic overrides (applied after the lists, in order)

1. `owner != us` → never executed at all. Tracked as waiting-on. Tier is moot.
2. Your own force-review list (name the fields, records, or paths that always require a
   person, e.g. pricing fields, contract records) → REVIEW when plausibly touched.
3. Estimate L → REVIEW. Confidence low → REVIEW.
4. No testable done-condition → REVIEW, marked needs-definition.
5. When any rule and the proposal disagree, the stricter tier wins. No exceptions.

## Graduation (how AUTO is earned)

Nothing writes unattended on day one. A person reviews every extraction and scores four
failure modes per pass. Invented items. Missed asks. Wrong owners. Wrong tiers.

Set your own bar before you start (a common one is five consecutive clean passes), then
graduate only the AUTO-listed actions. Customer-facing content never graduates. Keep the
pass log. The log with dates is what makes "we trust it" a measured claim.
