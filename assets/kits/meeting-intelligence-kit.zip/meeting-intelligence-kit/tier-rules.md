# Meeting Intelligence — tier rules

Part of the Magnetiz Meeting Intelligence implementation kit. The extraction PROPOSES a
tier. These rules DECIDE it. Rules beat proposals, so a misclassified item can be
under-privileged (annoying) but never over-privileged (dangerous).

## The scales the rules run on (defined, so the rules are falsifiable)

**Estimate.** S = under an hour of focused work. M = fits inside one day. L = more than
a day, or cannot honestly be estimated. When torn between two bands, pick the larger.

**Confidence.** high = the words are explicit and unambiguous. medium = the ask is clear
but the acceptance criteria are inferred. low = a reasonable reader would ask "did they
actually agree to that?" Notes-sourced input drops every item one level.

## AUTO — may run or write unattended (after graduation)

- Drafting an internal record update from stated facts
- Creating a task with owner, quote, and acceptance criteria
- Posting the channel brief
- Research confined to your own systems with a written output
- Docs and internal notes

## REVIEW — always waits for a person

- **Anything a person outside your team will see, in their words or yours. Always.**
  This is the permanent gate and this is its one wording, used identically in the
  extraction prompt.
- CRM writes to live deal records (until graduated per below)
- Anything touching pricing, legal terms, or commitments
- Estimate L, or untestable items
- confidence: low, regardless of size
- Anything that cannot be traced or rolled back

## Deterministic overrides (applied after the lists, in order)

1. `owner != us` → never executed at all. Tracked as waiting-on. Tier is moot.
2. Your own force-review list (name the fields, records, or paths that always require a
   person) → REVIEW when plausibly touched.
3. Estimate L → REVIEW. Confidence low → REVIEW.
4. No testable done-condition → REVIEW, marked needs-definition.
5. When any rule and the proposal disagree, the stricter tier wins. No exceptions.

**Deal facts are tiered by the CRM field map, not by these rules.** The overrides above
key on fields only work items carry. `crm-field-mapping.md` assigns each fact class its
write rule, and that worksheet is the authority for fact writes.

## Graduation (how AUTO is earned)

Nothing writes unattended on day one. A person reviews every extraction and scores
**five failure modes** per pass:

1. Invented items
2. Missed asks
3. Wrong owners
4. Wrong routes (commitment or scope misjudged)
5. **Unfaithful quotes** — a `source_quote` that is fabricated, paraphrased, or trimmed
   into a different meaning. The item can be otherwise perfect and this still fails the
   pass, because the receipts are the product.

Wrong tiers cannot escalate (the overrides catch them) but get logged too. Set your bar
before you start (five consecutive clean passes is a common one), then graduate only the
AUTO-listed actions. Content leaving your team never graduates. Keep the pass log; the
log with dates is what makes "we trust it" a measured claim. Graduation means the same
thing in every Magnetiz playbook: a pre-committed streak of consecutive clean, dated
checks against named failure modes, with the threshold set before you start.
