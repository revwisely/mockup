# Meeting Intelligence — CRM field-mapping worksheet

Part of the Magnetiz Meeting Intelligence implementation kit. Fill this once per team.
The extraction's `deal_facts` and `work_items` land in real fields only after this map
exists. An unmapped fact goes to the review queue instead of guessing.

## 1. Systems

| Question | Your answer |
|---|---|
| System of record for deals/accounts | |
| System of record for tasks | |
| Channel for the brief (Slack / Teams / other) | |
| Who reviews the queue, by name | |

## 2. Deal-fact map

For each fact class the extraction produces, name the destination field. Delete rows you
do not track; add rows your team needs.

| Fact class | Example from a call | Destination field | Write rule |
|---|---|---|---|
| Budget signal | "we're budget constrained through the rest of the year" | | draft for review |
| Timeline signal | "we want this before Q1" | | draft for review |
| Named stakeholder | "our CFO needs to see this" | | draft for review |
| Competitor mention | "we're also talking to X" | | draft for review |
| Current stack | "we run HubSpot and Slack" | | may auto-write after graduation |
| Problem confirmed, their words | "that is exactly our issue" | | draft for review |
| Objection, their words | | | draft for review |
| Next step agreed | "let's meet Thursday" | | draft for review |

## 3. Work-item map

| Extraction field | Your task-tool field |
|---|---|
| title | |
| owner (us / them) | |
| priority (p1-p3) | |
| estimate (S/M/L) | |
| tier (auto/review) | |
| source_quote | (a comment or custom field; keep it visible) |

## 4. The two rules that keep the map honest

1. **Verbatim beats summary in any field that holds their words.** A quote field carrying
   a paraphrase silently loses the thing that made it useful.
2. **`them`-owned items are waiting-on entries, never your tasks.** Map them to whatever
   your tool uses for dependencies, and date them, so the brief can say "waiting on X
   since the 14th."
