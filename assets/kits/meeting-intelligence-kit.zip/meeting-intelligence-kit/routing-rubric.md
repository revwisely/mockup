# Meeting Intelligence — routing rubric

Part of the Magnetiz Meeting Intelligence implementation kit. The routing layer decides
what meeting talk becomes. The linguistic tells matter more than the topic.

## The four routes

| Route | The tell | What happens |
|---|---|---|
| **committed** | Decision language with an owner. "Let's do X." "Can you have X by Friday?" "Yes, ship it." | Becomes a work item this cycle |
| **new_ask** | A real request outside the agreed scope. "We also need X." | Logged and sized, presented as a proposal with a scope note. Never silently added |
| **exploration** | Musing language, no owner, no date. "It would be cool if." "Down the road." "Have you ever thought about." | Parking lot. No task is created |
| **resurrected_non_goal** | Matches something explicitly scoped out before | Flagged with the original exclusion date so a person re-decides |

## The two governing rules

1. **The tell is an owner and a yes. Enthusiasm alone routes down.** A topic can move
   from exploration to committed inside one meeting. The move requires someone saying
   yes to something specific, never energy in the room.
2. **When unsure, route DOWN and let a person promote it.** A missed task costs a week.
   A phantom commitment costs trust.

## The parking lot is expansion signal

Parking lot entries are not waste. Reviewed monthly, they become the expansion
conversation ("you mentioned X twice, want us to scope it?"). Keep who raised each topic
and an honest one-line energy read, because that is what makes the monthly review fast.
