# Meeting Intelligence — routing rubric

Part of the Magnetiz Meeting Intelligence implementation kit. The tells are inlined in
the extraction prompt so it runs standalone; this file is the full rationale and the
reference the humans calibrate against.

## Two axes, judged separately

The old single "route" field collapsed two facts into one and split implementers on
items that were both agreed AND out of scope. The axes are independent:

- **commitment** = was it agreed? `committed` (decision language with an owner) /
  `explored` (musing, no owner, no date) / `declined` (a stated no).
- **scope** = does the agreed scope cover it? `in` / `out` / `reversal` (matches a
  declared non-goal).

## The routing matrix (route is derived, never judged directly)

| commitment | scope | route | what happens |
|---|---|---|---|
| committed | in | **committed** | work item this cycle |
| committed | out | **scoped_commitment** | proceeds, ALWAYS with a scope note attached. Agreed in the room does not mean silently absorbed into scope; the note is how scope stays governed |
| explored | any | **parking_lot** | no task. Who raised it and the energy read get kept |
| any | reversal | **non_goal_flag** | flagged with the original exclusion date; a person re-decides |
| declined | any | — | recorded in `decisions` only |

## The two governing rules

1. **The tell is an owner and a yes. Enthusiasm alone is `explored`.** A topic can move
   from explored to committed inside one meeting; the move requires someone saying yes
   to something specific.
2. **When unsure, choose `explored` and let a person promote it.** A missed task costs a
   week. A phantom commitment costs trust.

## The parking lot is expansion signal

Parking lot entries are not waste. Reviewed monthly, they become the expansion
conversation ("you mentioned X twice, want us to scope it?"). **Promotion out of the
parking lot is a human act, always.** No rule and no model moves an explored item into
the work queue.
