# Message and send check

Part of the Magnetiz Champion Job Change implementation kit.

The message is written from the person, and checked again right before it sends.

## Writing the message

The first message is about them, their new role, and the work you did together. It does not pitch.

| Part | Your version |
|---|---|
| Opening line | [about their new role, in your own words, e.g. something they have posted since they started] |
| The history, in one line | [what you did together, stated plainly, e.g. "we worked together on the rollout at Larkspur"] |
| The ask | [one small ask, e.g. whether they want to compare notes once they have settled in] |

Three things to leave out.

- The alert. "I saw you changed jobs" tells them a tool noticed, not you.
- Anything about the old company's results that the old company has not made public.
- A link in the first message.

## The send check

Run this on every message in the batch, right before it sends. The facts the tier was decided on can
change between the check and the send.

| Person | Still at the new company? | Title still matches? | Rendered message read in full? | Name and company in the message match their profile today? | Send / hold |
|---|---|---|---|---|---|
| | | | | | |
| | | | | | |
| | | | | | |

**Read the rendered message**, the one the tool will actually send, with every field filled in.
When we read every message before one load, 8 of 129 contacts weren't employees of the company the
message was written for.

## Record the result

| Person | Tier | Sent on | Replied? | Meeting booked? | Notes |
|---|---|---|---|---|---|
| | | | | | |
| | | | | | |
