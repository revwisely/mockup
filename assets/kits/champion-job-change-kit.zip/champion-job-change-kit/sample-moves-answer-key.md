# Sample moves, with the answer key

Part of the Magnetiz Champion Job Change implementation kit.

Ten made-up alerts for a made-up company that sells to revenue operations teams. Every name and
company here is invented. Run them through `move-check.md` and `tier-rules.md` before reading the
answer key. One of them is a trap.

The sample's settings are a target band of 100 to 300 employees, buyers in revenue operations or
revenue leadership, and a 90-day window.

## The alerts

| # | Person | Champion level | Old company | Alert says | What you find |
|---|---|---|---|---|---|
| 1 | Priya Natarajan | A, signed | Larkspur Freight (customer) | VP RevOps at Corvane Logistics, 180 people | Corvane's leadership page lists her. Started 34 days ago |
| 2 | Marcus Bell | B, ran the rollout | Larkspur Freight (customer) | Ops Manager at Tallow & Finch, 60 people | Tallow & Finch's announcement post names him. Started 20 days ago |
| 3 | Dana Okafor | B | Pinecrest Software (customer) | VP Revenue Operations at Pinecrest Software | Same company, she was Director last month |
| 4 | Luis Ferreira | A | Hartwell Supply (churned) | Head of Sales Ops at Quarry Point, 150 people | A Quarry Point press release from fourteen months ago names him |
| 5 | Hannah Cho | C | Pinecrest Software (customer) | Advisor at Fieldnote, 12 people | Her profile still lists Pinecrest as her full-time role |
| 6 | Owen Pruitt | A | Brightwell Analytics (customer) | Head of Sales Ops at Meridian Data Group, 260 people | See the answer key |
| 7 | Sofia Reyes | B | Hartwell Supply (churned) | RevOps Lead at Osprey Cloud, 140 people | Only her own profile. No team page, no announcement, no post |
| 8 | Tom Albright | D, sat in one demo | Larkspur Freight (customer) | Sales Director at Kestrel Labs, 210 people | Kestrel's site lists him. Started 41 days ago |
| 9 | Grace Liu | A, signed | Northgate Health (lost deal, she pushed for us) | CRO at Hollis Health, 240 people | Hollis's press release names her. Started 70 days ago |
| 10 | Rachel Kim | B | Brightwell Analytics (customer) | RevOps Director at Pinecrest Software | Pinecrest's team page lists her. Started 15 days ago |

## The answer key

| # | Verdict | Tier | Old account task | Why |
|---|---|---|---|---|
| 1 | Verified move | 1 | Yes, Larkspur lost its signer | Second source, inside the window, in band, buying role |
| 2 | Verified move | Cold | Yes, Larkspur lost its admin | Real move, but 60 people is under the band, so Tallow & Finch does not qualify for outreach either |
| 3 | Not a move (promotion) | None | No | Same company. A promotion is worth a note from the account owner, not a job change play |
| 4 | Not a move (stale profile) | None | No, Hartwell churned | The profile was updated late. The move is fourteen months old, far outside the window |
| 5 | Not a move (side role) | None | No | An advisor seat while still full-time at Pinecrest |
| 6 | **Not a move (renamed company). The trap** | None | Yes, update the account record | Meridian acquired Brightwell in August and folded it into its own name. Same role, same team, same budget. The alert reads it as a new job at a new company in your band, which makes it look like the best move on the list. Routing it would congratulate your current champion on a job they did not change |
| 7 | Cannot tell | Held | No, Hartwell churned | One source only. A named owner checks again next cycle |
| 8 | Verified move | Cold | No | A real move, but a demo attendee is not a champion |
| 9 | Verified move | 1 | No, a lost deal | Second source, inside the window, in band, buying role. Note why the deal was lost, because it changes the message |
| 10 | Verified move | Owner | Yes, Brightwell lost its admin | Pinecrest is already a customer, so it goes to that account's owner, not to outreach |

## What a correct run looks like

Two Tier 1 moves (1 and 9), one held (7), four not a move (3, 4, 5, 6), and three old account tasks
(1, 2 and 10, plus the record update on 6). If your run sent a message to Owen Pruitt, the move
check took the alert's word for it. Go back to question 1 in `move-check.md`.
