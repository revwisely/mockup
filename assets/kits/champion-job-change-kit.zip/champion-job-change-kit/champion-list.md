# Champion list

Part of the Magnetiz Champion Job Change implementation kit.

Fill this in before you watch anyone. The list decides who a move is worth acting on, so it comes
first, from your own records, while nobody is looking at an alert.

## Why a list with evidence

Most job change tools watch every contact on a closed-won account. A contact is not a champion. The
person who sat in one demo and the person who signed the contract both show up as "past customer
contact", and only one of them will take your call at the new company.

A champion is someone your records show did something for the deal or the rollout.

## The evidence ladder

Rate each person on the strongest thing your records show. Write the source next to it, so anyone
can check the rating.

| Level | What the record shows | Example source |
|---|---|---|
| A | Signed, or approved the budget | the contract, the order form, the approval email |
| B | Ran the rollout or owned the tool day to day | onboarding notes, admin seat, support tickets they opened |
| C | Argued for you inside the deal | call notes, a forwarded internal email, the deal's champion field with a note behind it |
| D | Attended, was copied, or is only on the account | meeting invites, CRM contact roles with nothing behind them |

**Levels A to C go on the watch list. Level D stays off.** If a D-level person moves, they are a
cold contact at the new company, and they go to your usual outreach.

## Where to look

- Closed-won accounts, current and churned. A churned customer's champion can still be a good
  champion. Note why the account churned, because it changes the message.
- Late-stage lost deals where one person pushed for you. Mark these as C, and note the loss reason.

## The list

| Person | Old company | Their role then | Level (A to D) | Evidence and where it lives | Account status (customer, churned, lost deal) | Notes |
|---|---|---|---|---|---|---|
| | | | | | | |
| | | | | | | |
| | | | | | | |
| | | | | | | |
| | | | | | | |

## Before you move on

- Every A to C row names its evidence and where it lives.
- Nobody is on the list because of a title alone.
- The owner of the number has read the list and agrees with the D cut.
