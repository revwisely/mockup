# Move check

Part of the Magnetiz Champion Job Change implementation kit.

Run this on every alert before it goes anywhere. A job change alert is a claim that a profile
changed. This check decides whether a person actually moved.

## Why check every alert

Profiles change for reasons that are not a new job. A promotion at the same company, an advisor
seat on the side, a company renamed after an acquisition, or a profile updated a year after the
move. Each one fires the same alert. A message that congratulates someone on a job they started
fourteen months ago, or at a company that is their old one under a new name, tells them you read
an alert and not their profile.

## The four questions

Answer each one with a source. Their own profile counts as one source. A move needs a second one,
such as the new company's team page, a press release, an announcement post, or a filing.

| # | Question | Answer |
|---|---|---|
| 1 | Did they leave the old company and join a different one? | yes / no / cannot tell |
| 2 | Is it confirmed at a second source? | the source, or "none found" |
| 3 | When did they start? | the date, and whether it is inside your window |
| 4 | Is the new role one that touches what you sell? | yes / no / cannot tell |

## The three answers

- **Verified move.** Yes to 1, a second source for 2, inside the window for 3. It goes to the tier
  rules in `tier-rules.md`.
- **Not a move.** No to 1. Drop it and count it. Write which kind it was (promotion, side role,
  renamed company, stale profile), because the readout uses these counts to judge the alert source.
- **Cannot tell.** Anything you cannot confirm. Hold it with a named owner and check it again next
  cycle. A held move never gets a tier and never gets a message.

## Where an AI agent helps

Research is the slow part, so an agent can do it, with a person reading every answer before
anything routes. Use this prompt per alert.

```
You are checking one job change alert. Do not write any outreach.

Person: [name]
Old company: [company]
Alert says new company: [company]
Alert says new role: [title]

Find out whether this person really left the old company for a different one.
Use only public sources. List every source you used with its link and date.

Answer these four questions, one line each:
1. Left the old company for a different one? (yes / no / cannot tell)
2. Second source confirming the new role, other than their own profile? (link, or "none found")
3. Start date, and how you know it
4. Does the new role own or influence [what you sell]? (yes / no / cannot tell)

Then give one verdict: VERIFIED MOVE, NOT A MOVE, or CANNOT TELL.
If the new company acquired, merged with, or renamed the old one, say so. That is NOT A MOVE.
If you could not find a second source, the verdict is CANNOT TELL. Do not guess.
```

The agent's verdict is a proposal. A person approves it, and a CANNOT TELL is never upgraded by
re-asking until the agent says yes.

## The log

| Alert date | Person | Old company | New company (per alert) | Q1 | Q2 source | Q3 start date | Q4 | Verdict | Kind, if not a move | Checked by |
|---|---|---|---|---|---|---|---|---|---|---|
| | | | | | | | | | | |
| | | | | | | | | | | |
| | | | | | | | | | | |

## The tally for the cycle

| Field | Count |
|---|---|
| Alerts received | |
| Verified moves | |
| Not a move | |
| Cannot tell, held | |
| Held from last cycle, now resolved | |
