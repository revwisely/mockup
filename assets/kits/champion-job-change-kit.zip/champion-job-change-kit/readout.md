# Readout

Part of the Magnetiz Champion Job Change implementation kit.

Sign the rule in section 1 before the first message sends. Read it once a quarter.

## Why quarterly

Champion moves come in small numbers. A few verified moves a month is normal for a list of a few
hundred champions, so a monthly read is mostly noise. Count every one and read the quarter.

## 1. The rule, signed before the first send

The comparison is your usual cold outreach to accounts in the same band, over the same weeks.

| Field | Your answer |
|---|---|
| What we count | Meetings booked per verified move contacted, Tier 1 and 2 together |
| Compared with | Meetings booked per cold account contacted, same band, same weeks |
| The chance that counts | [we use 90%, the chance that champion moves really book more than cold] |
| Read date | [end of the quarter] |

## 2. Look the counts up

Meetings from 20 verified moves against 4 meetings from 100 cold accounts. Report the chance and
the range together. The range is where the real gap probably sits.

| Meetings, champion moves vs cold | Chance champion moves really book more | Range of the gap |
|---|---|---|
| 5 of 20 vs 4 of 100 | 99.8% | 2.2 to 15 times |
| 3 of 20 vs 4 of 100 | 97% | 1.2 to 11 times |
| 2 of 20 vs 4 of 100 | 90%, on the line | 0.7 to 8.6 times |
| 1 of 20 vs 4 of 100 | 73%, too close to call | 0.3 to 6.2 times |

The ranges are wide because 20 is a small number. That is fine. The direction can be clear long
before the size is.

## 3. The decision

| On the read date the log shows | Decision |
|---|---|
| The chance that counts or better | **Keep.** Keep the move check on every alert |
| Many alerts, few verified (more than one in three not a move or cannot tell) | **Fix the source.** The alert tool or the list is the problem, not the play |
| Verified moves contacted, and they book no better than cold | **Tighten.** Move the champion line up the ladder, e.g. A and B only |
| No better than cold for two quarters in a row | **Retire.** Put the time into a signal that earns it |
| Read date not reached | Keep recording, decide nothing yet |

## 4. The record

| Quarter | Alerts | Verified | Not a move | Cannot tell | Contacted | Meetings | Cold contacted | Cold meetings | Chance | Decision | Signed by |
|---|---|---|---|---|---|---|---|---|---|---|---|
| | | | | | | | | | | | |
| | | | | | | | | | | | |
