# Tier rules

Part of the Magnetiz Champion Job Change implementation kit.

Write these rules before the first verified move arrives, and keep them in a sheet or in code. A
person or a rule picks the tier. An AI model may draft the message later, and it never picks who
gets one.

## Why the rules come first

If the tier is decided when the move is in front of you, every move from someone you liked becomes
Tier 1. Rules written in advance let the readout tell you whether they were right.

## The tiers

| Tier | All of these are true | What happens |
|---|---|---|
| 1 | Verified move, champion level A or B, new company inside your target band, role touches what you sell | A person writes to them within a week, see `message-and-send-check.md` |
| 2 | Verified move, champion level C, or the role is next to what you sell | A shorter personal message, same send check |
| Owner | The new company is already your customer | It goes to that account's owner, not to outreach |
| Cold | Verified move, but level D, or the new company is outside your band | Your usual outreach, if the account qualifies on its own |
| Held | Cannot tell, from `move-check.md` | No tier until it is resolved |

Write your band here so nobody has to guess it.

| Field | Your answer |
|---|---|
| Target band (size, industry, region) | |
| Roles that buy or run what you sell | |
| Window (days from the start date that a move still counts) | [we start at 90, and the readout tests it] |

## The other half of every move

A champion who left took your best relationship at the old account with them. Every verified move
from a current customer also creates a task for that account's owner.

| Old account status | Task |
|---|---|
| Current customer | Find who now owns the tool or the budget, and meet them before renewal |
| Churned or lost deal | Nothing to send. Note the move on the record |

This task is not a message from outreach. It goes to the person who owns the account.

## Sign-off

| | Name | Date |
|---|---|---|
| Owner of the number | | |
| Person who runs the tiers | | |
