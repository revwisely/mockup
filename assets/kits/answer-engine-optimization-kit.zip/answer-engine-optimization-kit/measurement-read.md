# Measurement read

Part of the Magnetiz Answer Engine Optimization implementation kit.

Set this up before the first page ships, so there is a baseline to read against. It answers one
question. Are we named more often than we were?

## Why one answer tells you nothing

Ask an engine the same question twice and the companies it names change. SparkToro and Gumshoe ran
12 prompts 2,961 times. The same list came back under 1% of the time, and the same order under 0.1%.

So a screenshot of one answer is an anecdote, and a "rank" in an AI answer does not exist. What holds
steady is the share of runs in which you appear.

## Freeze the prompts

Take the questions from `question-list.md`, word for word as people ask them. Group them into two
or three families, such as buyer questions and learner questions.

Once the baseline runs, never edit a prompt. A changed prompt cannot be compared with its old runs.
Adding a new prompt later is fine.

| Family | What it holds | Prompts |
|---|---|---|
| F1 | | |
| F2 | | |
| F3 | | |

## Write the rule before the baseline

Decide what "it worked" means before you see a single number. Fill in the blanks.

- **Works.** On at least ___ engines, in at least one family, we are named in at least ___% of
  runs, and the rate is clearly above the baseline.
- **Too close to call.** Run one more cycle with the same levers, then read again.
- **Not yet.** Drop the weakest lever, keep measuring, and read again in ___ weeks.

A starting point to test is two engines and 20% of runs.

Write down what else could move the number, such as an engine changing its model or a competitor's
launch. You cannot control those. Logging them stops you crediting yourself for their effect.

## Run it

| Setting | Starting point | Yours |
|---|---|---|
| Engines | ChatGPT, Perplexity, Gemini and one more | |
| Runs per prompt, per engine | 10 | |
| Session | Fresh, logged out, no history | |
| Web search | On for every run. Throw out answers given without it | |
| How often | Baseline, then every two weeks | |

Ten runs on one prompt is still thin. Read the family, where the runs add up to a hundred or more.

A logged-in account carries memory of your past chats, so never use your own account as the
measurement. An API or a tracking tool gives clean runs.

## What to record on every answer

| Field | Why |
|---|---|
| Named | The answer's text names your company. This is the win |
| Cited | The answer lists your domain as a source. Useful, and never counted as a win on its own |
| Who was named instead | These are the companies the engine trusts for this question |
| Domains cited | These are the pages to learn from, and the lists to get onto |
| Model and date | Engines change models without notice, and a read describes the week it was taken |

## The read

| Family | Engine | Runs counted | Named | Named rate | Cited | Prompts named, of prompts covered |
|---|---|---|---|---|---|---|
| F1 | | | | | | |
| F1 | | | | | | |
| F2 | | | | | | |

Show the named rate with a range, never as a single exact figure. Zero named in 140 runs still
leaves a true rate anywhere from 0% to about 2%.

Watch the last column. A rate that rests on one prompt out of ten is one lucky question.

## What a zero baseline means

It is the normal start for a small firm. Our own baseline was zero. It tells you every engine is
answering your buyers' questions with other companies, and the "who was named instead" column tells
you which ones.

## What this sheet cannot tell you

Being named is a step before a visit, and a visit is a step before a call. Track the calls in your
CRM. This sheet reads the first step only.
