# Sample question ledger

Part of the Magnetiz Answer Engine Optimization implementation kit.

A worked example from question list to next asset. The company, the volumes and the cited sites are
made up to show the shape.

*Northwind Payroll sells payroll setup and cleanup services to restaurants with 5 to 40 locations.*

## Step 1. The question list

Twelve seed phrases returned 310 questions. Grouped and tagged, the top of the list looked like
this.

| # | Question group | Phrasings | Monthly volume | Tag |
|---|---|---|---|---|
| Q1 | restaurant payroll software | 14 | 3,900 | Tool shopper |
| Q2 | how to do payroll for a restaurant | 6 | 880 | Buyer |
| Q3 | tip pooling payroll rules | 9 | 720 | Learner |
| Q4 | payroll for multi location restaurants | 4 | 210 | Buyer |
| Q5 | restaurant payroll service | 5 | 170 | Buyer |
| Q6 | how to fix payroll errors after switching providers | 3 | 90 | Buyer |
| Q7 | restaurant payroll manager salary | 2 | 140 | Job seeker |

Q1 has the most volume and is tagged tool shopper, so it is skipped. Q7 is a job seeker question.

## Step 2. The citation read

| # | Companies named | Domains cited | Answer shape | Verdict |
|---|---|---|---|---|
| Q2 | Two large payroll vendors in every run | The vendors' own guides | How-to | Owned |
| Q3 | None | A government page, two accountant blogs, a forum thread | Definition | Open |
| Q4 | Names change between runs | One vendor blog, two small consultancies, a video | How-to | Contested |
| Q5 | Three small firms, different each run | A directory, two firm pages | Vendor list | Open |
| Q6 | None | A forum thread, one accountant blog | How-to | Open |

Q2 is owned. The narrow question underneath it is Q4, which adds "multi location" and is contested.

## Step 3. The coverage check

Northwind searched its own site for each phrase.

| # | Volume | Verdict | Guide | Service page | Method | Next asset |
|---|---|---|---|---|---|---|
| Q3 | 720 | Open | Adjacent (one FAQ entry in an old post) | None | None | Split the FAQ entry into its own guide |
| Q4 | 210 | Contested | None | Adjacent (one line on the services page) | None | Guide first, then a service page section |
| Q5 | 170 | Open | None | Exact | None | Refresh the service page, then get onto the directory |
| Q6 | 90 | Open | None | None | None | A checklist readers can download |

Q5 looked like new work on the list. The site already had an exact service page, so the next step
was the directory the engines cite.

## Step 4. The levers picked

| Lever | Why | First action |
|---|---|---|
| L1, narrow questions | Q3, Q4 and Q6 are open or contested and nobody large answers them | Write the Q3 guide |
| L2, plain service page | Q5's answers are vendor lists that cite firm pages | Rewrite the service page to state who it serves, what it delivers and how long it takes |
| L3, third-party lists | One directory appears in every Q5 run | Complete the directory profile |

## Step 5. The baseline

Twelve prompts in two families, 10 runs each on three engines.

| Family | Engine | Runs counted | Named | Named rate | Prompts named, of prompts covered |
|---|---|---|---|---|---|
| Buyer (Q4, Q5, Q6) | ChatGPT | 70 | 0 | 0% (range 0% to 4%) | 0 of 7 |
| Buyer | Perplexity | 70 | 2 | 3% (range 1% to 9%) | 1 of 7 |
| Learner (Q3) | ChatGPT | 50 | 0 | 0% (range 0% to 6%) | 0 of 5 |

The two Perplexity hits both came from one Q5 prompt, which cited the existing service page. That is
one lucky question, and it shows the service page is already being read.

## Step 6. The rule, written before the baseline

Works when Northwind is named in at least 20% of runs in the buyer family on at least two engines.
Read every two weeks. First decision at week eight.

## What to notice

- The highest-volume question was the wrong one to chase.
- The coverage check turned one "new page" into a refresh.
- A zero baseline still produced a list of who the engines trust, and one page that is already
  being cited.
