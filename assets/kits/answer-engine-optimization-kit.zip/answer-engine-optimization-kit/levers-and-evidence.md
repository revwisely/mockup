# Levers and evidence

Part of the Magnetiz Answer Engine Optimization implementation kit.

Read this before spending a dollar or an hour. It lists what the published research supports, what
it does not, and how strong each finding is.

## How to read the grades

| Grade | Meaning |
|---|---|
| A | A controlled experiment, or a real intervention with a published method |
| B | A large dataset with a stated method, showing a correlation |
| C | A vendor claim, an anecdote, or a method nobody published |

Almost every large study here was run by a company that sells a tracking tool, on brands much larger
than a small firm. None tested a small B2B services firm. Treat the levers as the best available
bets and measure your own result.

## Levers that reach a small firm

| # | Lever | What the research found | Grade |
|---|---|---|---|
| L1 | Pick narrow questions where few sources exist | Ahrefs published pages for a brand-new name in 2026. It reached 66.4% of answers to a narrow question and 15.8% to a broader one. Semrush found only 15.2% of 1,094 ChatGPT categories had a clear owner | A minus, B |
| L2 | One plain service page per offer that answers the buyer's factual questions | For agency questions, the agency's own service pages were the most cited first-party page type at 30.4% (Ahrefs, 750 prompts). For factual questions about a company, 63.4% of ChatGPT citations went to official sites (Ahrefs, 66.6M responses) | B |
| L3 | Get onto the third-party lists and directories the engines already cite for your question | Lists of "best X" were 43.8% of cited page types, and 35% of cited lists sat on low-authority domains (Ahrefs) | B |
| L4 | Practical long-form articles on LinkedIn under a person's name | Long-form articles were 50 to 66% of cited LinkedIn content. Authors with under 500 followers were cited about as often as larger ones (Semrush with LinkedIn data, 89,000 URLs) | B minus |
| L5 | Mentions on many independent sites and videos, breadth over prestige | Mentions in YouTube videos (about 0.74) and on other sites (0.66 to 0.71) were the strongest correlates of AI visibility across 75,000 brands. Domain rating was 0.27 to 0.33 (Ahrefs) | B, big-brand sample |
| L6 | Specific numbers, named sources and dates on the page | In a 2023 lab test, adding statistics and quotations raised a source's share of the answer, most for lower-ranked sources (Aggarwal et al., KDD 2024). Cited pages averaged about 26% newer than organic results (Ahrefs, 17M URLs) | A in the lab, C for today's engines |
| L7 | Measure share of appearances across many runs | The same prompt returned the same list of brands under 1% of the time across 2,961 runs (SparkToro and Gumshoe) | B minus |

## What the research does not support

| Tactic | What was found | Grade |
|---|---|---|
| llms.txt as a visibility lever | No correlation with citations across about 300,000 domains (SE Ranking). Google's own guide says Search ignores the file | B |
| Schema added to win AI citations | 1,885 pages that added JSON-LD, each matched to three controls. No lift (Ahrefs, 2026) | A |
| Rewriting pages "for AI" | A 2025 NeurIPS benchmark found most rewrite methods do little, and that where a page ranks in retrieval matters far more (Puerto et al., C-SEO Bench) | A |
| Tracking your "rank" in an AI answer | Order repeated under 0.1% of the time (SparkToro and Gumshoe) | B minus |
| Publishing a list of "best X" that ranks yourself first | In 43% of answers that cited a planted page, the engine recommended a competitor from that page. About a quarter of pages were cited once and never again (Ahrefs) | A minus |
| Press releases for AI | Rose briefly to about 6% of citations, then fell back toward 1.2% (Muck Rack) | C plus |
| Seeding forum threads | Reddit's share of ChatGPT answers fell from about 1 in 5 to about 1 in 43 between March and September 2026 (Ahrefs). It also breaks the forum's rules | B |
| Bulk link building | Backlinks were among the weakest correlates in every large dataset (Ahrefs) | B |

## Two findings that change the plan

**Being cited and being recommended are different.** Semrush found that only 21% of the most-cited
domains were also the most-mentioned brand. Read both in `measurement-read.md`, and count a win only
when the answer names you.

**The source mix moves.** ChatGPT's sources shifted in September 2025, July 2026 and again in
August and September 2026. A tactic that depends on one engine's current habits has a short life.
The levers above are the ones that held across engines.

## Your picks

Choose at most three levers for the first eight weeks. More than that and you cannot tell which one
moved the read.

| Lever | Why this one for us | Owner | First action | By when |
|---|---|---|---|---|
| | | | | |
| | | | | |
| | | | | |

## Sources

Read by Magnetiz on 2026-10-21. Check each for an update before quoting a number.

- Aggarwal et al., GEO. Generative Engine Optimization, KDD 2024. arxiv.org/abs/2311.09735
- Puerto et al., C-SEO Bench, NeurIPS 2025. arxiv.org/abs/2506.11097
- Ahrefs, AI brand visibility correlations, 75,000 brands. ahrefs.com/blog/ai-brand-visibility-correlations
- Ahrefs, self-promotional content experiment. ahrefs.com/blog/self-promotional-content-ai-seo-experiment
- Ahrefs, "best X" lists research. ahrefs.com/blog/best-lists-research
- Ahrefs, ChatGPT query fan-out. ahrefs.com/blog/query-fan-out-chatgpt (read through a summary, original not opened)
- Ahrefs, do AI assistants prefer fresh content. ahrefs.com/blog/do-ai-assistants-prefer-to-cite-fresh-content
- Ahrefs, schema and AI citations test. ahrefs.com/de/blog/schema-ai-citations
- Semrush with Kevin Indig, ChatGPT topic authority study. semrush.com/blog/chatgpt-topic-authority-study
- Semrush, LinkedIn as a cited source, reported by ppc.land
- SE Ranking, llms.txt study. seranking.com/blog/llms-txt
- Google, AI optimization guide. developers.google.com/search/docs/fundamentals/ai-optimization-guide
- SparkToro and Gumshoe, reported by Search Engine Journal
- Muck Rack, What Is AI Reading
