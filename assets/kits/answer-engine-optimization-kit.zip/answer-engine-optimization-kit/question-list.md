# Question list

Part of the Magnetiz Answer Engine Optimization implementation kit.

Fill this in first. Every other sheet in the kit reads this list.

## Why the list comes before any page

An answer engine names a company in reply to a question. So the unit of work is the question, and a
page is only useful if it answers one that buyers ask.

It is common to start from the topics a company wants to be known for. This sheet starts from what
people type.

## Where the questions come from

Use at least three of these sources. One source alone gives you its own blind spot.

| Source | What it gives you | What it misses |
|---|---|---|
| AI question data (DataForSEO LLM Mentions, Ahrefs Brand Radar, Semrush AI Visibility Toolkit, Profound) | Real questions with a monthly volume and the pages cited for each | Only questions that contain your seed phrase. Empty results do not mean nobody asks |
| Sales calls and emails | The buyer's own wording, and the question behind the question | Volume. Ten calls is ten voices |
| Community threads (the subreddits and Slack groups your buyers use) | First-person problems in plain words | Skews to practitioners, light on executives |
| Search Console queries for your own site | Questions you already get traffic for | Anything you have never ranked for |
| Your support and onboarding inbox | The questions asked right after buying | Pre-purchase questions |

## How to pull from AI question data

1. Write 10 to 15 seed phrases of two or three words. Short seeds match more questions.
2. Pull every question that contains each seed, with its monthly volume and its cited pages.
3. Keep the raw file. You will re-read the cited pages in `citation-read.md`.
4. Note which seeds returned nothing, and try a shorter phrase before dropping the idea.

## Group, then tag

Many rows are one question in different words. "ai marketing agent" and "ai marketing agents" get
one answer. Group them, add the volumes, and keep every phrasing in the notes.

Then tag each group.

| Tag | Meaning | What to do |
|---|---|---|
| Buyer | Someone choosing or fixing the thing you sell | Keep. These turn into calls |
| Learner | Someone working out what a term means | Keep the ones that sit just before a buyer question |
| Job seeker | Someone asking how to become the role | Leave for a personal channel |
| Tool shopper | Someone asking for a list of software | Skip unless you sell software |
| Other meaning | The phrase means something else to most askers | Skip. Check by reading the cited pages |

## The list

| # | Question group | Phrasings | Monthly volume | Source | Tag | Notes |
|---|---|---|---|---|---|---|
| Q1 | | | | | | |
| Q2 | | | | | | |
| Q3 | | | | | | |

## What this sheet cannot tell you

Volumes from AI question data describe one engine's logged questions, usually Google's AI answers in
one country. Treat every number as a floor. It ranks the questions against each other. It does not
count the market.
