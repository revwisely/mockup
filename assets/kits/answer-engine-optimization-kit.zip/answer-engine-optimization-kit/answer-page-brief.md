# Answer page brief

Part of the Magnetiz Answer Engine Optimization implementation kit.

Fill in one brief per question before the page is written. It keeps the page on one question and
stops the writer from adding tactics the research does not support.

## What the page is for

One question group from `coverage-check.md`, graded none or adjacent, with a verdict of open or
contested.

| Field | Your answer |
|---|---|
| Question, in the asker's words | |
| Other phrasings it must also answer | |
| Monthly volume | |
| Who asks it (buyer, learner) | |
| Answer shape the engines give today (definition, how-to, vendor list, comparison) | |
| Pages cited today | |
| What those pages leave out | |
| Surface (guide, service page, method, article, video) | |

## How to build the page

These follow levers L2 and L6 in `levers-and-evidence.md`.

1. **Put the question in a heading, in the asker's words.** One question per heading.
2. **Answer it in the first two sentences under that heading.** A reader, or an engine, should be
   able to lift those two sentences and have the answer.
3. **Use specific numbers with their source and date.** "63.4% of citations, Ahrefs, 2026" can be
   checked. "Most citations" cannot.
4. **Name things.** The tool, the plan tier, the field, the author.
5. **Date the page and keep the date true.** Update it when a fact changes, and say what changed.
6. **Serve it as plain, crawlable HTML.** Text that only appears after a script runs may never be
   read.
7. **Cover what the cited pages leave out.** That gap is the reason for an engine to add you.
8. **Say what you do, in a sentence a stranger would repeat.** When the question is "who can do
   this", the engine needs a plain statement of who you serve and what you deliver.

## What to leave out

The research in `levers-and-evidence.md` found no lift from any of these, so they do not earn
writing time.

- A special file for AI crawlers
- Schema added only in the hope of AI citations (keep it for normal search features)
- A second version of the page rewritten "for AI"
- A list of "best" providers with your own firm in first place

## The brief

**Question.**

**The two-sentence answer.**

**Sections, each a question the asker has next.**

1.
2.
3.
4.

**Numbers the page will state, each with source and date.**

| Number | Source | Date read |
|---|---|---|
| | | |

**The gap this page fills.**

**Where it links (one main next step).**

## Check before it ships

- [ ] The first two sentences under each heading answer that heading alone
- [ ] Every number has a source and a date
- [ ] The page carries a visible date
- [ ] No claim about results we have not measured
- [ ] `coverage-check.md` is updated to exact for this question
