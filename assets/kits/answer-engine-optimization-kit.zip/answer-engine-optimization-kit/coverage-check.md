# Coverage check

Part of the Magnetiz Answer Engine Optimization implementation kit.

Run this after `citation-read.md` and before anyone writes. It answers one question. Have we already
answered this?

## Why this sheet exists

A question list makes every row look like new work. Teams then write a second page on a question an
older page already answers, and the two compete with each other.

We made this mistake ourselves. A question sat at the top of our list marked as unanswered. An
existing playbook and an existing blog section already covered it, and the list never showed that.

## Check the live site, never the list

For each open or contested question, look at what is published today.

1. Search your own site for the question's main phrase and its two closest phrasings.
2. Open every page that comes back and read the section that touches the question.
3. Record the page and grade the coverage.

| Grade | Meaning | What to do |
|---|---|---|
| Exact | A page is written to this question and answers it in its first two sentences | No new page. Refresh it if it is over 12 months old |
| Adjacent | A page covers it in a section or an FAQ entry | Improve that section, or split it into its own page if the question has its own volume |
| None | Nothing on the site answers it | This is a new page |

## Pick the next asset

One question can be answered on several surfaces. Write down which ones exist and which one is next.

| Surface | Best for |
|---|---|
| Guide or blog post | How-to and definition questions |
| Service page | "Who can do this" and factual questions about your firm |
| Downloadable method (a playbook, a template) | Questions where the reader wants to do the work |
| Long-form article under a person's name | Opinion and practice questions |
| Video | Questions where the cited sources are already videos |

## The ledger

| # | Question group | Volume | Verdict | Guide | Service page | Method | Article | Video | Next asset | Owner |
|---|---|---|---|---|---|---|---|---|---|---|
| Q1 | | | | | | | | | | |
| Q2 | | | | | | | | | | |
| Q3 | | | | | | | | | | |

Fill each surface cell with exact, adjacent or none.

## The rule for the week

Each week, the highest-volume question that is open or contested, and has no exact page, gets its
next asset. Any piece of content planned that week that answers no row on this ledger gets flagged
by name.

## What this sheet cannot tell you

Exact coverage means the page exists. It does not mean the page gets cited. That is what
`measurement-read.md` reads.
