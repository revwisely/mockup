# Citation read

Part of the Magnetiz Answer Engine Optimization implementation kit.

Run this on every question group in `question-list.md` before writing anything. It answers one
question. Can a company our size get named here?

## Why some questions are open and some are closed

Engines name the sources they already trust for a question. On broad questions those are the largest
brands. On narrow ones there are often few sources at all, and a new page can become one of them.

The research backs this, and all of it is listed in `levers-and-evidence.md`.

- Semrush tracked 1,094 categories in ChatGPT for six months. Only 15.2% had a clear owner and 53.7%
  were unsettled.
- Ahrefs published pages for a brand-new name. It appeared in 66.4% of answers to a narrow question
  and 15.8% of answers to a broader one.

## How to read a question

Ask each question on at least two engines, three times each, in a fresh session with no history.
Log what comes back.

| Field | What to write |
|---|---|
| Companies named | Every company the answer recommends or mentions |
| Pages cited | Every domain in the sources |
| Page type | Vendor product page, vendor blog, agency page, independent guide, list of "best X", forum thread, video, encyclopedia |
| Answer shape | A definition, a how-to, a list of vendors, or a comparison |
| Fresh | Whether the cited pages carry a date in the last 12 months |

## Sort each question

| Verdict | The pattern | What it means |
|---|---|---|
| Open | Cited pages are small sites, individual authors, forums or videos, and the names change between runs | A good page can join the sources. Start here |
| Contested | A mix of large brands and small sites | Winnable with a narrower angle. Write the narrow version first |
| Owned | The same two or three large brands in every run, citing their own pages | Skip, or find the narrow question underneath it |
| Wrong shape | The answer is a definition and you wanted a vendor list, or the reverse | Write the page the engine is already assembling, or skip |

## Find the narrow question underneath

A broad question that is owned usually has narrow ones under it that are open. Add one qualifier at
a time and read again.

- The platform. "lead scoring" becomes "hubspot lead scoring".
- The company size or sector. "for a 200 person B2B company".
- The task. "how to test" or "how to audit" in place of "what is".

Record each narrow version as its own row in `question-list.md`.

## The read

| # | Question group | Engines asked | Companies named | Domains cited | Page type | Answer shape | Verdict |
|---|---|---|---|---|---|---|---|
| Q1 | | | | | | | |
| Q2 | | | | | | | |
| Q3 | | | | | | | |

## What this sheet cannot tell you

Three runs show you the shape of the answer. They do not measure how often you would be named. That
takes the fixed set of runs in `measurement-read.md`.
